import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path

root=Path('/repo')
work=Path('/work')
delivery=root/'.artifacts/downloads/0.59.0-candidate.0/profile-views-linux'
proof=json.loads((root/'evidence/profile-views/deliveries.json').read_text())['linux']
archive=delivery/'hollow-wake-workshop-linux-x64.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archives'][archive.name]
with zipfile.ZipFile(archive) as source:
    for name in source.namelist():
        assert name.startswith('inventory-workshop/') and '..' not in Path(name).parts and '.godot' not in Path(name).parts
    source.extractall(work)
project=work/'inventory-workshop'
settings=work/'settings'
settings.mkdir()
env=dict(os.environ,HOME=str(settings),XDG_CONFIG_HOME=str(settings),XDG_DATA_HOME=str(settings),XDG_CACHE_HOME=str(settings),TMPDIR=str(settings))
command=['/tools/Godot_v4.7.2-stable_linux.x86_64','--headless','--editor','--import','--frame-delay','1000','--path',str(project),'--verbose']
started=time.monotonic()
with (work/'import.log').open('wb') as log:
    proc=subprocess.Popen(command,cwd=project,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    timed_out=False
    try: proc.wait(timeout=150)
    except subprocess.TimeoutExpired:
        timed_out=True
        proc.kill()
        proc.wait()
report=dict(command=command,exitCode=proc.returncode,timeout=timed_out,elapsed=time.monotonic()-started,archiveSha256=proof['archives'][archive.name],extensions=(project/'.godot/extension_list.cfg').read_text() if (project/'.godot/extension_list.cfg').exists() else None)
(work/'import.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
sys.exit(1 if timed_out or proc.returncode else 0)
