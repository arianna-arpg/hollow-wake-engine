import subprocess,sys
from pathlib import Path
root=Path('/repo');work=Path('/work/final-linux')
commands=[
 ['scripts/test-workshop-cleanup.py',str(work/'scratch')],
 ['scripts/check-godot-import-faults.py','/tools/Godot_v4.7.2-stable_linux.x86_64','/repo/.artifacts/downloads/0.59.0-candidate.0/profile-views-linux',str(work/'scratch'),str(work/'import-faults.json')],
 ['scripts/verify-background-workshop.py',str(work/'tools.json'),str(work/'native.json'),'/repo/.artifacts/downloads/0.59.0-candidate.0/profile-views-linux',str(work/'scratch'),str(work/'rebuilt-clean')],
]
for index,args in enumerate(commands):
    with (work/('finish-'+str(index)+'.log')).open('wb') as log:
        result=subprocess.run([sys.executable,'-I','-B',str(root/args[0]),*args[1:]],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    assert result.returncode==0,(work/('finish-'+str(index)+'.log')).read_text()[-5000:]
    print(args[0],'passed',flush=True)
assert not list((work/'scratch').iterdir())
print('HWE_IMPORT_AND_CLEANUP_OK',flush=True)
