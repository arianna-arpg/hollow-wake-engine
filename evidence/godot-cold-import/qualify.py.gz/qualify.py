import hashlib,json,runpy,subprocess,sys,zipfile
from pathlib import Path

root=Path('/repo');work=Path('/work/final-linux');work.mkdir()
delivery=root/'.artifacts/downloads/0.59.0-candidate.0/profile-views-linux'
tools=dict(editor='/tools/Godot_v4.7.2-stable_linux.x86_64',exportRelease='/tools/linux_release.x86_64',exportDebug='/tools/linux_debug.x86_64')
(work/'tools.json').write_text(json.dumps(tools))
proof=json.loads((delivery/'verification.json').read_text())
native=proof['native']
with zipfile.ZipFile(delivery/'hollow-wake-workshop-linux-x64.zip') as source:
    data=source.read('inventory-workshop/addons/hollow_wake_save/bin/libhwe_slot_store.so')
    assert hashlib.sha256(data).hexdigest()==native['librarySha256']
    (work/'libhwe_slot_store.so').write_bytes(data)
native['library']=str(work/'libhwe_slot_store.so')
(work/'native.json').write_text(json.dumps(native))
scratch=work/'scratch';scratch.mkdir()
commands=[
 ['scripts/check-background-workflows.py',tools['editor'],str(delivery),str(scratch),str(work/'workflows.json'),'--profile-views'],
 ['scripts/verify-background-workshop.py',str(work/'tools.json'),str(work/'native.json'),str(delivery),str(scratch),str(work/'rebuilt')],
]
for index,args in enumerate(commands):
    command=[sys.executable,'-I','-B',str(root/args[0]),*args[1:]]
    print('Starting',args[0],flush=True)
    with (work/('qualification-'+str(index)+'.log')).open('wb') as log:
        result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    print('Finished',args[0],result.returncode,flush=True)
    assert result.returncode==0,(work/('qualification-'+str(index)+'.log')).read_text()[-5000:]
assert not list(scratch.iterdir()),'Temporary installations remain'
print('HWE_COLD_QUALIFIED',flush=True)
