// ---------------------------------------------------------------------------
// ONE-OFF PROBE — THE ADVANCING FRONT end to end on the real engine
// (docs/engine/creep.md § fronts): classic-creep byte-identity when no
// front lever is set (pinned pre-change fingerprint), directional march,
// affinity weighting + the clearway firebreak, consumption (remnant swap,
// removal, kin), conversion-behind (ashfield; the flood's shallow wake),
// the yieldWays causeway mask (drawn == tested), quench/feed through the
// real blast tap, undertow drag + the breath ramp, ambient wave lanes
// (+ the authored landslide announce rows driven off TILESETS — drawn ==
// tested), and the cadence-less creep heart's ONE-SHOT latch (a shipped
// creepSource without a cadence never arms the pump clock — and the
// section-0 fingerprint re-proves the classic path byte-identical under
// the pump-aware sweep). Plus THE GROW VERB (growCreepAt — cleanseAt's
// symmetric twin: revive/plant/claim, the irrevocable recoils, the
// arrival line, the kind-scoped cleanse, the cadenced grant dial) and
// the POXROT debut (the Contagion's own carried ground — the first
// world-event package to own a creep kind).
// Run: npx tsx balance/probe_front.ts
// ---------------------------------------------------------------------------

import { bootSimEngine, makeSimWorld } from '../src/sim/arena';
import { applyBuild } from '../src/sim/builds';
import { seedGlobalRandom } from '../src/sim/rng';
import { buildZoneCreep, CreepField, CREEPS, CREEP_CFG, registerCreep } from '../src/engine/creep';
import type { FrontSpawnRow } from '../src/engine/creep';
import { killRules } from '../src/engine/killHandlers';
import { TILESETS } from '../src/data/tilesets';
import type { Doodad } from '../src/engine/levelgen';
import { vec } from '../src/core/math';
import { Rng } from '../src/core/rng';
import type { BuildSpec } from '../src/sim/types';

let failed = 0;
const check = (name: string, ok: boolean, detail = ''): void => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`);
  if (!ok) failed++;
};

bootSimEngine();
seedGlobalRandom(0xf407);

const fnv = (text: string): string => {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return `0x${h.toString(16).padStart(8, '0')}`;
};

// --- 0) CLASSIC BYTE-IDENTITY: the exact pre-change scenario, pinned ------
// Captured on the committed tree BEFORE any front code existed
// (balance/reports/_fp_creep_classic.ts). A creep row with no front levers
// must tick byte-identically forever.
{
  const world = makeSimWorld('warrior', 133742);
  const f = world.creepEnsure()!;
  const heart = { dead: false };
  f.addSource(CREEPS['caulflesh'], 600, 500, { bornFrac: 0 });
  f.addSource(CREEPS['blightgrowth'], 900, 700, { bornFrac: 0.5 });
  f.addSource(CREEPS['caulflesh'], 400, 800, { reach: 180, bornFrac: 1, ambient: true });
  f.addSource(CREEPS['blightgrowth'], 1200, 400, { bornFrac: 0.25, boundTo: heart });
  const PROBES: [number, number][] = [
    [650, 520], [880, 690], [410, 795], [1180, 410], [30, 30], [700, 640],
  ];
  const lines: string[] = [];
  const dt = 1 / 60;
  let t = 0;
  for (let sec = 0; sec < 8; sec++) {
    for (let i = 0; i < 60; i++) {
      world.update(dt);
      t += dt;
      if (heart.dead === false && t >= 3) heart.dead = true;
    }
    for (const s of f.sources) {
      lines.push([
        s.def.id, s.state, s.ambient ? 1 : 0,
        s.pos.x.toFixed(3), s.pos.y.toFixed(3),
        s.cur.toFixed(3), s.maxReach.toFixed(3), s.bound.toFixed(3),
        s.seed, s.phase.toFixed(6),
        s.harm.map(h => `${h.k}:${h.a.toFixed(6)}:${h.p.toFixed(6)}`).join('|'),
      ].join(','));
    }
    for (const [px, py] of PROBES) lines.push(`c:${f.coverAt(px, py).toFixed(6)}:${f.onCreep(px, py) ? 1 : 0}`);
    lines.push(`n:${f.sources.length}`);
  }
  const hash = fnv(lines.join('\n'));
  check('classic: byte-identical fingerprint (no lever set = yesterday\'s creep)',
    hash === '0x04e4055d', `got ${hash}, want 0x04e4055d over ${lines.length} lines`);
}

// --- 1) THE FLOODCREST: march, wake, undertow, breath ----------------------
{
  const world = makeSimWorld('warrior', 24603);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  const f = world.creepEnsure()!;
  const p = world.player;
  const src = f.addFront(CREEPS['floodcrest'], cx - 600, cy, 0, { reach: 120, bornFrac: 1 })!;
  check('flood: addFront plants a marching section', !!src?.front);
  const startX = src.pos.x;
  const dt = 1 / 60;
  // Phase 1 — IN the crest: pin the hero at the surge's heart (the undertow
  // would otherwise shove them out to surf the skirt — that's phase 2's
  // assert) and let the water dress and drown them properly.
  let swimSeen = false;
  for (let i = 0; i < 60 * 3; i++) {
    p.pos.x = src.pos.x + 10;
    p.pos.y = src.pos.y;
    world.update(dt);
    if (!swimSeen && p.statuses.some(s => s.id === 'swimming')) swimSeen = true;
  }
  check('flood: swimming granted inside the crest (the marine pass\'s own slow)', swimSeen);
  const breath = p.survival?.get('breath');
  check('flood: breath drained on the deep-water ramp', breath !== undefined && breath < 11,
    `breath ${breath?.toFixed(1) ?? 'full'} after 3s under`);
  // Phase 2 — AHEAD of the crest: a free body is caught and CARRIED.
  p.pos.x = src.pos.x + 180;
  p.pos.y = cy;
  const heroAt = p.pos.x;
  let dragSeen = false;
  for (let i = 0; i < 60 * 22; i++) {
    world.update(dt);
    if (!dragSeen && p.pos.x > heroAt + 40) dragSeen = true;
  }
  check('flood: the crest MARCHES its bearing', src.pos.x - startX > 200,
    `advanced ${(src.pos.x - startX).toFixed(0)} east, drifted ${(src.pos.y - cy).toFixed(1)} lateral`);
  check('flood: no lateral wander on a fixed bearing', Math.abs(src.pos.y - cy) < 1);
  // Scan the marched-over stretch: stamp clocks stagger by seed, so the
  // wake's first pool lands SOMEWHERE along the path, never at a fixed x.
  let wakeShallow = false, wakeDeep = false;
  for (let off = 40; off <= 420; off += 20) {
    const g = world.groundAt(vec(startX + off, cy));
    if (g?.kind === 'water') { wakeShallow ||= !g.deep; wakeDeep ||= g.deep; }
  }
  check('flood: a wadeable SHALLOW wake behind (the ford contract, never a new deep)',
    wakeShallow && !wakeDeep, `shallow ${wakeShallow}, deep ${wakeDeep}`);
  // POOLS NEVER STACK: overlapping shallow discs pile their per-disc ford
  // lightening into a flat wash that erases the mottle (the "ground goes
  // flat past a line" playtest read) — geometry spaces them and the stamp
  // adapter refuses the rest; this pin holds both honest.
  const pools = world.doodads.filter(d => d.kind === 'water' && d.shallow === true);
  let stacked = 0;
  for (let i = 0; i < pools.length; i++) {
    for (let j = i + 1; j < pools.length; j++) {
      const dd = Math.hypot(pools[i].pos.x - pools[j].pos.x, pools[i].pos.y - pools[j].pos.y);
      if (dd < (pools[i].radius + pools[j].radius) * 0.95) stacked++;
    }
  }
  check('flood: wake pools never overlap (the ford-wash bug stays dead)',
    pools.length > 0 && stacked === 0, `${pools.length} pools, ${stacked} stacked pairs`);
  check('flood: wake discs are real terrain (doodad list carries shallow water)',
    world.doodads.some(d => d.kind === 'water' && d.shallow === true));
  check('flood: the undertow CARRIED the hero downstream', dragSeen,
    `hero ${heroAt.toFixed(0)} → ${p.pos.x.toFixed(0)}`);
  // The deep's kin ride the tow for free: a faction on the drag's waiver
  // list holds its ground where the unlisted hero was swept away.
  const before = f.sources.length;
  p.faction = 'deep';
  const px0 = p.pos.x;
  for (let i = 0; i < 60; i++) world.update(dt);
  check('flood: the deep-sworn are NOT dragged (drag.notFactions)',
    f.sources.length === 0 || Math.abs(p.pos.x - px0) < 8,
    `drift ${(p.pos.x - px0).toFixed(1)} over 1s (sources live: ${before})`);
  delete p.faction;
}

// --- 2) THE WILDFIRE: fuel, remnants, ashfield, the firebreak --------------
{
  seedGlobalRandom(0xa11ce);
  const world = makeSimWorld('warrior', 24604);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  // Fuel in the fire's path — BEFORE creepEnsure, so the terrain window's
  // way snapshot and doodad index both see the finished ground.
  const fuels: Doodad[] = [];
  for (let i = 0; i < 6; i++) fuels.push({ pos: vec(cx - 140 + i * 55, cy + (i % 2 ? 24 : -24)), radius: 12, kind: 'brush' });
  fuels.push({ pos: vec(cx + 40, cy), radius: 16, kind: 'tree' });
  fuels.push({ pos: vec(cx + 120, cy - 20), radius: 16, kind: 'tree' });
  // A kept road crossing the path at cx+330: the FIREBREAK.
  for (let y = cy - 260; y <= cy + 260; y += 34) fuels.push({ pos: vec(cx + 330, y), radius: 22, kind: 'road' });
  world.doodads.push(...fuels);
  const f = world.creepEnsure()!;
  const src = f.addFront(CREEPS['wildfire'], cx - 300, cy, 0, { reach: 100, bornFrac: 1 })!;
  const dt = 1 / 60;
  let gutteredBy = -1;
  for (let i = 0; i < 60 * 34; i++) {
    world.update(dt);
    if (gutteredBy < 0 && (src.state === 'recede' || !f.sources.includes(src))) gutteredBy = i / 60;
  }
  const brushLeft = world.doodads.filter(d => d.kind === 'brush').length;
  const snags = world.doodads.filter(d => d.kind === 'charred_snag').length;
  const treesLeft = world.doodads.filter(d => d.kind === 'tree').length;
  check('fire: kindling consumed outright', brushLeft === 0, `${brushLeft} brush left of 6`);
  check('fire: timber left as CHARRED SNAGS (kind swap)', snags === 2 && treesLeft === 0,
    `${snags} snags, ${treesLeft} live trees`);
  let ashSeen = false;
  for (let off = -220; off <= 120; off += 20) {
    if (world.groundAt(vec(cx + off, cy))?.kind === 'ashfield') { ashSeen = true; break; }
  }
  check('fire: ASHFIELD laid behind the trailing rim', ashSeen);
  check('fire: the road is a FIREBREAK (clearway 0 walls the march; starve gutters it)',
    gutteredBy > 0, gutteredBy > 0 ? `guttered at ${gutteredBy.toFixed(1)}s` : 'still marching');
  const overRoad = world.groundAt(vec(cx + 470, cy));
  check('fire: nothing burned past the break', overRoad?.kind !== 'ashfield',
    `beyond-road ground: ${overRoad?.kind ?? 'bare'}`);
  const kin = world.actors.filter(a => a.defId === 'cinderling' || a.defId === 'emberwisp');
  check('fire: consumption may birth kin, capped (consume.spawn)',
    kin.length <= CREEP_CFG.front.spawnMax, `${kin.length} born (cap ${CREEP_CFG.front.spawnMax})`);
}

// --- 3) YIELDWAYS: the causeway is dry in the hit test ---------------------
{
  const world = makeSimWorld('warrior', 24605);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  const road: Doodad[] = [];
  for (let y = cy - 300; y <= cy + 300; y += 34) road.push({ pos: vec(cx + 100, y), radius: 22, kind: 'road' });
  world.doodads.push(...road);
  const f = world.creepEnsure()!;
  const src = f.addFront(CREEPS['floodcrest'], cx - 80, cy, 0, { reach: 130, bornFrac: 1 })!;
  const dt = 1 / 60;
  // March until the crest is centered over the causeway.
  let steps = 0;
  while (src.pos.x < cx + 100 && steps++ < 60 * 20) world.update(dt);
  const onDeck = f.onCreep(cx + 100, cy);
  const besideDeck = f.onCreep(cx + 100 - 60, cy);
  check('causeway: the DECK is dry in the hit test while the water covers it', !onDeck && besideDeck,
    `deck ${onDeck ? 'wet' : 'dry'}, verge ${besideDeck ? 'wet' : 'dry'} (crest at ${src.pos.x.toFixed(0)})`);
  for (let i = 0; i < 60 * 6; i++) world.update(dt);
  const deckGround = world.groundAt(vec(cx + 100, cy));
  check('causeway: the wake never stamped the deck wet', deckGround?.kind === 'road',
    `deck ground: ${deckGround?.kind ?? 'bare'}`);
}

// --- 4) QUENCH & FEED: typed damage on the skin, through the real tap ------
{
  const world = makeSimWorld('sorcerer', 24606);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  const f = world.creepEnsure()!;
  const src = f.addFront(CREEPS['wildfire'], cx + 40, cy, 0, { reach: 110, bornFrac: 1 })!;
  const run = src.front!;
  const spec: BuildSpec = {
    id: 'front_probe', classId: 'sorcerer', level: 9,
    skills: [{ id: 'frost_nova', level: 3 }],
  };
  const warnings = applyBuild(world, spec, 7);
  if (warnings.length) console.log('build warnings:', warnings.join(' | '));
  const p = world.player;
  p.pos.x = cx - 40;
  p.pos.y = cy;
  const dt = 1 / 60;
  for (let i = 0; i < 30; i++) world.update(dt);
  const vigor0 = run.vigor;
  const nova = p.skills.find(s => s?.def.id === 'frost_nova');
  check('build: frost nova on the bar', !!nova);
  world.useSkill(p, nova!, { x: p.pos.x, y: p.pos.y });
  for (let i = 0; i < 60; i++) world.update(dt);
  check('quench: a real cold cast through the blast tap stalls the section',
    run.vigor < vigor0, `vigor ${vigor0.toFixed(3)} → ${run.vigor.toFixed(3)}`);
  // The quantitative lane: enough cold gutters the section outright.
  f.damageSkin(src.pos.x, src.pos.y, 60, { cold: 9999 });
  check('quench: guttered at zero vigor (state recede)', src.state === 'recede',
    `vigor ${run.vigor.toFixed(2)}, state ${src.state}`);
  // FEED mirrors on its own lever, deliberately heavy-handed to move:
  const src2 = f.addFront(CREEPS['wildfire'], cx - 200, cy + 300, 0, { reach: 100, bornFrac: 1 })!;
  const stoke0 = src2.front!.stoke;
  f.damageSkin(src2.pos.x, src2.pos.y, 60, { fire: 450 });
  check('feed: fire STOKES a burning section (high power — a stray splash barely moves it)',
    src2.front!.stoke > stoke0 && src2.front!.stoke <= CREEP_CFG.front.stokeMax,
    `stoke ${stoke0.toFixed(2)} → ${src2.front!.stoke.toFixed(2)}`);
  const src3 = f.addFront(CREEPS['floodcrest'], cx - 200, cy - 300, 0, { reach: 100, bornFrac: 1 })!;
  f.damageSkin(src3.pos.x, src3.pos.y, 60, { fire: 9999 });
  check('anti-goal: fire does NOTHING to the flood (no reaction matrix — unlisted types are silence)',
    src3.front!.vigor === 1 && src3.state !== 'recede');
}

// --- 5) DETERMINISM: same seed, same march, same ground --------------------
{
  const trace = (seed: number): string => {
    seedGlobalRandom(seed);
    const world = makeSimWorld('warrior', 777001);
    const cx = world.arena.w / 2, cy = world.arena.h / 2;
    const fuels: Doodad[] = [];
    for (let i = 0; i < 5; i++) fuels.push({ pos: vec(cx - 100 + i * 60, cy + (i % 2 ? 20 : -20)), radius: 12, kind: 'brush' });
    fuels.push({ pos: vec(cx + 100, cy), radius: 16, kind: 'tree' });
    world.doodads.push(...fuels);
    const f = world.creepEnsure()!;
    f.addFront(CREEPS['wildfire'], cx - 260, cy, 0.1, { reach: 100, bornFrac: 1 });
    const dt = 1 / 60;
    for (let i = 0; i < 60 * 8; i++) world.update(dt);
    const lines: string[] = [];
    for (const s of f.sources) {
      lines.push(`${s.def.id},${s.pos.x.toFixed(3)},${s.pos.y.toFixed(3)},${s.cur.toFixed(3)},${s.state},`
        + `${s.front ? `${s.front.vigor.toFixed(4)},${s.front.stoke.toFixed(4)},${s.front.mult.toFixed(4)},${s.front.stamps}` : ''}`);
    }
    for (const d of world.doodads) {
      if (d.kind === 'ashfield' || d.kind === 'charred_snag' || d.kind === 'brush' || d.kind === 'tree') {
        lines.push(`${d.kind}@${d.pos.x.toFixed(2)},${d.pos.y.toFixed(2)},${d.radius.toFixed(2)}`);
      }
    }
    lines.push(...world.actors.filter(a => a.defId === 'cinderling' || a.defId === 'emberwisp')
      .map(a => `kin:${a.defId}`).sort());
    return fnv(lines.join('\n'));
  };
  const a = trace(11);
  const b = trace(11);
  check('determinism: twice-run front leaves identical ground, march and kin', a === b, `${a} vs ${b}`);
}

// --- 6) AMBIENT LANES: waves break in, die out, return ---------------------
{
  const world = makeSimWorld('warrior', 24607);
  const f = world.creepEnsure()!;
  f.installLanes([{ id: 'floodcrest', line: [3, 3], bearing: 0, delay: [1, 1], waves: [2, 2] }]);
  const dt = 1 / 60;
  for (let i = 0; i < 90; i++) world.update(dt);
  const wave1 = f.sources.filter(s => s.front?.rowIdx === 0).length;
  check('lanes: the first wave breaks in on its delay, a picket line abreast', wave1 === 3, `${wave1} sections`);
  // Cleanse the wave (the payoff verb force-recedes it) and wait: the lane
  // owes its next wave.
  world.creep!.cleanseAt(0, 0, 1e9);
  let returned = 0;
  for (let i = 0; i < 60 * 8; i++) {
    world.update(dt);
    const n = f.sources.filter(s => s.front?.rowIdx === 0 && s.state !== 'recede').length;
    if (n === 3) { returned = n; break; }
  }
  check('lanes: the next wave RETURNS on the row\'s cadence (waves lever)', returned === 3);
}

// --- 7) THE TIDAL SPAN: the wall crosses, THE CORRIDOR HOLDS ---------------
{
  const world = makeSimWorld('warrior', 24608);
  const W = world.arena.w, H = world.arena.h;
  const f = world.creepEnsure()!;
  f.installLanes([{
    id: 'tidalwall', line: 'span', bearing: 0, delay: [0.5, 0.5],
    spacing: 0.8, reach: [90, 120], gap: { width: 140 },
  }]);
  const dt = 1 / 60;
  for (let i = 0; i < 90; i++) world.update(dt);
  const secs = f.sources.filter(s => s.front?.rowIdx === 0);
  check('span: the wall fields wall-to-wall (a line, not a picket)', secs.length >= 4,
    `${secs.length} sections across H=${H}`);
  check('span: the lane reach override held', secs.every(s => s.maxReach >= 90 && s.maxReach <= 120),
    secs.map(s => s.maxReach.toFixed(0)).join(','));
  check('span: bearings exactly parallel (spanning lanes never jitter)',
    secs.every(s => s.front!.bearing === 0));
  // Find the promised corridor from the fielded geometry: the widest hole
  // between adjacent rim CEILINGS (maxReach × (1+Σa) × stretch).
  const st = Math.max(1, CREEPS['tidalwall'].front!.stretch ?? 1);
  const rows = secs.map(s => {
    let sum = 0;
    for (const h of s.harm) sum += h.a;
    return { y: s.pos.y, ceil: s.maxReach * (1 + sum) * st };
  }).sort((a, b) => a.y - b.y);
  let gapY = -1, gapW = 0;
  for (let i = 0; i + 1 < rows.length; i++) {
    const lo = rows[i].y + rows[i].ceil, hi = rows[i + 1].y - rows[i + 1].ceil;
    if (hi - lo > gapW) { gapW = hi - lo; gapY = (lo + hi) / 2; }
  }
  check('span: a clear corridor at least gap.width wide exists between rim ceilings',
    gapW >= 140, `widest hole ${gapW.toFixed(0)} at y=${gapY.toFixed(0)}`);
  // March the whole crossing: the corridor must NEVER read on-creep while
  // the wall's own tracks flood solid — the weave lane is a promise about
  // the hit test, held for the wave's entire life. The hero PARKS in the
  // corridor for the duration: standing in the weave lane must be fully
  // survivable (no cover → no undertow, no breath drain — and no drowned
  // hero stalling the sim, which is exactly what parking him mid-wall did).
  const p = world.player;
  const wallY = rows[0].y;
  let corridorMax = 0, wallMax = 0, t = 0, tick = 0;
  while (f.sources.some(s => s.front?.rowIdx === 0) && t < 140) {
    p.pos.x = 400;
    p.pos.y = gapY;
    world.update(dt); t += dt; tick++;
    if (tick % 30 === 0) {
      for (let x = 20; x < W; x += 30) {
        corridorMax = Math.max(corridorMax, f.coverAt(x, gapY));
        wallMax = Math.max(wallMax, f.coverAt(x, wallY));
      }
    }
  }
  check('span: THE CORRIDOR HELD the whole crossing (never on-creep anywhere along it)',
    corridorMax < CREEP_CFG.hitFloor, `max corridor cover ${corridorMax.toFixed(3)} vs floor ${CREEP_CFG.hitFloor}`);
  check('span: the wall itself flooded solid on its own track', wallMax >= 0.99,
    `max wall cover ${wallMax.toFixed(3)}`);
  check('span: the wave crossed and left (no lingering sections)',
    !f.sources.some(s => s.front?.rowIdx === 0), `crossed in ${t.toFixed(0)}s`);
  const breathRow = p.survival?.get('breath');
  check('span: the hero LIVED in the weave lane (no drown, no undertow)',
    !p.dead && (breathRow === undefined || breathRow > 10),
    `alive ${!p.dead}, breath ${breathRow?.toFixed(1) ?? 'full'}`);
}

// --- 8) THE EVAPORATING WAKE: pools dry, the floor reverts -----------------
{
  const world = makeSimWorld('warrior', 24609);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  const f = world.creepEnsure()!;
  f.addFront(CREEPS['brinesurge'], cx - 500, cy, 0, { reach: 90, bornFrac: 1 });
  const dt = 1 / 60;
  for (let i = 0; i < 60 * 20; i++) world.update(dt);
  const pools = world.doodads.filter(d => d.kind === 'tide_pool' && d.evap);
  check('evap: the wake stamps DRYING tide pools (convert.fade)', pools.length >= 2,
    `${pools.length} pools`);
  const p0 = pools[0];
  const center = vec(p0.pos.x, p0.pos.y);
  const r0 = p0.radius;
  check('evap: a live pool is real sensed ground', world.groundAt(center)?.kind === 'tide_pool');
  const radii = new Set<number>([p0.radius]);
  let gone = -1;
  for (let i = 0; i < 60 * 80 && gone < 0; i++) {
    world.update(dt);
    radii.add(p0.radius);
    if (!world.doodads.includes(p0)) gone = i / 60;
  }
  check('evap: the pool contracted then vanished (the zone reverts)', gone > 0,
    gone > 0 ? `r0 ${r0.toFixed(0)} gone at ${gone.toFixed(1)}s` : `still r=${p0.radius.toFixed(1)}`);
  check('evap: contraction is QUANTIZED steps (a bounded stale trickle, never per-frame churn)',
    radii.size >= 3 && radii.size <= 20, `${radii.size} distinct radii`);
  check('evap: the floor reverted under it', world.groundAt(center)?.kind !== 'tide_pool',
    `now: ${world.groundAt(center)?.kind ?? 'bare'}`);
  // addTempGround's evaporate option: the patch DRIES at expiry instead of
  // popping — the same fabric, opened to every temp-ground caller.
  const at = vec(cx + 320, cy + 320);
  world.addTempGround(at, 'ashfield', 40, 1.0, { evaporate: { rate: 30 } });
  const patch = world.doodads.find(d => d.kind === 'ashfield' && d.pos.x === at.x && d.pos.y === at.y)!;
  for (let i = 0; i < 72; i++) world.update(dt); // 1.2s: dwell served, drying begun
  check('evap: addTempGround evaporate DRIES instead of popping',
    world.doodads.includes(patch) && patch.radius < 40,
    `r ${patch.radius.toFixed(1)} at 1.2s (was 40)`);
  let patchGone = false;
  for (let i = 0; i < 60 * 4 && !patchGone; i++) {
    world.update(dt);
    patchGone = !world.doodads.includes(patch);
  }
  check('evap: the temp patch finished drying away', patchGone);
}

// --- 9) STRETCH: one ellipse truth for hit test and bound ------------------
{
  registerCreep({ id: 'probe_stretch', lobing: 0, front: { speed: 10, stretch: 2.5 } });
  const world = makeSimWorld('warrior', 24610);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  const f = world.creepEnsure()!;
  const src = f.addFront(CREEPS['probe_stretch'], cx, cy, 0, { reach: 100, bornFrac: 1 })!;
  const along = f.rimAt(src, 0), across = f.rimAt(src, Math.PI / 2);
  check('stretch: across-rim = along-rim × stretch (rimMulOf, lobing 0 exact)',
    Math.abs(across / along - 2.5) < 1e-9, `${along.toFixed(1)} → ${across.toFixed(1)}`);
  check('stretch: the broad-phase bound covers the across axis', src.bound >= across,
    `bound ${src.bound.toFixed(1)} vs across ${across.toFixed(1)}`);
  const on = f.coverAt(cx, cy + across * 0.9);
  const off = f.coverAt(cx, cy + across * 1.05);
  const offAlong = f.coverAt(cx + across * 0.9, cy);
  check('stretch: cover rides the stretched rim (in wet, out dry)',
    on >= CREEP_CFG.hitFloor && off === 0, `in ${on.toFixed(2)}, out ${off.toFixed(2)}`);
  check('stretch: the along axis stays UNstretched (a wall, not a bigger circle)',
    offAlong === 0, `cover at 2.25R along: ${offAlong.toFixed(2)}`);
}

// --- 10) NOTAQUATIC: no water within water ---------------------------------
{
  const dry = buildZoneCreep(
    { pockets: [0, 0], kinds: [], fronts: [{ id: 'tidalwall' }] },
    { w: 2000, h: 1400 }, new Rng(7));
  const wet = buildZoneCreep(
    { pockets: [0, 0], kinds: [], fronts: [{ id: 'tidalwall' }] },
    { w: 2000, h: 1400, aquatic: true }, new Rng(7));
  check('aquatic: the tidal lane is refused under the sea (structural, not authorial)',
    dry !== null && wet === null, `dry ${dry ? 'field' : 'null'}, aquatic ${wet ? 'field' : 'null'}`);
  const wet2 = buildZoneCreep(
    { pockets: [2, 3], kinds: [{ id: 'brinesurge' }, { id: 'caulflesh' }] },
    { w: 2000, h: 1400, aquatic: true }, new Rng(9));
  check('aquatic: sea-forsworn pocket kinds filtered; unflagged kinds still grow',
    wet2 !== null && wet2.sources.length > 0 && wet2.sources.every(s => s.def.id === 'caulflesh'),
    wet2 ? `${wet2.sources.length} pockets: ${[...new Set(wet2.sources.map(s => s.def.id))].join(',')}` : 'null');
}

// --- 11) CHANCE: the intra-zone-event dial ---------------------------------
{
  const mk = (seed: number): number => {
    const f2 = buildZoneCreep(
      { pockets: [0, 0], kinds: [], fronts: [{ id: 'floodcrest', chance: 0.5 }] },
      { w: 1500, h: 1000 }, new Rng(seed));
    return f2 ? f2.laneCount() : 0;
  };
  check('chance: per-visit roll is deterministic per seed',
    mk(41) === mk(41) && mk(97) === mk(97));
  let on = 0;
  for (let s = 0; s < 30; s++) on += mk(1000 + s) ? 1 : 0;
  check('chance: both outcomes occur across seeds (an event, not a fixture)',
    on > 4 && on < 26, `${on}/30 visits fielded the lane`);
  const always = buildZoneCreep(
    { pockets: [0, 0], kinds: [], fronts: [{ id: 'floodcrest' }] },
    { w: 1500, h: 1000 }, new Rng(5));
  check('chance: absent = fixture (and chance-less rows draw no extra rng)',
    always?.laneCount() === 1);
}

// --- 12) ANNOUNCE: one arrival line per fielding wave ----------------------
{
  const f = new CreepField(new Rng(77), 1600, 1200);
  const seen: string[] = [];
  f.setTerrain({
    groundKindAt: () => null,
    eachFuelNear: () => {},
    consume: () => {},
    stamp: () => {},
    drag: () => {},
    drown: () => {},
    announce: text => seen.push(text),
  });
  f.installLanes([
    { id: 'tidalwall', line: 'span', bearing: 0, delay: [0, 0], announce: { text: 'the sea rises!' } },
    { id: 'floodcrest', line: [2, 2], bearing: 0, delay: [0, 0] },
  ]);
  f.update(0.1, 0, []);
  check('announce: one line per announcing wave — silent rows stay silent',
    seen.length === 1 && seen[0] === 'the sea rises!', seen.join('|') || 'none');
}

// --- 13) THE ONE-SHOT LATCH: a shipped cadence-less heart never pumps ------
// creepSource.cadence added the pump lane; a SHIPPED heart without one
// must keep yesterday's contract exactly — one planted pocket, no next-
// beat stamp, no marching wave, ever (the byte-identity half is section
// 0's pinned fingerprint, which ticks through the same pump-aware sweep).
{
  const world = makeSimWorld('warrior', 24611);
  const cx = world.arena.w / 2, cy = world.arena.h / 2;
  const f = world.creepEnsure()!;
  const snail = world.createMonster('garden_snail', 4, 'enemy');
  snail.pos.x = cx + 500; snail.pos.y = cy;
  world.actors.push(snail);
  const dt = 1 / 60;
  for (let i = 0; i < 60 * 6; i++) world.update(dt);
  const own = f.sources.filter(s => s.boundTo === snail);
  check('one-shot: the shipped heart planted exactly one pocket in 6s',
    own.length === 1 && !own[0]?.front, `${own.length} sources`);
  check('one-shot: no pump stamp ever armed (creepSource without cadence)',
    snail.creepPlanted === true && snail.creepPumpAt === undefined,
    `planted ${snail.creepPlanted}, pumpAt ${snail.creepPumpAt ?? '-'}`);
}

// --- 14) THE WEATHER GATE: a when-gated lane waits at the door -------------
// FrontSpawnRow.when (FrontCond via the terrain window's condHeld): a
// pending wave whose sky says no WAITS timer-spent and fields the moment
// the condition holds — the machinery behind the snowcrown avalanche and
// the coastal STORM TIDE rows.
{
  let held = false;
  const f = new CreepField(new Rng(88), 1600, 1200);
  f.setTerrain({
    groundKindAt: () => null,
    eachFuelNear: () => {},
    consume: () => {},
    stamp: () => {},
    drag: () => {},
    drown: () => {},
    condHeld: () => held,
  });
  f.installLanes([{
    id: 'tidalwall', line: 'span', bearing: 0, delay: [0.5, 0.5],
    when: { weather: ['storm'] },
  }]);
  const dt = 1 / 60;
  for (let i = 0; i < 90; i++) f.update(dt, i * dt, []);
  check('when: a gated lane WAITS at the door while the sky says no (timer spent)',
    f.sources.length === 0, `${f.sources.length} sections by 1.5s on a 0.5s delay`);
  held = true;
  f.update(dt, 1.6, []);
  check('when: the wave fields the MOMENT its condition holds',
    f.sources.length > 0, `${f.sources.length} sections`);
}

// --- 15) THE SHIPPED LANES: storm-tide rows + the gutworks peristalsis -----
// Census of the authored when-gated content (docs/engine/creep.md): each
// coastal face keeps its ungated tidal fixture AND appends exactly one
// storm-gated sibling (the append law — appended rows never shift earlier
// rows' draws) that is strictly meaner: likelier, bigger, sooner. And the
// gutworks runs its queued push — a bore row with flow + confine + a slow
// finite travel, leaning on the tract's own ground.
{
  const mean = (band: readonly [number, number]): number => (band[0] + band[1]) / 2;
  const defMean = mean(CREEPS['tidalwall'].reach ?? [0, 0]);
  for (const id of ['strand', 'brine_flats', 'drowned_margin']) {
    const fronts = TILESETS[id]?.theme.creep?.fronts ?? [];
    const walls = fronts.filter(r => r.id === 'tidalwall');
    const clear = walls.filter(r => !r.when);
    const storm = walls.filter(r => r.when?.weather?.includes('storm'));
    check(`storm tide: ${id} fields the ungated fixture AND one storm sibling`,
      clear.length === 1 && storm.length === 1,
      `${clear.length} ungated, ${storm.length} storm-gated of ${fronts.length} lanes`);
    if (clear.length !== 1 || storm.length !== 1) continue;
    const s0 = storm[0], c0 = clear[0];
    check(`storm tide: ${id} appended the gated row AFTER the fixture (the append law)`,
      fronts.indexOf(s0) > fronts.indexOf(c0));
    check(`storm tide: ${id} storm wall is strictly meaner (chance up, reach up, clock down)`,
      (s0.chance ?? 1) > (c0.chance ?? 1)
      && !!s0.reach && mean(s0.reach) > defMean
      && !!s0.waves && !!c0.waves && s0.waves[1] <= c0.waves[1],
      `chance ${c0.chance} → ${s0.chance}, reach mean ${defMean} → ${s0.reach ? mean(s0.reach) : '-'}`);
  }
  const gutFronts = TILESETS['gutworks']?.theme.creep?.fronts ?? [];
  const bolus = gutFronts.find(r => !!CREEPS[r.id]?.front?.flow);
  const bk = bolus ? CREEPS[bolus.id] : undefined;
  check('peristalsis: the gutworks fields a bore lane (a flow row on the tract face)',
    !!bolus && !!bk, gutFronts.map(r => r.id).join(',') || 'no lanes');
  if (bolus && bk?.front) {
    check('peristalsis: the push is vessel-confined with a finite travel (the reserved shape)',
      bk.front.flow?.confine === true && !!bk.front.travel);
    check('peristalsis: a QUEUE, not a pump — slower than the artery\'s bore',
      bk.front.speed < CREEPS['sanguine_bore'].front!.speed,
      `${bk.front.speed} vs sanguine ${CREEPS['sanguine_bore'].front!.speed}`);
    check('peristalsis: the wave leans on the tract\'s own ground and never refuses it',
      (bk.front.affinity?.ground?.['chyme_pool'] ?? 0) > 1
      && bk.front.convert?.ground === 'chyme_pool' && !!bk.front.convert?.fade,
      `chyme_pool affinity ${bk.front.affinity?.ground?.['chyme_pool'] ?? '-'}`);
  }
}

// --- 16) THE GROW VERB: growCreepAt, cleanseAt's symmetric twin ------------
// The payoff API could only ever recede until this landed. The contract:
// within r, recoiling kin of THE KIND revive (the un-cleanse); the
// irrevocable recoils (dead heart, spent run) neither revive nor claim;
// where no live kin claims, a fresh patch plants through addSource's whole
// grammar; the arrival line prints once per visit; refusals return 0.
{
  registerCreep({ id: 'probe_grow', reach: [80, 80], spread: 30, recede: 60 });
  registerCreep({
    id: 'probe_grow_bolt', reach: [40, 40], spread: 30, recede: 2,
    front: { speed: 300, travel: { range: [10, 10] } },
  });
  const def = CREEPS['probe_grow'];
  const f = new CreepField(new Rng(0x9e0d), 2000, 2000);
  const dt = 1 / 60;
  let t = 0;
  const tick = (n: number): void => { for (let i = 0; i < n; i++) { t += dt; f.update(dt, t, []); } };

  // PLANT where nothing claims — born small, the skin visibly crawls out.
  check('grow: plants on empty ground (returns 1)',
    f.growCreepAt(def, 600, 500, 90) === 1 && f.sources.length === 1);
  check('grow: a planted patch is born growing', f.sources[0].state === 'grow');

  // THE CLAIM: a live patch within r suppresses replanting.
  check('grow: a live claim suppresses the plant (returns 0)',
    f.growCreepAt(def, 620, 510, 90) === 0 && f.sources.length === 1);

  // THE UN-CLEANSE: a recoiling patch turns back to growing, in place.
  check('grow: cleanse recoils the patch first',
    f.cleanseAt(600, 500, 1e9) === 1 && f.sources[0].state === 'recede');
  check('grow: revives the recoiling patch in place (the un-cleanse)',
    f.growCreepAt(def, 600, 500, 90) === 1 && f.sources[0].state === 'grow' && f.sources.length === 1);

  // PAST the claim radius, fresh ground plants fresh skin.
  check('grow: past r the ground is unclaimed (plants a second)',
    f.growCreepAt(def, 1400, 500, 90) === 1 && f.sources.length === 2);

  // A DEAD HEART neither revives nor claims: the pox jumps to the fresh
  // corpse right beside the letting-go skin.
  const heart = { dead: false };
  check('grow: boundTo rides the opts through (the credit contract)',
    f.growCreepAt(def, 600, 1500, 90, { bornFrac: 1, boundTo: heart }) === 1);
  heart.dead = true;
  tick(1); // the bound watcher flips the patch to recede
  const bound = f.sources.find(s => s.boundTo === heart);
  check('grow: a dead heart recoils', bound?.state === 'recede');
  const before = f.sources.length;
  check('grow: a dead heart neither revives nor claims (plants beside it)',
    f.growCreepAt(def, 600, 1500, 90) === 1 && f.sources.length === before + 1 && bound?.state === 'recede');

  // A SPENT FINITE RUN is the other irrevocable recoil.
  const boltDef = CREEPS['probe_grow_bolt'];
  const bolt = f.addFront(boltDef, 500, 900, 0, { bornFrac: 1 })!;
  tick(10); // 300 u/s crosses the rolled 10-unit range inside a few frames
  check('grow: a spent run recoils where it stands',
    bolt.state === 'recede' && bolt.front!.traveled >= bolt.front!.rangeMax);
  const n2 = f.sources.length;
  check('grow: a spent run neither revives nor claims',
    f.growCreepAt(boltDef, bolt.pos.x, bolt.pos.y, 90) === 1
    && bolt.state === 'recede' && f.sources.length === n2 + 1);

  // THE ARRIVAL LINE: once per visit, on the kind's first patch only.
  registerCreep({ id: 'probe_grow_loud', reach: [60, 60], spread: 30 });
  const loud = CREEPS['probe_grow_loud'];
  let lines = 0;
  const f2 = new CreepField(new Rng(0x51de), 2000, 2000);
  f2.setTerrain({
    groundKindAt: () => null, eachFuelNear: () => {}, consume: () => {},
    stamp: () => {}, drag: () => {}, drown: () => {},
    announce: () => { lines++; },
  });
  const say = { announce: { text: 'the rot arrives!' } };
  f2.growCreepAt(loud, 300, 300, 80, say);
  check('grow: the arrival line prints on the kind\'s first patch', lines === 1);
  f2.growCreepAt(loud, 900, 300, 80, say);
  check('grow: later plants are quiet growth (once per visit)', lines === 1);
  f2.cleanseAt(300, 300, 40);
  f2.growCreepAt(loud, 300, 300, 80, say);
  check('grow: a revive never announces', lines === 1);

  // THE KIND-SCOPED CLEANSE (the grow verb's twin dial): a named cure
  // purges its own skin and leaves the land's alone.
  const f3 = new CreepField(new Rng(0xc1ea), 2000, 2000);
  f3.growCreepAt(def, 500, 500, 90);
  f3.addSource(CREEPS['caulflesh'], 560, 500, { bornFrac: 1, ambient: true });
  check('cleanse: a kind-named purge recoils only its own skin',
    f3.cleanseAt(500, 500, 1e9, 'probe_grow') === 1
    && f3.sources.every(s => (s.def.id === 'probe_grow') === (s.state === 'recede')));
  check('cleanse: the kind-blind sweep still purges everything (the classic verb)',
    f3.cleanseAt(500, 500, 1e9) === 1 && f3.sources.every(s => s.state === 'recede'));

  // SATURATION: past the source cap the grow refuses politely, like addSource.
  const f4 = new CreepField(new Rng(0x0ca9), 4000, 4000);
  let planted = 0;
  while (f4.addSource(def, 100 + (planted % 40) * 90, 100 + Math.floor(planted / 40) * 90, { bornFrac: 1 })) planted++;
  check('grow: at the source cap the refusal is polite (returns 0)',
    planted === CREEP_CFG.maxSources && f4.growCreepAt(def, 3500, 3500, 50) === 0
    && f4.sources.length === CREEP_CFG.maxSources);

  // THE ENSURE COMPOSITION (the KillCtx binding's shape): a bare world
  // builds its field on demand and the grown skin is live ground.
  const world = makeSimWorld('warrior', 77031);
  const wf = world.creepEnsure()!;
  check('grow: creepEnsure + grow composes on a bare world',
    wf.growCreepAt(def, 700, 700, 90, { bornFrac: 1 }) === 1);
  check('grow: the grown skin is the hit surface (drawn == tested)', wf.onCreep(700, 700));
}

// --- 17) THE POXROT: the Contagion's own carried ground --------------------
// The first world-event package to OWN a creep kind. The def registers from
// src/packages/defs/contagion.ts, which reaches this process through the sim
// boot's own chain (arena → manifest → registry → package defs) — this
// census breaks LOUD if that import set ever drops the package defs.
{
  const pox = CREEPS['poxrot'];
  check('poxrot: registered by the Contagion package (the sim import chain holds)', !!pox);
  if (pox) {
    const g = pox.grants?.[0];
    check('poxrot: one grant — the gutworks sour ladder vs everyone but the plague',
      pox.grants?.length === 1 && g?.status === 'queasy'
      && !!g?.notFactions?.includes('plague') && !g?.factions && !g?.teams);
    check('poxrot: the stacking grant rides its own cadence, not the apply sweep',
      (g?.every ?? 0) > CREEP_CFG.applyEvery, `every ${g?.every}, sweep ${CREEP_CFG.applyEvery}`);
    check('poxrot: wears the plague hue (the one-hue law)', pox.glow === '#8fd24a');
    check('poxrot: anchored membrane, no front levers (kill-grown pockets, never waves)', !pox.front);
  }
  // THE PACKAGE-ONLY LAW: no tileset theme (base or variant, kinds or
  // fronts) grows the pox — the kind exists only where the plague's dead
  // fell. The registry is pure data, so a stringify scan is total.
  check('poxrot: no theme grows it (package-carried ground only)',
    !JSON.stringify(TILESETS).includes('poxrot'));
  // The kill rows stand: the grow payoff and the source's fall (whose
  // teardown carries the kind-scoped cleanse — rig 16 proves the mechanism).
  const ids = killRules().map(r => r.id);
  check('poxrot: the pox-underfoot grow row is registered', ids.includes('plague_pox_ground'));
  check('poxrot: patient zero\'s bounty row stands beside it', ids.includes('patient_zero'));

  // LIVE FILTERING + THE CADENCE at the field grain: the intruder sickens
  // on the grant's own clock; the Plaguebound wade their garden freely.
  if (pox) {
    const f = new CreepField(new Rng(0x90c5), 2000, 2000);
    f.addSource(pox, 800, 800, { bornFrac: 1 });
    const seen: Record<string, number> = {};
    const mk = (team: string, faction?: string) => ({
      pos: { x: 800, y: 800 }, radius: 12, dead: false, team,
      ...(faction ? { faction } : {}),
      applyStatus: (id: string) => { seen[`${team}:${id}`] = (seen[`${team}:${id}`] ?? 0) + 1; },
    });
    const intruder = mk('player');
    const plagueborn = mk('enemy', 'plague');
    let tq = 0;
    for (let i = 0; i < 7; i++) { tq += 0.3; f.update(0.3, tq, [intruder, plagueborn]); }
    check('poxrot: the intruder climbs the sour ladder on the grant\'s cadence',
      seen['player:queasy'] === 2,
      `${seen['player:queasy'] ?? 0} applications over 2.1s (want 2 at every 1.8, not 7 at the sweep)`);
    check('poxrot: the plague wades its own garden untaxed', !seen['enemy:queasy']);
    // THE TEARDOWN MECHANISM: the kind-named cure empties the field whole —
    // borrowed ground un-writes, no scar (the patient-zero row's exact call).
    f.cleanseAt(800, 800, 1e9, 'poxrot');
    const dtq = 1 / 60;
    let tr = tq;
    for (let i = 0; i < 60 * 4; i++) { tr += dtq; f.update(dtq, tr, []); }
    check('poxrot: cleansed skin recoils to nothing (borrowed weather, no scar)',
      f.sources.length === 0);
  }
}

// --- 18) THE LANDSLIDE ANNOUNCE: the authored mountain lanes speak ---------
// Backlog #62. Three shipped mountain faces (overpass, snowcrown, stonecrown)
// author `announce: { text: 'the mountainside lets go!' }` on their ungated
// landslide span lanes, and snowcrown appends a snow-gated avalanche SIBLING
// (the same 'landslide' kind wearing its OWN line) — the fire site
// (spawnWave: `fielded > 0 && row.announce`) was live but only ever probed
// through section 12's SYNTHETIC row. These checks drive the REAL rows, read
// off TILESETS and installed VERBATIM (drawn == tested: re-wording or
// dropping an announce in tilesets.ts breaks this section — the expected
// lines are pinned below as literals, while the emission itself rides the
// authored row through the real machinery; the stub's sky always says yes,
// so the snow gate opens — gate behavior is section 14's subject, not ours).
// THE SEED LAW: installLanes rolls a row's `chance` as the field stream's
// FIRST draw, so one pinned seed whose first draw clears the meanest
// authored chance (0.55) admits every lane deterministically — and rolled
// delays are bounded by the row's own [lo, hi], so ticking past hi can
// never flake. Seed 7's first draw is 0.0117.
{
  const SLIDE_LINE = 'the mountainside lets go!';
  const AVALANCHE_LINE = 'the crown sheds: avalanche!';
  const slideRows: { home: string; row: FrontSpawnRow }[] = [];
  for (const [home, ts] of Object.entries(TILESETS)) {
    for (const row of ts.theme.creep?.fronts ?? []) {
      if (row.id === 'landslide') slideRows.push({ home, row });
    }
  }
  // Partition STRUCTURALLY (by the sky gate, never by text): the ungated
  // rows are the mountainside fixtures, the when-gated one is snowcrown's
  // avalanche — so a re-worded row stays in its partition and fails its
  // pin instead of silently migrating out of the driven set.
  const mountainRows = slideRows.filter(r => !r.row.when);
  const gatedRows = slideRows.filter(r => !!r.row.when);
  check('slide census: three mountain faces field the ungated landslide lane',
    mountainRows.length >= 3, mountainRows.map(r => r.home).join(',') || 'none');
  check('slide census: every ungated lane wears the one authored line',
    mountainRows.length > 0 && mountainRows.every(r => r.row.announce?.text === SLIDE_LINE),
    mountainRows.map(r => `${r.home}: '${r.row.announce?.text ?? 'SILENT'}'`).join(' | '));
  check('slide census: the snow-gated avalanche sibling wears its OWN line',
    gatedRows.length === 1 && gatedRows[0].row.announce?.text === AVALANCHE_LINE
    && gatedRows[0].row.when?.weather !== undefined,
    gatedRows.map(r => `${r.home}: '${r.row.announce?.text ?? 'SILENT'}'`).join(' | ') || 'none');
  check('slide census: no landslide lane anywhere is silent (future shirkers get named)',
    slideRows.every(r => !!r.row.announce?.text),
    slideRows.map(r => `${r.home}${r.row.when ? ' (gated)' : ''}`).join(','));
  // The walk reads base themes; the stringify counts prove it TOTAL — no
  // variant or future row hides either line where the walk can't see (the
  // poxrot scan idiom).
  const reg = JSON.stringify(TILESETS);
  check('slide census: the base-theme walk is total (stringify agrees, both lines)',
    reg.split(SLIDE_LINE).length - 1
      === mountainRows.filter(r => r.row.announce?.text === SLIDE_LINE).length
    && reg.split(AVALANCHE_LINE).length - 1
      === gatedRows.filter(r => r.row.announce?.text === AVALANCHE_LINE).length,
    `${reg.split(SLIDE_LINE).length - 1}+${reg.split(AVALANCHE_LINE).length - 1} in the registry vs `
    + `${mountainRows.length}+${gatedRows.length} walked`);

  const SLIDE_SEED = 7; // first draw 0.0117 — clears every authored chance
  const mkSlideField = (): { f: CreepField; seen: [string, string | undefined][] } => {
    const f = new CreepField(new Rng(SLIDE_SEED), 1600, 1200);
    const seen: [string, string | undefined][] = [];
    f.setTerrain({
      groundKindAt: () => null,
      eachFuelNear: () => {},
      consume: () => {},
      stamp: () => {},
      drag: () => {},
      drown: () => {},
      condHeld: () => true, // the sky always says yes — the snow gate opens
      announce: (text, color) => seen.push([text, color]),
    });
    return { f, seen };
  };
  const dt = 0.25;

  // (a) EXACTLY ONE LINE PER FIELDING WAVE, for every authored row — the
  // avalanche included (under the stub's held sky it fields like any
  // other) — text pinned per partition, color exactly as the row wires it.
  for (const { home, row } of slideRows) {
    const label = row.when ? `${home} avalanche` : home;
    const want = row.when ? AVALANCHE_LINE : SLIDE_LINE;
    const { f, seen } = mkSlideField();
    f.installLanes([row]);
    check(`slide: the ${label} lane is admitted under its authored chance (the seed law)`,
      f.laneCount() === 1, `chance ${row.chance ?? 'fixture'}`);
    let t = 0;
    const hi = (row.delay ?? CREEP_CFG.front.delay)[1] + 6;
    while (seen.length === 0 && t < hi) { t += dt; f.update(dt, t, []); }
    const fieldedAt = f.sources.filter(s => s.front).length;
    for (let i = 0; i < 12; i++) { t += dt; f.update(dt, t, []); } // grace: the march never re-announces
    check(`slide: the ${label} wave speaks the authored line EXACTLY once as it fields`,
      seen.length === 1 && seen[0][0] === want && seen[0][1] === row.announce?.color && fieldedAt > 0,
      `${seen.length} line(s) by ${t.toFixed(1)}s, ${fieldedAt} sections — `
      + (seen.map(s => `'${s[0]}'/${s[1]}`).join('|') || 'silence'));
  }

  // PER WAVE means per wave: gutter the first wave (the section-6 idiom) and
  // the lane's return on its own `waves` clock speaks AGAIN — one line each.
  {
    const { home, row } = mountainRows[0];
    const { f, seen } = mkSlideField();
    f.installLanes([row]);
    let t = 0;
    const hi = (row.delay ?? CREEP_CFG.front.delay)[1] + 6;
    while (seen.length === 0 && t < hi) { t += dt; f.update(dt, t, []); }
    f.cleanseAt(0, 0, 1e9);
    const cap = t + (row.waves ?? [0, 0])[1] + 40;
    while (seen.length < 2 && t < cap) { t += dt; f.update(dt, t, []); }
    check(`slide: the ${home} lane's RETURNING wave re-announces (one line per wave)`,
      seen.length === 2 && seen.every(s => s[0] === SLIDE_LINE),
      `${seen.length} line(s) by ${t.toFixed(0)}s (waves ${row.waves?.join('-') ?? 'none'})`);
  }

  // (b) A WAVE THE CAP REFUSES WHOLE IS SILENT — and the lane still owes
  // its return: gutter the squatters and the NEXT wave finally speaks (the
  // silence was the `fielded > 0` gate, never a dead collector).
  {
    const { home, row } = mountainRows[0];
    const { f, seen } = mkSlideField();
    f.installLanes([row]); // chance + delay bank as draws 1-2 (the seed law)
    let squat = 0;
    while (f.addSource(CREEPS['landslide'], 40 + (squat % 24) * 60, 40 + Math.floor(squat / 24) * 60,
      { reach: 20, bornFrac: 1 })) squat++;
    check('slide: the squat saturated the field to the source cap',
      squat === CREEP_CFG.maxSources, `${squat} of ${CREEP_CFG.maxSources}`);
    let t = 0;
    const quiet = (row.delay ?? CREEP_CFG.front.delay)[1] + 8;
    while (t < quiet) { t += dt; f.update(dt, t, []); }
    check(`slide: the ${home} wave refused WHOLE at the cap stays silent (fielded 0)`,
      seen.length === 0 && !f.sources.some(s => s.front) && f.sources.length === CREEP_CFG.maxSources,
      `${seen.length} line(s), ${f.sources.length} sources by ${t.toFixed(0)}s`);
    f.cleanseAt(0, 0, 1e9);
    const cap = t + (row.waves ?? [0, 0])[1] + 40;
    while (seen.length === 0 && t < cap) { t += dt; f.update(dt, t, []); }
    check('slide: the refused lane still owed its wave — space freed, it SPEAKS',
      seen.length === 1 && seen[0][0] === SLIDE_LINE && f.sources.some(s => s.front),
      `${seen.length} line(s) by ${t.toFixed(0)}s`);
  }
}

console.log(failed ? `\n${failed} CHECK(S) FAILED` : '\nALL FRONT CHECKS PASSED');
process.exit(failed ? 1 : 0);
