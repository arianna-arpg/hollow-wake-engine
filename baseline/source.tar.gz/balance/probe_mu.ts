// ---------------------------------------------------------------------------
// ONE-OFF PROBE — THE MU HUB (data/mu.ts + the 'mu' scene stage in
// engine/scenes.ts) on the real engine, headless. Pins the fabric's laws:
//   • THE TRANSIENT GATE — the standalone MU_SCENE stamps NOTHING (no
//     begun-mark, no completion key) and is re-enterable; sealed, boundless,
//     off-graph, empty-field like every scene ground.
//   • THE WISP — the hero stands guarded, kitless, small, and ethereal; the
//     HUD veil is up; nothing is ever restored (the pick rebuilds the world).
//   • THE CAST SEAL — the ground answers no button (ZoneDef.castSeal, the
//     one read World.castSealed); carve-outs by id / tag / registered law
//     are rows, the hard lock, binds, the spoken line, the lint.
//   • THE HAND LAW — apparitions mirror the class screen's economy exactly:
//     dealt hand AWAKE (selectableSlotCount from the unlocked pool), the
//     unlocked remainder VEILED (named, refusing), the locked remainder as
//     capped FAINT unknown cowls (nameless — the discovery web keeps its
//     secrets); all passive + invulnerable + untargetable scenery.
//   • THE DWELL LATCH — a still linger by an awake vessel posts THAT class's
//     request once (consumed until step-out; step-out re-arms); veiled and
//     faint vessels refuse and post nothing.
//   • THE AGENCY RECKONING (the prologue's rewritten fall) — no hold, the
//     mark chevron, the ten-breath cast, interrupt re-arm (delay never
//     denial), the mercy floor, and the fall INTO Mu with the completion
//     key stamped at the threshold.
// Run: npx tsx balance/probe_mu.ts
// ---------------------------------------------------------------------------

import { bootSimEngine, makeSimWorld } from '../src/sim/arena';
import {
  sceneBegin, sceneBegunKey, sceneCardAck, sceneDue, muStageLive, muTakeClassRequest,
} from '../src/engine/scenes';
import { MU_SCENE, MU_CFG, APPARITION_PREFIX, APPARITION_UNKNOWN_ID, apparitionDefId } from '../src/data/mu';
import { PROLOGUE_SCENE, type SceneReckoningStage, type SceneClashStage, type SceneAssaultStage } from '../src/data/scenes';
import {
  TUTORIAL_FACTIONS, LEDGER_TUTORIAL_FACTION_PREFIX, tutorialFactionKey, tutorialFactionOf,
  rollTutorialFaction, prologueForFaction,
} from '../src/data/commanders';
import { CLASSES } from '../src/data/classes';
import { MONSTERS } from '../src/data/monsters';
import { SKILLS } from '../src/data/skills';
import { BAR_SLOTS, makeSkillInstance } from '../src/engine/skills';
import { registerCastLaw, castSealIssues } from '../src/engine/castseal'; // THE CAST SEAL (B7-B19)
import { TILESETS } from '../src/data/tilesets';
import { QUESTS } from '../src/quests/defs';
import { revengeCullId, revengeCommanderId, revengeTrailKey } from '../src/quests/revenge';
import { selectableSlotCount } from '../src/meta/account';
import { collectAttention } from '../src/world/attention';
import type { World } from '../src/engine/world';
import type { Actor } from '../src/engine/actor';
import { angleDiff } from '../src/core/math';
import { runMuReliquaryChecks } from './muReliquaryChecks';

let failed = 0;
const check = (name: string, ok: boolean, detail = ''): void => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`);
  if (!ok) failed++;
};

const DT = 1 / 60;
const step = (w: World, s: number): void => {
  for (let t = 0; t < s; t += DT) w.update(DT);
};
const until = (w: World, cond: () => boolean, maxSec: number): boolean => {
  for (let t = 0; t < maxSec; t += DT) {
    if (cond()) return true;
    w.update(DT);
  }
  return cond();
};
const apparitionsOf = (w: World): Actor[] =>
  w.actors.filter(a => !!a.defId
    && (a.defId.startsWith(APPARITION_PREFIX) || a.defId === APPARITION_UNKNOWN_ID));
const rankOf = (a: Actor): 'awake' | 'veiled' | 'faint' =>
  a.statuses.some(s => s.id === 'mu_faint') ? 'faint'
    : a.statuses.some(s => s.id === 'mu_veiled') ? 'veiled' : 'awake';

bootSimEngine();

// === A) THE TRANSIENT GATE ===================================================
// A graduated account with a LOCKED remainder: keep 6 classes unlocked so all
// three ranks stand (hand 3 / veiled 3 / faint = min(cap, the rest)).
const w = makeSimWorld('warrior', 47001);
w.account.ledger[PROLOGUE_SCENE.ledger] = 1; // a veteran: the tutorial is behind
const keep = new Set(CLASSES.slice(0, 6).map(c => c.id));
for (const id of [...w.account.unlockedClasses]) {
  if (!keep.has(id)) w.account.unlockedClasses.delete(id);
}
const pendingClass = CLASSES[6];
w.account.unlockedClasses.add(pendingClass.id);
w.account.pendingClassUnlocks.add(pendingClass.id);
const p = w.player;
const heroLook = p.look;
check('A1: the standalone hub scene takes', sceneBegin(w, 'mu'));
check('A2: TRANSIENT stamps NOTHING — no begun-mark, no completion key',
  !(w.account.ledger[sceneBegunKey(MU_SCENE)] ?? 0)
  && !(w.account.ledger[MU_SCENE.ledger] ?? 0));
check('A3: sceneDue never applies to a transient scene', !sceneDue(w.account, 'mu'));
check('A4: Mu is CURRENT and OFF-GRAPH (caveMap, not the graph)',
  w.zone.id === 'scene_mu' && !!w.caveMap['scene_mu'] && !w.zoneMap['scene_mu']);
check('A5: the ground is sealed — spoils none, no packs, no exits, boundless',
  w.zone.spoils === 'none' && w.zone.packDensity === 0
  && w.zone.exits.length === 0 && w.arena.boundless === true);
check('A6: the mu stage is LIVE and never a completed scene', muStageLive(w));

// === B) THE WISP =============================================================
step(w, 0.3);
check('B1: the hero stands as the wisp — look swapped, small, pale',
  p.look === MU_CFG.wisp.look && p.radius === MU_CFG.wisp.radius && p.look !== heroLook);
check('B2: guarded whole — invulnerable, untargetable, vitals full',
  p.invulnerable && p.untargetable && p.life === p.maxLife());
check('B3: kitless — every bar slot stripped', p.skills.every(s => s === null));
check('B4: THE HUD VEIL is up', w.scene?.hudVeil === true);
check('B5: the prompt speaks the hub', w.scene?.prompt === MU_CFG.prompt);
// THE PANEL SEAL (her lever, 2026-09-11): the hub's listed hero pages read
// sealed through the ONE predicate the toggles and the tray share — the
// seal's own line as the why — and nothing unlisted does.
const sealIds = MU_CFG.sealPanels.ids as readonly string[];
check('B6: THE PANEL SEAL holds the listed pages shut with the hub\'s line, and nothing else',
  sealIds.length > 0 && sealIds.every(id => w.panelSealed(id) === MU_CFG.sealPanels.line)
  && w.panelSealed('zz_unlisted') === null
  && (sealIds.includes('character') || w.panelSealed('character') === null));
check('B6b: the seal names the bag (the provisional class beneath the wisp is no build to unlearn)', sealIds.includes('inventory'));

// THE CAST SEAL (her ask 2026-09-16 — the wisp swung THE UNARMED FLOOR in
// Mu: a fine byproduct of the one pipeline that implies there is something
// to DO here besides choose). ZoneDef.castSeal is the ground's law,
// engine/castseal.ts its open vocabulary, World.castSealed the ONE read
// the press, the bar, the AI, the trigger artery and the replenishment
// sweep share. Every carve-out below is a ROW, never a code path.
{
  const seal0 = w.zone.castSeal;
  const improvised = makeSkillInstance(SKILLS['improvised_strike']!, 1);
  const spellDef = Object.values(SKILLS).find(s => (s.tags ?? []).includes('spell') && !(s.tags ?? []).includes('attack'))!;
  const spell = makeSkillInstance(spellDef, 1);
  const press = (slot = 0): boolean => {
    const held = Array(BAR_SLOTS).fill(false) as boolean[];
    const edge = Array(BAR_SLOTS).fill(false) as boolean[];
    held[slot] = true; edge[slot] = true;
    const before = w.scene!.casts;
    w.applyInputs(new Map([['p0', { dx: 0, dy: 0, aim: { x: p.pos.x + 40, y: p.pos.y }, held, edge }]]), DT);
    const cast = w.scene!.casts > before || !!p.casting;
    p.casting = null; p.useLock = 0; // clear the swing so the next press judges fresh
    return cast;
  };
  const acted0 = w.localSeat.lastActedAt, texts0 = w.texts.length;
  check("B7: Mu's ground wears the seal WHOLE and SILENT (MU_ZONE.castSeal via sealStageZone)",
    !!seal0 && (seal0.mode ?? 'shut') === 'shut' && !seal0.open && !seal0.shut && !seal0.line);
  check('B8: an empty-slot press casts NOTHING — the unarmed floor is sealed at the door', !press());
  check('B9: the sealed press is silent and interrupts no dwell (it sits before markSeatActed)',
    w.texts.length === texts0 && w.localSeat.lastActedAt === acted0);
  check('B10: World.castSealed is the ONE read — the floor reads sealed; the bar (skillUsable) and the AI (pressUsable) say no',
    w.castSealed(p, improvised) === seal0 && !w.skillUsable(p, improvised) && !w.pressUsable(p, improvised));
  w.zone.castSeal = { mode: 'shut', open: { ids: ['improvised_strike'] } };
  check('B11: an OPEN row by skill id lets that cast through (the future "certain casts eligible" lever)',
    w.castSealed(p, improvised) === null && press());
  w.zone.castSeal = { mode: 'shut', open: { tags: ['attack'] } };
  check('B12: an OPEN row by TAG opens the family and only the family',
    w.castSealed(p, improvised) === null && w.castSealed(p, spell) !== null);
  let armed = false;
  registerCastLaw('probe:wisp', ctx => armed && ctx.caster === w.player);
  w.zone.castSeal = { mode: 'shut', open: { laws: ['probe:wisp'] } };
  const shutWhileDisarmed = w.castSealed(p, improvised) !== null;
  armed = true;
  check('B13: an OPEN row by a registered LAW opens on a LIVE predicate (dynamic by construction)',
    shutWhileDisarmed && w.castSealed(p, improvised) === null);
  w.zone.castSeal = { mode: 'open', shut: { tags: ['attack'] } };
  check('B14: an OPEN ground seals only what its shut row names',
    w.castSealed(p, improvised) !== null && w.castSealed(p, spell) === null);
  w.zone.castSeal = { mode: 'shut', open: { ids: ['improvised_strike'] }, shut: { tags: ['attack'] } };
  check('B15: THE HARD LOCK — a shut row beats an open row that also matches', w.castSealed(p, improvised) !== null);
  w.zone.castSeal = { mode: 'shut', binds: 'seats' };
  const vessel = apparitionsOf(w)[0]!;
  check('B16: binds seats — a seatless body stands outside the seal, the wisp inside it',
    w.castSealed(vessel, improvised) === null && w.castSealed(p, improvised) !== null);
  w.zone.castSeal = { mode: 'shut', line: 'the void does not answer' };
  press();
  check('B17: an authored line speaks the refusal through the rate-limited failNote lane',
    w.texts.some(t => t.text === 'the void does not answer'));
  w.zone.castSeal = seal0;
  check('B18: the authored seal restored — sealed again', !press() && w.castSealed(p, improvised) === seal0);
  check('B19: castSealIssues names an unknown skill id and an unregistered law, and clears the authored seal',
    castSealIssues({ open: { ids: ['zz_nope'], laws: ['zz_law'] } }, id => !!SKILLS[id]).length === 2
    && castSealIssues(seal0!, id => !!SKILLS[id]).length === 0);
}

// === C) THE HAND LAW =========================================================
const apps = apparitionsOf(w);
const awake = apps.filter(a => rankOf(a) === 'awake');
const veiled = apps.filter(a => rankOf(a) === 'veiled');
const faint = apps.filter(a => rankOf(a) === 'faint');
const pool = CLASSES.filter(c => w.account.unlockedClasses.has(c.id));
check('C1: the dealt hand stands AWAKE (the class screen\'s own hand size)',
  awake.length === Math.min(selectableSlotCount(w.account), pool.length),
  `awake=${awake.length}`);
check('C2: the unlocked remainder stands VEILED',
  veiled.length === pool.length - awake.length, `veiled=${veiled.length}`);
check('C3: the locked remainder is FAINT unknown cowls, capped',
  faint.length === Math.min(MU_CFG.faintCap, CLASSES.length - pool.length)
  && faint.every(a => a.defId === APPARITION_UNKNOWN_ID),
  `faint=${faint.length}`);
check('C4: every vessel is guarded scenery on the player team',
  apps.length > 0 && apps.every(a => a.invulnerable && a.untargetable && a.team === 'player'));
check('C5: awake + veiled wear their CLASS\'s own face (def per class)',
  [...awake, ...veiled].every(a => pool.some(c => apparitionDefId(c.id) === a.defId)));
check('C6: the unknown cowls are NAMELESS (no npcRole — no nameplate to leak)',
  faint.every(a => a.defId === APPARITION_UNKNOWN_ID));
check('C6b: a pending discovery stands as its own named background vessel, never awake',
  veiled.some(a => a.defId === apparitionDefId(pendingClass.id) && a.name === pendingClass.name)
  && !awake.some(a => a.defId === apparitionDefId(pendingClass.id)));
// THE GAZE (2026-09-11, her word: the vessels stood facing east — they
// should look AT the wisp that will inhabit them): every apparition is born
// facing its mark (the live wisp by default) and FOLLOWS a drifting wisp at
// MU_CFG.gaze.turnRate — a swing per frame, never a snap — until it settles.
{
  const bearing = (a: Actor): number => Math.atan2(p.pos.y - a.pos.y, p.pos.x - a.pos.x);
  const off = (a: number, b: number): number => Math.abs(angleDiff(a, b));
  const worst = (): number => Math.max(...apps.map(a => off(a.facing, bearing(a))));
  check('C7: every vessel is BORN looking at the wisp (MU_CFG.gaze.at = wisp)',
    MU_CFG.gaze.at === 'wisp' && apps.length > 0 && worst() < 0.02, `worst off=${worst().toFixed(3)}`);
  const hx = p.pos.x, hy = p.pos.y;
  const before = apps.map(a => a.facing);
  p.pos.x = hx + 320; p.pos.y = hy + 260; // a drift well inside the wrap
  w.update(DT);
  const perFrame = apps.map((a, i) => off(before[i]!, a.facing));
  check('C8: THE GAZE SWINGS — one frame turns a vessel by at most turnRate × dt, never a snap',
    perFrame.every(d => d <= MU_CFG.gaze.turnRate * DT + 1e-6) && perFrame.some(d => d > 1e-4),
    `max/frame=${Math.max(...perFrame).toFixed(4)} cap=${(MU_CFG.gaze.turnRate * DT).toFixed(4)}`);
  step(w, 3);
  check('C9: …and SETTLES on the wisp where it now stands (every vessel, within a hair)',
    worst() < 0.02, `worst off=${worst().toFixed(3)}`);
  p.pos.x = hx; p.pos.y = hy;
  step(w, 3);
}

// === D) THE DWELL LATCH ======================================================
{
  const v = awake[0];
  p.pos.x = v.pos.x; p.pos.y = v.pos.y + v.radius + 8;
  step(w, MU_CFG.dwell.sec + 0.6);
  const req = muTakeClassRequest(w);
  check('D1: the still linger posts THAT class\'s request',
    req !== null && apparitionDefId(req) === v.defId, `req=${req}`);
  check('D2: the request is consumed whole (no double card)',
    muTakeClassRequest(w) === null);
  step(w, MU_CFG.dwell.sec + 0.6);
  check('D3: the latch stays consumed while standing (a closed card never re-pops in place)',
    muTakeClassRequest(w) === null);
  // Step out, come back: the latch re-arms (the Dwell law's step-out).
  p.pos.x = v.pos.x + 400; p.pos.y = v.pos.y + 400;
  step(w, 0.3);
  p.pos.x = v.pos.x; p.pos.y = v.pos.y + v.radius + 8;
  step(w, MU_CFG.dwell.sec + 0.6);
  check('D4: step-out re-arms — the next linger asks again',
    muTakeClassRequest(w) !== null);
}

// === E) THE REFUSALS =========================================================
{
  const pending = veiled.find(a => a.defId === apparitionDefId(pendingClass.id))!;
  p.pos.x = pending.pos.x; p.pos.y = pending.pos.y + pending.radius + 8;
  step(w, MU_CFG.dwell.sec + 0.8);
  check('E0: a discovered class refuses selection and points to its Vault unlock',
    muTakeClassRequest(w) === null && w.scene!.prompt === MU_CFG.pendingLine && w.scene!.bar === null);
  const v = veiled[0];
  p.pos.x = v.pos.x; p.pos.y = v.pos.y + v.radius + 8;
  step(w, MU_CFG.dwell.sec + 0.8);
  check('E1: a VEILED vessel posts nothing (not this waking)',
    muTakeClassRequest(w) === null);
  const f = faint[0];
  if (f) {
    p.pos.x = f.pos.x; p.pos.y = f.pos.y + f.radius + 8;
    step(w, MU_CFG.dwell.sec + 0.8);
    check('E2: a FAINT cowl posts nothing (a shape not yet earned)',
      muTakeClassRequest(w) === null);
  }
}

// === F) THE AGENCY RECKONING (the prologue's rewritten fall) =================
{
  const v = makeSimWorld('warrior', 47002);
  const vp = v.player;
  check('F0: the virgin sim account is due the prologue', sceneDue(v.account, 'prologue'));
  check('F0b: the prologue begins', sceneBegin(v, 'prologue'));
  // Jump the director straight to the reckoning (the walk itself is
  // probe_scenes.ts's law — this rig owns the fall's mechanics).
  const sc = v.scene!;
  const ix = sc.def.stages.findIndex(s => s.kind === 'reckoning');
  check('F1: the prologue still ends through a reckoning', ix >= 0);
  sc.stageIx = ix;
  sc.begun = false;
  sc.fadeTarget = 0;
  v.screenFade = 0;
  step(v, 0.2);
  const spec = sc.def.stages[ix] as { def: string; verb: string; graceSec: number; floorFrac: number };
  const col = v.actors.find(a => a.defId === spec.def);
  check('F2: the commander stands — and the world is NOT held (agency, not cinema)',
    !!col && !v.timeflow.heldBy('cinematic') && sc.focus === null);
  check('F3: THE MARK — the attention chevron names him',
    sc.mark?.id === col?.id && collectAttention(v).some(pt => pt.id === 'scene_mark'));
  // THE TEMPTATION: park the hero inside the verb's ai range so a leaky
  // picker WOULD freelance the muster (the QA'd strand) — the ban must
  // bind the ordinary picker, and only the director may order the verb.
  vp.pos.x = col!.pos.x + 200;
  vp.pos.y = col!.pos.y + 120;
  // THE CLOCK YIELDS: pre-stamp the verb's actor-side cooldown — the
  // director's order must clear it (no stamped clock refuses the beat).
  col!.cooldowns.set(spec.verb, 45);
  col!.cooldownTotals.set(spec.verb, 45);
  check('F4: after the grace beat the muster is a live TEN-second cast (through a pre-stamped clock)',
    until(v, () => !!col?.casting, spec.graceSec + 2)
    && (col?.casting?.total ?? 0) >= 9.5,
    `total=${col?.casting?.total?.toFixed(1)}`);
  check('F4b: THE BAN BINDS THE PICKER — the brain never pressed a banned verb itself',
    col!.aiLastSkill == null,
    `aiLast=${col!.aiLastSkill?.id ?? 'none'}`);
  // THE INTERRUPT RE-ARM: a stun wipes the cast (the engine's own law); the
  // director re-orders the muster once the body is free — delay, never denial.
  // Break the poise first: applyStatus shrugs hard CC by the poiseCcAvoid
  // ROLL while poise stands (that roll is the live game's own guard on this
  // very muster) — the rig pins the director's re-arm, not the dice.
  col!.poise = 0;
  col!.applyStatus('stun', 0, 1, 'probe');
  step(v, 0.15);
  check('F5: a stun truly interrupts the cast (the player\'s honest little victory)',
    col!.casting === null);
  check('F6: the muster RE-ARMS the moment the body is free',
    until(v, () => !!col?.casting, 3), `casting=${String(!!col?.casting)}`);
  // THE ENRAGE: below the floor the commander stays MORTAL — no immunity,
  // no refusal prints — he furies (the rally worn visibly) and the muster
  // surges to its last breaths. Show, never tell.
  col!.life = col!.maxLife() * spec.floorFrac * 0.5;
  step(v, 0.2);
  check('F7: THE ENRAGE — mortal below the floor, rally worn, the bar surged to its last breaths',
    col!.invulnerable === false
    && col!.statuses.some(s => s.id === 'rally')
    && ((col!.casting?.total ?? 0) - (col!.casting?.elapsed ?? 0)) <= 1.5,
    `left=${((col!.casting?.total ?? 0) - (col!.casting?.elapsed ?? 0)).toFixed(2)}s`);
  check('F8: the blast fells the hero through the covenant (never a death)',
    until(v, () => sc.fell && !vp.dead && vp.invulnerable, 14),
    `fell=${String(sc.fell)} dead=${String(vp.dead)}`);
  check('F9: the fall card follows, and the ack drifts into MU',
    until(v, () => v.scene?.card != null, 8));
  sceneCardAck(v);
  check('F10: the spirit arrives in Mu with the tutorial stamped LIVED at the threshold',
    until(v, () => v.zone.id === 'scene_mu' && muStageLive(v), 5)
    && (v.account.ledger[PROLOGUE_SCENE.ledger] ?? 0) >= 1
    && !sceneDue(v.account, 'prologue'));
  check('F11: the wisp stands among the vessels',
    vp.look === MU_CFG.wisp.look && apparitionsOf(v).length > 0);
}

// THE MECHANICS-BREAKER'S LANE ("haha, we thought of that"): a Father who is
// somehow truly finished mid-muster just fades the stage forward — the wake
// card and Mu follow as ever. No immunity, no refusal, and above all no lock.
{
  const k = makeSimWorld('warrior', 47006);
  sceneBegin(k, 'prologue');
  const sck = k.scene!;
  sck.stageIx = sck.def.stages.findIndex(s => s.kind === 'reckoning');
  sck.begun = false;
  sck.fadeTarget = 0;
  k.screenFade = 0;
  step(k, 0.3);
  const spec2 = sck.def.stages[sck.stageIx] as { def: string };
  const kc = k.actors.find(a => a.defId === spec2.def)!;
  kc.life = 0;
  k.kill(kc);
  step(k, 0.1);
  check('F11b: a dead commander still leaves a fallen hero, never a living victory',
    k.player.downed && k.player.life === 0 && sck.fell);
  check('F12: a truly dead Father fades forward — the wake follows, never a lock',
    until(k, () => k.scene?.card != null, 8));
  sceneCardAck(k);
  check('F13: …and Mu opens as ever behind it',
    until(k, () => k.zone.id === 'scene_mu' && muStageLive(k), 5));
}

// === I) THE GLOBE + THE YOUNG PROMPT =========================================
{
  const cx = w.arena.w / 2, cy = w.arena.h / 2;
  // Young: the fresh sim account has no completed runs — the drift
  // instruction speaks while nothing is engaged.
  p.pos.x = cx;
  p.pos.y = cy;
  step(w, 0.3);
  check('I1: a YOUNG account hears the drift instruction',
    w.scene?.prompt === MU_CFG.prompt);
  // THE GLOBE: walk out past the rim and the nothing WRAPS — the spirit
  // pops out the antipode, inbound, and the vessels come back to meet it.
  p.pos.x = cx + MU_CFG.wrap.radius + 60;
  p.pos.y = cy;
  step(w, 0.1);
  check('I2: past the rim the spirit pops out the antipode, headed home',
    p.pos.x < cx
    && Math.abs(Math.hypot(p.pos.x - cx, p.pos.y - cy) - MU_CFG.wrap.reentry) < 2,
    `x=${(p.pos.x - cx).toFixed(0)} d=${Math.hypot(p.pos.x - cx, p.pos.y - cy).toFixed(0)}`);
  // THE CONTINUOUS EYE: the wrap banks its whole displacement, so the
  // renderer's ambient parallax (cam − bank) never sees the jump — the
  // abyss flows through the seam without a residual shift.
  check('I2b: the wrap banks its displacement for the parallax strata (no seam in the deep field)',
    Math.abs(w.ambientCamShift.x + (MU_CFG.wrap.reentry + MU_CFG.wrap.radius + 60)) < 2
    && Math.abs(w.ambientCamShift.y) < 2,
    `bank=${w.ambientCamShift.x.toFixed(0)},${w.ambientCamShift.y.toFixed(0)}`);
  // A VETERAN account keeps the stillness — no standing instruction.
  w.account.runRecords.push({} as never, {} as never, {} as never);
  p.pos.x = cx;
  p.pos.y = cy;
  step(w, 0.3);
  check('I3: a VETERAN account keeps the stillness (no standing instruction)',
    w.scene?.prompt === null);
}

// === G) THE TUTORIAL FACTIONS (data/commanders.ts — the Fathers) =============
{
  // G1: table integrity — every row's bodies and verbs are REGISTERED, and
  // every commander is Ghorvane's true sibling: a voice part whose break
  // silences exactly the row's reckoning verb.
  let wired = true, voiced = true, tided = true;
  for (const row of TUTORIAL_FACTIONS) {
    const cmd = MONSTERS[row.commander];
    if (!cmd || !SKILLS[row.verb] || !MONSTERS[row.clash.def]) wired = false;
    if (!cmd?.skills.includes(row.verb)) wired = false;
    const voice = cmd?.parts?.some(p =>
      p.breakDisables?.includes(row.verb) && !!MONSTERS[p.monster]);
    if (!voice) voiced = false;
    for (const wave of row.waves) {
      for (const s of wave.spawns) if (!MONSTERS[s.def]) tided = false;
    }
    if (SKILLS[row.verb]?.useTime !== 10) wired = false;
  }
  check('G1: every legion is wired whole — commander, verb (ten breaths), clash, every wave body',
    wired, TUTORIAL_FACTIONS.map(r => r.id).join(','));
  check('G2: every Father carries a VOICE — the part whose break silences his reckoning',
    voiced);
  check('G3: every tide row names only registered kin', tided);
  // G4: the roll — deterministic per manifest, stamped once, recalled forever.
  const a = makeSimWorld('warrior', 47003);
  const b = makeSimWorld('warrior', 47003);
  const ra = rollTutorialFaction(a);
  const rb = rollTutorialFaction(b);
  check('G4: the roll is a pure function of the manifest seed', ra.id === rb.id, `roll=${ra.id}`);
  check('G5: the roll stamps the account (the tutorial_faction: presence key)',
    tutorialFactionOf(a.account.ledger) === ra.id
    && (a.account.ledger[tutorialFactionKey(ra.id)] ?? 0) >= 1);
  // The recall beats the dice: pre-stamp a DIFFERENT legion and the roll
  // must bow to it (an aborted tutorial replays the same war).
  const c = makeSimWorld('warrior', 47004);
  const other = TUTORIAL_FACTIONS.find(r => r.id !== rollTutorialFaction(makeSimWorld('warrior', 47004)).id)!;
  c.account.ledger[tutorialFactionKey(other.id)] = 1;
  check('G6: a standing stamp is RECALLED, never re-rolled',
    rollTutorialFaction(c).id === other.id);
  // G7: the resolve swaps fiction and war; mechanical lessons and Mu stay
  // the base def's rows byte-identically.
  const row = TUTORIAL_FACTIONS.find(r => r.id === 'demon')!;
  const eff = prologueForFaction(row);
  const kinds = eff.stages.map(s => s.kind);
  const clash = eff.stages.find(s => s.kind === 'clash') as SceneClashStage;
  const assault = eff.stages.find(s => s.kind === 'assault') as SceneAssaultStage;
  const reck = eff.stages.find(s => s.kind === 'reckoning') as SceneReckoningStage;
  check('G7: the resolve keeps the walk\'s shape (same stage kinds, same id + ledger)',
    kinds.join(',') === PROLOGUE_SCENE.stages.map(s => s.kind).join(',')
    && eff.id === PROLOGUE_SCENE.id && eff.ledger === PROLOGUE_SCENE.ledger);
  check('G8: the war stages wear the legion — clash, tide and reckoning all re-dressed',
    clash.spawns[0].def === row.clash.def && assault.rows === row.waves
    && reck.def === row.commander && reck.verb === row.verb
    && (reck.floorFrac ?? 0) > 0);
  check('G9: the untouched stages are the base rows THEMSELVES (no silent forks)',
    eff.stages[1] === PROLOGUE_SCENE.stages[1]
    && eff.stages[eff.stages.length - 1] === PROLOGUE_SCENE.stages[PROLOGUE_SCENE.stages.length - 1]);
  // G10: a live sceneBegin resolves — the runtime walks the ROLLED legion
  // (the seam is armed everywhere via the arena's census imports;
  // probe_scenes pins its own lane by pre-stamping the goblin recall).
  const v = makeSimWorld('warrior', 47005);
  sceneBegin(v, 'prologue');
  const lived = tutorialFactionOf(v.account.ledger);
  const vReck = v.scene!.def.stages.find(s => s.kind === 'reckoning') as SceneReckoningStage;
  check('G10: sceneBegin walks the rolled legion\'s reckoning',
    lived !== null && vReck.def === TUTORIAL_FACTIONS.find(r => r.id === lived)!.commander,
    `legion=${lived}`);
  check('G11: the prefix scan finds exactly one stamped legion',
    Object.keys(v.account.ledger).filter(k => k.startsWith(LEDGER_TUTORIAL_FACTION_PREFIX)).length === 1);
}

// === H) THE REVENGE CHAIN (quests/revenge.ts) ================================
{
  let wired = true, gated = true, chained = true;
  const mkCtx = (ledger: Record<string, number>) =>
    ({ classId: 'warrior', vocations: [] as string[], runLedger: {}, accountLedger: ledger });
  for (const row of TUTORIAL_FACTIONS) {
    const cull = QUESTS[revengeCullId(row.id)];
    const cmd = QUESTS[revengeCommanderId(row.id)];
    if (!cull || !cmd) { wired = false; continue; }
    // QuestZoneSpec.tileset is optional since the authored-map lane (a quest may name a map instead).
    if (!TILESETS[cull.zone.tileset ?? ''] || !TILESETS[cmd.zone.tileset ?? '']) wired = false;
    if (cmd.zone.objective.kind !== 'boss' || cmd.zone.objective.id !== row.commander) wired = false;
    if (!(cull.zone.packsOverride?.table.length ?? 0)) wired = false;
    // Odyssey gives the vendetta early; commander readiness stays in 12–15.
    if (cull.offerAtLevel !== 2 || cmd.offerAtLevel !== 2 || cmd.zone.level !== 13) wired = false;
    // THE CHAIN: the cull's field payout is the commander hunt's door.
    const trail = revengeTrailKey(row.id);
    if ((cull.reward.ledger?.[trail] ?? 0) < 1 || cmd.requiresLedger !== trail) chained = false;
    if (cull.turnIn || !cmd.turnIn) chained = false;
    // THE GATE: this legion's stamp lights exactly this chain…
    const stamped = mkCtx({ [tutorialFactionKey(row.id)]: 1 });
    if (!cull.gate?.(stamped) || !cmd.gate?.(stamped)) gated = false;
    // …and every OTHER legion's chain stays dark under it.
    for (const other of TUTORIAL_FACTIONS) {
      if (other.id === row.id) continue;
      if (QUESTS[revengeCullId(other.id)]?.gate?.(stamped)) gated = false;
    }
  }
  check('H1: every legion fields its whole chain — cull + commander hunt, real ground, real boss',
    wired);
  check('H2: THE GATE — the tutorial stamp lights exactly ONE legion\'s revenge', gated);
  check('H3: THE CHAIN — the cull pays the trail in the field; the hunt opens on it and turns in',
    chained);
  check('H4: an unstamped veteran gets the goblin canon (Ghorvane was always their opening)',
    QUESTS[revengeCullId('goblin')]?.gate?.(mkCtx({})) === true
    && QUESTS[revengeCullId('demon')]?.gate?.(mkCtx({})) === false);
  check('H5: the commander keeps his VOICE out here — the revenge fight\'s counterplay stands',
    TUTORIAL_FACTIONS.every(row =>
      MONSTERS[row.commander]?.parts?.some(p => p.breakDisables?.includes(row.verb))));
}

runMuReliquaryChecks(check);

console.log(failed ? `\n${failed} CHECK(S) FAILED` : '\nALL CHECKS PASS');
process.exit(failed ? 1 : 0);
