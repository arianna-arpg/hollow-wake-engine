// ---------------------------------------------------------------------------
// ONE-OFF PROBE — THE PATRON'S HOLD end to end (data/vendors.ts VENDOR_CFG +
// engine/world.ts + meta/worldstate.ts + meta/unlocks.ts). Pins:
//   - THE RESERVE LADDER: capacity = owned rungs (VENDOR_CFG.lock.ladder),
//     0 rungs refuse, each rung opens one slot; a reserved row rides every
//     restock and every leave/re-enter AS THE SAME OBJECT while free slots
//     re-roll; releasing re-opens the slot; buying clears the row and frees
//     capacity; the first purchase stamps LEDGER_VENDOR_BOUGHT (the Vault's
//     discovery gate — hidden before, visible after).
//   - SAVE FIDELITY: holds ride serializeWorldState → adoptWorldState (idx,
//     gem id/level/rarity, commission mark, ordinal); a stateless world
//     writes NO vendorHolds (empty is not load-bearing here); the sanitizer
//     drops unknown gems / vendors / dead site-scopes and never throws.
//   - THE DROP INDEX (gemdrop:<id>): dropGemAt mints bump it; a player
//     DISCARD does not; a counter PURCHASE does not — abuse-proof at the
//     mint site by construction.
//   - THE STANDING ORDER: refusals (no rung / unknown gem / index below
//     need / odds 0 before supports are sold) each in their own words; the
//     watch resolves elapsed beats at the shelf's true odds and seats the
//     find RESERVED (exempt from the reserve cap); a reload replays the
//     IDENTICAL outcome (find, rarity, seat — world seed × counter × gem ×
//     beat is the whole roll); purchase fulfills; releasing the find
//     unbought resumes the watch; withdrawal releases order and find.
//   - The chandler shares the fabric by registry (holds on its VendorDef
//     row; the live-port rig stays with probe_harborholds' ground).
//   - THE MARKET CHAIN (rig E): the TRADE GATE refuses every purchase until
//     the Salvage Station is owned (browsing free, refusals mutate nothing);
//     the GEM CASE refuses gem buys until its own unlock; the BROADER-WARES
//     ladder widens gems AND gear by its rows' own numbers; THE COUNTER
//     GLASS seats every rolled piece deterministically and provably holds
//     the catalog's worst case (capacity law derived, never guessed); the
//     single-face builders roll clean (the delver's gems-only counter).
//   - THE GATEWORK AVENUES (rig F): a gated family rung hangs SEALED once
//     its chain is walked, and opens along ANY authored road — level /
//     vocation / quest, the player's own order — with the level stamp
//     REGISTERED by derivation (catalogLevelMilestones).
// Run: npx tsx balance/probe_vendorlocker.ts
// ---------------------------------------------------------------------------

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { bootSimEngine, makeSimWorld } from '../src/sim/arena';
import { seedGlobalRandom } from '../src/sim/rng';
import {
  FEATURE, STARTER_SKILLS, STARTER_SUPPORTS, gemDropKey,
  LEDGER_GEMDROP_TOTAL, LEDGER_VENDOR_BOUGHT, makeAccount,
} from '../src/meta/account';
import { VENDOR_CFG } from '../src/data/vendors';
import { GEM_DROP_CFG } from '../src/engine/loot';
import { autoPlace } from '../src/engine/inventory';
import { sanitizeVendorHolds } from '../src/meta/worldstate';
import {
  allUnlockables, isUnlockVisible, sealedUnlocks,
} from '../src/meta/unlocks';
import { START_ZONE } from '../src/data/zones';
import { MONSTERS } from '../src/data/monsters';
import { ESSENCE_IDS, VENDOR_ITEM_CFG } from '../src/data/essences';
import { ITEM_BASES } from '../src/data/itembases';
import type { World, VendorEntry } from '../src/engine/world';

let failed = 0;
const check = (name: string, ok: boolean, detail = ''): void => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`);
  if (!ok) failed++;
};

bootSimEngine();

// THE BEAT LAW's base quantum, read from the config's own home — no rush
// rung is granted anywhere below except rig G's ladder checks.
const RESTOCK_SEC: number = VENDOR_CFG.restock.baseSec;
const need = VENDOR_CFG.commission.need;
const rungs = VENDOR_CFG.lock.ladder;

/** Park the hero at Brandt's elbow (nearSmith: 160px + dwell-reachable). */
const parkAtSmith = (w: World): void => {
  const smith = w.actors.find(a => !a.dead && a.defId && MONSTERS[a.defId]?.npcRole === 'vendor');
  if (!smith) throw new Error('no smith in town');
  // Ten px off her elbow — INSIDE the smithy's roof (THE COUNTER LAW: a
  // roofed vendor serves only under her own roof; rig H walks the apron).
  w.player.pos.x = smith.pos.x + 10;
  w.player.pos.y = smith.pos.y;
};
const enterTown = (w: World): void => { w.loadZone(START_ZONE); parkAtSmith(w); };
const leaveTown = (w: World): void => {
  const away = Object.values(w.zoneMap).find(z => z.id !== START_ZONE && !z.boundless)!;
  w.loadZone(away.id);
};
const fund = (w: World): void => { for (const id of ESSENCE_IDS) w.localSeat.meta.essences[id] = 99999; };
/** Open the market's meta gates (THE TRADE GATE + THE MEMORY COUNTER) so
 *  rigs that are not ABOUT those laws can buy freely — rig E owns the laws
 *  themselves. VENDOR_GEMS shapes the STOCK now (skill-items M3: the rung
 *  re-aimed from face-seal to true-gem share), so this runs BEFORE the
 *  town entry arms the shelf — every rig's armed shelf includes the gems
 *  it reads, deterministically per (seed, counter, beat, account). */
const openMarket = (w: World): void => {
  w.account.features.add(FEATURE.SALVAGE_STATION);
  w.account.features.add(FEATURE.VENDOR_GEMS);
};
const entryId = (e: VendorEntry): string =>
  e.kind === 'skill' ? e.inst.def.id : e.kind === 'support' ? e.gem.def.id : `item:${e.item.uid}`;
const commRow = (w: World, key = 'brandt') => w.vendorHolds[key]?.locks.find(r => r.commission);

// ------------------------------------------------ A. THE RESERVE LADDER
const SEED_A = 0x51c7;
seedGlobalRandom(0x77e2);
const wA: World = makeSimWorld('warrior', SEED_A);
openMarket(wA);
enterTown(wA);
check('A: the town arms a stocked counter', wA.vendorStock.length > 0,
  `${wA.vendorStock.length} wares`);
check('A: zero rungs = zero capacity, the toggle refuses',
  wA.vendorLockCap() === 0 && wA.setVendorLock('brandt', 0, true) === false);

wA.account.features.add(rungs[0].flag);
check('A: the first rung opens one slot', wA.vendorLockCap() === 1);
const heldA = wA.vendorStock[0];
check('A: a ware reserves within capacity',
  wA.setVendorLock('brandt', 0, true) === true
  && wA.vendorEntryHold('brandt', heldA) !== undefined);
check('A: the ledger full, a second reserve refuses',
  wA.setVendorLock('brandt', 1, true) === false);
wA.account.features.add(rungs[1].flag);
wA.account.features.add(rungs[2].flag);
check('A: the whole ladder counts (no literal three)', wA.vendorLockCap() === rungs.length);
const heldA2 = wA.vendorStock[1];
check('A: capacity grown, the second reserve stands', wA.setVendorLock('brandt', 1, true) === true);

const freeA = wA.vendorStock[2];
wA.restockVendor();
check('A: a restock re-seats reserved rows as the SAME objects at their slots',
  wA.vendorStock[0] === heldA && wA.vendorStock[1] === heldA2);
check('A: a free slot re-rolled (fresh object)', wA.vendorStock[2] !== freeA);

check('A: releasing a reserve stands', wA.setVendorLock('brandt', 1, false) === true);
wA.restockVendor();
check('A: the released slot re-rolls; the standing reserve rides on',
  wA.vendorStock[1] !== heldA2 && wA.vendorStock[0] === heldA
  && wA.vendorHolds.brandt.locks.length === 1);

leaveTown(wA);
check('A: THE STANDING SHELF — leaving town sheds nothing (the beat owns its truth); the hold rides',
  wA.vendorStock.length > 0 && wA.vendorHolds.brandt.locks.length === 1);
enterTown(wA);
check('A: re-entry inside the beat keeps the very shelf — the reserved row untouched at its seat',
  wA.vendorStock[0] === heldA);

fund(wA);
const stockLenA = wA.vendorStock.length;
check('A: buying the reserved ware clears its row and frees the ledger',
  wA.buyVendorGem(0) === true
  && wA.vendorStock.length === stockLenA - 1
  && wA.vendorHolds.brandt.locks.length === 0);
check('A: the purchase stamps the market ledger',
  (wA.account.ledger[LEDGER_VENDOR_BOUGHT] ?? 0) >= 1);

{
  // The Vault's ladder rung 1 stands at the CHAIN's far end now: the Gem
  // Counter + a Broader Wares rung owned AND the market ledger stamped —
  // the fresh account sees nothing, the walked one sees the card.
  const fresh = makeAccount();
  const lock1 = allUnlockables().find(u => u.id === 'feat_vendor_lock_1')!;
  const met = makeAccount();
  met.ledger[LEDGER_VENDOR_BOUGHT] = 1;
  met.features.add(FEATURE.VENDOR_GEMS);
  met.features.add(FEATURE.VENDOR_WARES_2); met.features.add(FEATURE.VENDOR_RESTOCK_2);
  const chainOnly = makeAccount();
  chainOnly.features.add(FEATURE.VENDOR_GEMS);
  chainOnly.features.add(FEATURE.VENDOR_WARES_2); chainOnly.features.add(FEATURE.VENDOR_RESTOCK_2);
  check('A: the Vault hides the ladder until the whole chain is walked + the account has traded',
    !isUnlockVisible(fresh, lock1) && !isUnlockVisible(chainOnly, lock1) && isUnlockVisible(met, lock1));
  check('A: the walked-but-untraded rung TEASES sealed (visible, unbuyable, its road printed)',
    sealedUnlocks(chainOnly).some(s => s.u.id === 'feat_vendor_lock_1')
    && !sealedUnlocks(fresh).some(s => s.u.id === 'feat_vendor_lock_1'));
}

// ------------------------------------------------ B. SAVE FIDELITY
{
  const heldNow = wA.vendorStock[3];
  check('B: (setup) a gem row reserved for the ride',
    !!heldNow && wA.setVendorLock('brandt', 3, true) === true);
  const ws = wA.serializeWorldState();
  const savedHold = ws.vendorHolds?.brandt;
  check('B: the hold rides the save (row, seat, loot arm)',
    !!savedHold && savedHold.locks.length === 1 && savedHold.locks[0].idx === 3);

  seedGlobalRandom(0x77e2);
  const wB = makeSimWorld('warrior', SEED_A);
  openMarket(wB); // account ownership is restored separately from world holds
  for (const r of rungs) wB.account.features.add(r.flag);
  check('B: adoptWorldState stands the hold back up', wB.adoptWorldState(ws) === true
    && wB.vendorHolds.brandt?.locks.length === 1);
  wB.loadZone(START_ZONE);
  const seated = wB.vendorStock[3];
  check('B: the restored row arms at its seat wearing its identity',
    !!seated && entryId(seated) === entryId(heldNow)
    && (seated.kind !== 'skill' || heldNow.kind !== 'skill'
      || (seated.inst.rarity === heldNow.inst.rarity && seated.inst.level === heldNow.inst.level)),
    `${entryId(heldNow)} @${heldNow?.kind} vs ${seated ? entryId(seated) : 'none'} @${seated?.kind}`);

  // A stateless world writes NO holds (empty is not load-bearing here).
  seedGlobalRandom(0x77e2);
  const wEmpty = makeSimWorld('warrior', 0x51c9);
  wEmpty.loadZone(START_ZONE);
  check('B: a holdless world saves no vendorHolds field',
    wEmpty.serializeWorldState().vendorHolds === undefined);
}

// ------------------------------------------------ B2. the sanitizer's floor
{
  const town = wA.zoneMap[START_ZONE];
  const goodRow = { idx: 2, loot: { kind: 'skill' as const, skillId: STARTER_SKILLS[0], level: 1, rarity: 'common' as const, sockets: [null] } };
  const raw: Record<string, unknown> = {
    brandt: {
      locks: [
        goodRow,
        { idx: 0, loot: { kind: 'skill', skillId: 'no_such_skill', level: 1, rarity: 'common', sockets: [] } },
        { idx: -4, loot: goodRow.loot },
        { idx: 1, loot: { kind: 'support', supportId: 'no_such_support', level: 1 } },
        null, 42, { idx: 1 },
      ],
      commission: { kind: 'skill', id: STARTER_SKILLS[0] },
      watchedSec: 3210.5,
      ordinal: 12.7,
    },
    chandler: { locks: [], commission: { kind: 'support', id: 'no_such_support' } },
    nobody: { locks: [goodRow] },
    [`brandt@${START_ZONE}`]: { locks: [goodRow] },
    'brandt@gone_zone': { locks: [goodRow] },
  };
  const out = sanitizeVendorHolds(raw, { [START_ZONE]: town });
  check('B2: the good row + order survive; garbage rows drop; both clock anchors sanitize',
    out.brandt?.locks.length === 1 && out.brandt.locks[0].idx === 2
    && out.brandt.commission?.id === STARTER_SKILLS[0]
    && out.brandt.watchedSec === 3210.5 && out.brandt.ordinal === 12,
    JSON.stringify(out.brandt?.locks.map(r => r.idx)));
  check('B2: an order for a de-registered gem releases (its hold drops empty)',
    out.chandler === undefined);
  check('B2: an unregistered counter drops; a dead site-scope drops with its ground',
    out.nobody === undefined && out['brandt@gone_zone'] === undefined
    && out[`brandt@${START_ZONE}`]?.locks.length === 1);
  check('B2: pure garbage never throws',
    Object.keys(sanitizeVendorHolds(['nonsense', { a: 1 }], {})).length === 0
    && Object.keys(sanitizeVendorHolds(null, {})).length === 0);
}

// ------------------------------------------------ C. THE DROP INDEX
{
  seedGlobalRandom(0x77e2);
  const wC = makeSimWorld('warrior', 0x2b31);
  openMarket(wC);
  enterTown(wC);
  const snapshot = (): string => JSON.stringify(
    Object.entries(wC.account.ledger).filter(([k]) => k.startsWith('gemdrop')).sort());
  const before = snapshot();
  // THE MEMORY LAW (2026-09-12): a DROP is a Memory now and stamps NOTHING —
  // the index feeds at the RECALL, where the gem truly enters the world.
  wC.dropGemAt(wC.player.pos, undefined, false, 'zombie');
  const pouchDrop = wC.drops[wC.drops.length - 1];
  check('C: a Memory DROP stamps nothing (the stone is not yet a gem)',
    pouchDrop.item.kind === 'gear' && !!pouchDrop.item.item.mem && snapshot() === before);
  wC.drops.pop();
  const pouch = pouchDrop.item.kind === 'gear' ? pouchDrop.item.item : null;
  if (pouch && autoPlace(wC.localSeat.meta.items, pouch)) {
    const recalled = wC.recallMemory(wC.localSeat, pouch.uid, 'zombie');
    check('C: the RECALL is the genuine mint — it stamps the index + the total',
      !!recalled && snapshot() !== before
      && (wC.account.ledger[gemDropKey(recalled.id)] ?? 0) >= 1
      && (wC.account.ledger[LEDGER_GEMDROP_TOTAL] ?? 0) >= 1, recalled?.id ?? 'no grant');
    const at = wC.localSeat.meta.items.findIndex(i => i.uid === recalled?.itemUid);
    if (at >= 0) wC.localSeat.meta.items.splice(at, 1);
  } else check('C: (setup) the pouch lands in the bag', false);
  // The pre-law BARE lane (memoryShare 0) stamps at the drop itself, as ever.
  const origShare = GEM_DROP_CFG.memoryShare;
  GEM_DROP_CFG.memoryShare = 0;
  const beforeBare = snapshot();
  wC.dropGemAt(wC.player.pos);
  GEM_DROP_CFG.memoryShare = origShare;
  const minted = wC.drops[wC.drops.length - 1];
  const mintedId = minted.item.kind === 'skill' ? minted.item.inst.def.id
    : minted.item.kind === 'support' ? minted.item.gem.def.id : '';
  check('C: a genuine BARE mint (memoryShare 0) stamps the index + the total',
    snapshot() !== beforeBare
    && (wC.account.ledger[gemDropKey(mintedId)] ?? 0) >= 1
    && (wC.account.ledger[LEDGER_GEMDROP_TOTAL] ?? 0) >= 1, mintedId);

  // A DISCARD moves owned goods — never a mint. (Pick the minted gem up
  // first: updateDrops is the pickup path; shortcut straight to the bag.)
  const afterMint = snapshot();
  // THE RESIDENCE (M1): the shortcut to the bag is the grant chokepoint;
  // the discard drops the wrapper by uid (unwrapping as it falls).
  const granted = minted.item.kind === 'skill'
    ? wC.grantSkillGemItem(wC.localSeat, minted.item.inst)
    : minted.item.kind === 'support'
      ? wC.grantSupportGemItem(wC.localSeat, minted.item.gem) : null;
  wC.drops.pop();
  if (granted) wC.dropGearFromBag(wC.localSeat, granted.uid);
  check('C: a player discard never feeds the index', snapshot() === afterMint);

  // A counter purchase moves stock — never a mint.
  fund(wC);
  const afterDiscard = snapshot();
  check('C: a counter purchase never feeds the index',
    wC.buyVendorGem(0) === true && snapshot() === afterDiscard);
}

// ------------------------------------------------ D. THE STANDING ORDER
{
  const SEED_D = 0x66d3;
  seedGlobalRandom(0x77e2);
  const wD = makeSimWorld('warrior', SEED_D);
  wD.account.memorySecondary.clear(); // this rig exercises account progression, not the arena's open-tree fixture
  openMarket(wD);
  enterTown(wD);
  const skillId = STARTER_SKILLS[0];
  const supId = STARTER_SUPPORTS[0];

  check('D: no rung, no order', wD.setVendorCommission('brandt', { kind: 'skill', id: skillId }) === false);
  wD.account.features.add(FEATURE.VENDOR_COMMISSION);
  check('D: an unknown gem refuses',
    wD.setVendorCommission('brandt', { kind: 'skill', id: 'no_such_gem' }) === false);
  check('D: an unawakened skill refuses commissioning',
    wD.setVendorCommission('brandt', { kind: 'skill', id: skillId }) === false);
  wD.account.ledger[gemDropKey(skillId)] = need;
  wD.account.memorySecondary.add(`skill:${skillId}`);
  wD.account.ledger[gemDropKey(supId)] = need;
  check('D: a support refuses at HONEST zero odds while Brandt sells none',
    wD.commissionOdds({ kind: 'support', id: supId }) === 0
    && wD.setVendorCommission('brandt', { kind: 'support', id: supId }) === false);
  wD.account.features.add(FEATURE.BRANDT_SELL_SUPPORTS);
  check('D: once supports sell, the same support prices real odds',
    wD.commissionOdds({ kind: 'support', id: supId }) > 0);

  const p = wD.commissionOdds({ kind: 'skill', id: skillId });
  check('D: the shelf odds are honest (0 < p ≤ 1)', p > 0 && p <= 1, `p=${p.toFixed(4)}`);
  check('D: a KNOWN gem places the order',
    wD.setVendorCommission('brandt', { kind: 'skill', id: skillId }) === true
    && wD.vendorHolds.brandt.commission?.id === skillId);
  check('D: the watch starts NOW — the wall-time anchor, no retroactive beats',
    wD.vendorHolds.brandt.watchedSec === wD.time);

  // Bank the pre-resolution save for the replay rig, then resolve away beats.
  const wsPre = wD.serializeWorldState();
  const BEATS = 400; // p≈>0.05 folded over 400 beats — a miss is ~impossible
  leaveTown(wD);
  wD.time += BEATS * RESTOCK_SEC;
  enterTown(wD);
  const found1 = commRow(wD);
  check('D: the away watch resolves and seats the find RESERVED',
    !!found1 && entryId(found1.entry) === skillId
    && wD.vendorStock[found1.idx] === found1.entry);
  check('D: the order still stands (fulfilled by PURCHASE, not by the find)',
    wD.vendorHolds.brandt.commission?.id === skillId);
  const rarity1 = found1?.entry.kind === 'skill' ? found1.entry.inst.rarity : undefined;

  // THE REPLAY: the same save, the same clock — the identical find (seat,
  // gem, rarity). World seed × counter × gem × beat is the whole roll.
  seedGlobalRandom(0x77e2);
  const wR = makeSimWorld('warrior', SEED_D);
  openMarket(wR);
  wR.account.features.add(FEATURE.VENDOR_COMMISSION);
  wR.account.features.add(FEATURE.BRANDT_SELL_SUPPORTS);
  wR.account.ledger[gemDropKey(skillId)] = need;
  wR.account.ledger[gemDropKey(supId)] = need;
  check('D: (replay) the save stands back up', wR.adoptWorldState(wsPre) === true);
  wR.time += BEATS * RESTOCK_SEC;
  enterTown(wR);
  const found2 = commRow(wR);
  check('D: a reload replays the IDENTICAL find — seat, gem, rarity',
    !!found2 && !!found1
    && found2.idx === found1.idx
    && entryId(found2.entry) === entryId(found1.entry)
    && (found2.entry.kind === 'skill' ? found2.entry.inst.rarity : undefined) === rarity1,
    `rarity=${String(rarity1)}`);

  // Purchase FULFILLS: the order clears and later restocks seat nothing new.
  fund(wD);
  check('D: buying the find fulfills the standing order',
    !!found1 && wD.buyVendorGem(found1.idx) === true
    && wD.vendorHolds.brandt.commission === undefined
    && commRow(wD) === undefined);
  wD.restockVendor();
  check('D: a fulfilled order stays fulfilled (no re-seat)', commRow(wD) === undefined);

  // Release-unbought RESUMES the watch; withdrawal releases order + find.
  check('D: (re-place for the release rig)',
    wD.setVendorCommission('brandt', { kind: 'skill', id: skillId }) === true);
  leaveTown(wD);
  wD.time += BEATS * RESTOCK_SEC;
  enterTown(wD);
  const found3 = commRow(wD);
  check('D: the re-placed watch finds again', !!found3);
  check('D: releasing the find unbought keeps the order armed',
    !!found3 && wD.setVendorLock('brandt', found3.idx, false) === true
    && wD.vendorHolds.brandt.commission?.id === skillId
    && commRow(wD) === undefined);
  leaveTown(wD);
  wD.time += BEATS * RESTOCK_SEC;
  enterTown(wD);
  check('D: the resumed watch finds anew', commRow(wD) !== undefined);
  check('D: withdrawal releases order and find together',
    wD.setVendorCommission('brandt', null) === true
    && wD.vendorHolds.brandt.commission === undefined && commRow(wD) === undefined);

  // The find is EXEMPT from the reserve cap (rung 1 only: one reserve +
  // the find coexist; a second reserve still refuses).
  wD.account.features.add(rungs[0].flag);
  check('D: (setup) one reserve fills rung one', wD.setVendorLock('brandt', 0, true) === true);
  check('D: (setup) the order re-places', wD.setVendorCommission('brandt', { kind: 'skill', id: skillId }) === true);
  leaveTown(wD);
  wD.time += BEATS * RESTOCK_SEC;
  enterTown(wD);
  check('D: the find seats BESIDE a full reserve ledger (cap-exempt)',
    commRow(wD) !== undefined && wD.vendorHolds.brandt.locks.length === 2);
  check('D: the reserve cap still binds ordinary rows',
    wD.setVendorLock('brandt', wD.vendorStock.findIndex(e => !wD.vendorEntryHold('brandt', e)), true) === false);

  // The Vault's commission card: purchasable exactly when at least ONE gem
  // is ORDERABLE (some gemdrop:* key at the commission's own need — the
  // gatework's prefix avenue), never on a bare total.
  const bare = makeAccount();
  bare.ledger[LEDGER_VENDOR_BOUGHT] = 1;
  bare.features.add(rungs[0].flag);
  const comm = allUnlockables().find(u => u.id === 'feat_vendor_commission')!;
  const seen = makeAccount();
  seen.ledger[LEDGER_VENDOR_BOUGHT] = 1;
  seen.features.add(rungs[0].flag);
  seen.ledger[gemDropKey(skillId)] = need;
  const shallow = makeAccount();
  shallow.ledger[LEDGER_VENDOR_BOUGHT] = 1;
  shallow.features.add(rungs[0].flag);
  shallow.ledger[LEDGER_GEMDROP_TOTAL] = 999; // a wide index with no DEEP gem
  shallow.ledger[gemDropKey(skillId)] = need - 1;
  seen.memorySecondary.add(`skill:${skillId}`);
  seen.ledger.odyssey_stage_2 = 1;
  check('D: the Vault sells the order when ONE Memory is eligible; old drop counts alone cannot awaken skills',
    !isUnlockVisible(bare, comm) && !isUnlockVisible(shallow, comm) && isUnlockVisible(seen, comm));
  check('D: the hold-owning account TEASES the sealed order card with its road',
    sealedUnlocks(shallow).some(s => s.u.id === 'feat_vendor_commission'
      && s.lines.some(l => !l.met)));
}

// ------------------------------------------------ E. THE MARKET CHAIN
// The trade gate, THE MEMORY COUNTER's stock-side gating (skill-items M3 —
// the one shelf: pouches from the first day, true gems join at the rung),
// the broader-wares fold, the counter glass, and the gatework avenues.
{
  seedGlobalRandom(0x77e2);
  const wE = makeSimWorld('warrior', 0x3e11);
  enterTown(wE);
  fund(wE);
  const isPouch = (e: VendorEntry): boolean => e.kind === 'item' && !!e.item.mem;
  const counts = (w: World): { pouches: number; gems: number; gear: number } => ({
    pouches: w.vendorStock.filter(isPouch).length,
    gems: w.vendorStock.filter(e => e.kind !== 'item').length,
    gear: w.vendorStock.filter(e => e.kind === 'item' && !e.item.mem).length,
  });
  const pouchKinds = (Object.keys(VENDOR_CFG.pouches) as (keyof typeof VENDOR_CFG.pouches)[])
    .filter(k => VENDOR_CFG.pouches[k] > 0);

  // --- THE ONE SHELF, fresh: pouches + gear stand; the true gems WAIT on
  // the Memory Counter (the rung re-aimed from face-seal to stock share).
  const fresh = counts(wE);
  check('E: Brandt starts with gear only; all Memories wait on the Vault',
    fresh.pouches === 0 && fresh.gems === 0 && fresh.gear === VENDOR_ITEM_CFG.slots,
    `p${fresh.pouches} g${fresh.gems} r${fresh.gear}`);

  // Brandt trades plain equipment immediately; other counters keep their gates.
  const gearIdx = wE.vendorStock.findIndex(e => e.kind === 'item' && !e.item.mem);
  check('E: the default market gate still requires the station', typeof wE.vendorTradeRefusal() === 'string');
  check('E: Brandt sells basic gear before the station', gearIdx >= 0 && wE.buyVendorGem(gearIdx));
  check('E: the Memory Counter still gates the memory shelf', !wE.vendorGemsOpen() && counts(wE).pouches === 0);
  wE.account.features.add(FEATURE.SALVAGE_STATION);
  check('E: the station opens other market gates', wE.vendorTradeRefusal() === null);
  wE.account.features.add(FEATURE.VENDOR_GEMS);
  wE.restockVendor(); // the rung joins the slots at the shelf's own re-arm
  check('E: the Memory Counter rung joins vendorSize() true-gem slots to the one shelf',
    wE.vendorGemsOpen() === true && counts(wE).gems === VENDOR_CFG.wares.baseGems);
  check('E: a true gem sells through the one face',
    wE.buyVendorGem(wE.vendorStock.findIndex(e => e.kind !== 'item')) === true);

  // --- THE BROADER-WARES FOLD: both halves widen per the ladder's own rows
  // (expectations DERIVED from config — nothing here counts to three); the
  // pouch offering stands CONSTANT (dial-owned, rung-free).
  wE.restockVendor();
  const base = counts(wE);
  check('E: the bare shelf is the configured base',
    base.gems === VENDOR_CFG.wares.baseGems && base.gear === VENDOR_ITEM_CFG.slots,
    `gems ${base.gems} gear ${base.gear}`);
  for (const r of VENDOR_CFG.wares.ladder) wE.account.features.add(r.flag);
  wE.restockVendor();
  const wide = counts(wE);
  const expGems = VENDOR_CFG.wares.baseGems + VENDOR_CFG.wares.ladder.reduce((n, r) => n + r.gems, 0);
  const expGear = VENDOR_ITEM_CFG.slots + VENDOR_CFG.wares.ladder.reduce((n, r) => n + r.gear, 0);
  check('E: the full ladder widens BOTH halves by its own numbers (pouches constant)',
    wide.gems === expGems && wide.gear === expGear && wide.pouches === pouchKinds.length,
    `gems ${wide.gems}/${expGems} gear ${wide.gear}/${expGear}`);

  // --- THE COUNTER GLASS: every ware seats — gear by footprint, gem finds
  // and pouch stacks as 1×1 tiles — deterministically, and the board
  // provably holds the WORST case (widest ladder × largest base + every
  // 1×1) — the capacity law derived from the catalog, so content that
  // outgrows the glass fails HERE, never silently in a panel.
  const pack1 = wE.vendorGridPack(wE.vendorStock);
  const pack2 = wE.vendorGridPack(wE.vendorStock);
  check('E: the glass seats every ware (gear + gems + pouches)',
    pack1.overflow.length === 0 && pack1.gemOverflow.length === 0,
    `${pack1.cells.size} item + ${pack1.gemCells.size} gem tiles`);
  check('E: the pack is deterministic (same stock, same glass)',
    JSON.stringify([...pack1.cells.entries()]) === JSON.stringify([...pack2.cells.entries()])
    && JSON.stringify([...pack1.gemCells.entries()]) === JSON.stringify([...pack2.gemCells.entries()]));
  const largest = Object.values(ITEM_BASES).reduce((a, b) => (a.w ?? 1) * (a.h ?? 1) >= (b.w ?? 1) * (b.h ?? 1) ? a : b);
  const worst = wE.vendorStock.map((e, i) => e.kind === 'item' && !e.item.mem
    ? { ...e, item: { ...e.item, uid: 990000 + i, baseId: largest.id } } : e);
  const packedWorst = wE.vendorGridPack(worst);
  check('E: paged glass seats the largest footprints without losing wares',
    !packedWorst.overflow.length && !packedWorst.gemOverflow.length && packedWorst.pages > 1
    && packedWorst.cells.size + packedWorst.gemCells.size === worst.length);

  // --- The single-half builders (arm sites standing down a half).
  check('E: a gems-half build rolls no gear (the pouches ride the gems half)',
    wE.buildVendorStock({ gear: false }).every(e => e.kind !== 'item' || !!e.item.mem));
  check('E: a gear-only build rolls neither gems nor pouches',
    wE.buildVendorStock({ gems: false }).every(e => e.kind === 'item' && !e.item.mem));

  // --- THE PRICE ON THE GLASS (2026-09-11, her report: "I see the cost for
  // the skills, but I don't see any mention of a cost on most of the other
  // items — I'm not sure whether I can go shopping"): gear and pouch tiles
  // wore the plain item card and a priceless title while only the gem card
  // spoke "click to buy — price". Now EVERY ware tile wears its price tag
  // (VENDOR_CFG.glass.priceTag) and names its ware (data-vware) so the item
  // card ends on the ONE counter footer the gem card also speaks.
  const panelsSrc = readFileSync(resolve(process.cwd(), 'src/ui/panels.ts'), 'utf8');
  const wareTags = panelsSrc.split('data-vware="').length - 1;
  check('E: every counter item tile names its ware for the card (the tile + the overflow row)',
    wareTags >= 2, `data-vware×${wareTags}`);
  check('E: the item card at the counter ends on THE COUNTER FOOTER',
    panelsSrc.includes('this.vendorWareTooltip(Number(el.dataset.itemUid), ext, el.dataset.vware)')
    && panelsSrc.includes('this.vendorWareFooter(wareKey)'));
  check('E: the gem card speaks the SAME footer (one helper, one set of words)',
    panelsSrc.includes('lines.push(...this.vendorWareFooter(key));'));
  check('E: the price tag rides the glass dial, worn by gem and item tiles alike',
    (['always', 'hover'] as readonly string[]).includes(VENDOR_CFG.glass.priceTag)
    && panelsSrc.includes("VENDOR_CFG.glass.priceTag === 'always'")
    && panelsSrc.split('${priceTag}').length - 1 >= 2);
  check('E: the tile title carries the price in plain words (the native hint fallback)',
    panelsSrc.includes('Buy: ${esc(i.name)} — ${esc(pricePlain)}'));
}

// ------------------------------------------------ F. THE GATEWORK AVENUES
// Rung 3 of the wares family opens along ANY of its authored roads — level,
// vocation, quest — in the player's own order; until then it hangs SEALED.
{
  const rung4 = allUnlockables().find(u => u.id === 'feat_vendor_wares_4')!;
  const a = makeAccount();
  for (const r of VENDOR_CFG.wares.ladder.slice(0, 3)) a.features.add(r.flag);
  check('F: fourth wares tier is sealed after the three early tiers', !isUnlockVisible(a, rung4)
    && sealedUnlocks(a).some(s => s.u.id === rung4.id));
  a.features.add(FEATURE.BRANDT_MAGIC_WARES);
  check('F: Magic Wares opens the fourth wares tier', isUnlockVisible(a, rung4));
  check('F: an unwalked chain does not tease later tiers', !sealedUnlocks(makeAccount()).some(s => s.u.id === rung4.id));
}

// ------------------------------------------------ G. THE BEAT LAW
// One clock: restocks land on floor(time/sec) boundaries; the shelf is a
// pure function of (world seed, counter, beat) — zone hops keep it, reloads
// replay it, only a TURNED beat re-rolls it; the rush ladder shortens the
// quantum without ever bending the watch (the wall-time anchor).
{
  const shelfSig = (w: World): string => JSON.stringify(w.vendorStock.map(e =>
    e.kind === 'skill' ? `s:${e.inst.def.id}:${e.inst.rarity}:${e.inst.level}`
    : e.kind === 'support' ? `g:${e.gem.def.id}`
    : `i:${e.item.baseId}:${e.item.rarity}:${e.item.ilvl}`));
  const SEED_G = 0x77aa;
  seedGlobalRandom(0x77e2);
  const wG = makeSimWorld('warrior', SEED_G);
  openMarket(wG);
  enterTown(wG);
  check('G: the live mark sits ON the lattice — (beat+1) × sec, phase zero',
    wG.vendorRestockAt === (Math.floor(wG.time / RESTOCK_SEC) + 1) * RESTOCK_SEC,
    `at=${wG.vendorRestockAt} t=${wG.time}`);
  const sig0 = shelfSig(wG);
  const obj0 = wG.vendorStock[0];
  leaveTown(wG);
  enterTown(wG);
  check('G: a zone hop inside the beat keeps the very ARRAY (no re-roll, no countdown reset)',
    shelfSig(wG) === sig0 && wG.vendorStock[0] === obj0);

  // A RELOAD inside the beat meets the same shelf BY SEED (fresh world,
  // same manifest, same beat — the foreordained-shelf identity).
  seedGlobalRandom(0x1234); // a DIFFERENT boot stream — the shelf must not care
  const wG2 = makeSimWorld('warrior', SEED_G);
  openMarket(wG2);
  wG2.time = wG.time;
  enterTown(wG2);
  check('G: a reload inside the beat deals the IDENTICAL shelf (seeded, boot-stream-proof)',
    shelfSig(wG2) === sig0);

  // A purchase persists across a hop (the beat keeps the SPLICED truth).
  fund(wG);
  const lenBefore = wG.vendorStock.length;
  check('G: (setup) a ware bought', wG.buyVendorGem(wG.vendorStock.findIndex(e => e.kind === 'item')) === true);
  leaveTown(wG);
  enterTown(wG);
  check('G: the purchase stays gone across the hop — no same-beat resurrection',
    wG.vendorStock.length === lenBefore - 1);

  // The TURNED beat deals anew.
  leaveTown(wG);
  wG.time += RESTOCK_SEC;
  enterTown(wG);
  check('G: the turned beat deals a fresh shelf', shelfSig(wG) !== sig0);

  // THE RUSH LADDER: every owned rung cuts the quantum; the mark lands on
  // the SHORTER lattice (expectation derived from the config, floored).
  for (const r of VENDOR_CFG.restock.ladder) wG.account.features.add(r.flag);
  const rushed = Math.max(VENDOR_CFG.restock.minSec,
    VENDOR_CFG.restock.ladder.reduce((s: number, r) => s - r.cutSec, RESTOCK_SEC));
  leaveTown(wG);
  wG.time += RESTOCK_SEC;
  enterTown(wG);
  check('G: the full rush ladder re-times the mark onto its own lattice',
    rushed < RESTOCK_SEC && wG.vendorRestockAt === (Math.floor(wG.time / rushed) + 1) * rushed,
    `sec=${rushed}`);
  check('G: the Vault derives the rush rows, open initially then chained',
    allUnlockables().some(u => u.id === 'feat_vendor_restock_1'
      && u.requiresUnlock === undefined)
    && allUnlockables().some(u => u.id === 'feat_vendor_restock_2'
      && (Array.isArray(u.requiresUnlock) ? u.requiresUnlock[0] : u.requiresUnlock) === 'feat_vendor_restock_1'));

  // THE WINDFALL CHECK: a rush rung bought MID-WATCH re-buckets elapsed
  // time honestly — the quantum change alone must resolve ZERO beats (under
  // the old beat-index anchor, floor(t/180)−floor(t/300) ≈ 26 phantom
  // beats here would near-certainly seat a find).
  seedGlobalRandom(0x77e2);
  const wW = makeSimWorld('warrior', 0x66d3);
  openMarket(wW);
  wW.account.features.add(FEATURE.VENDOR_COMMISSION);
  wW.account.features.add(FEATURE.BRANDT_SELL_SUPPORTS);
  const wSkill = STARTER_SKILLS[0];
  wW.account.ledger[gemDropKey(wSkill)] = need;
  enterTown(wW);
  wW.time += 12000; // deep into the run BEFORE the order — a big re-bucket span
  leaveTown(wW);
  enterTown(wW);
  check('W: (setup) the order placed deep into the run',
    wW.setVendorCommission('brandt', { kind: 'skill', id: wSkill }) === true
    && wW.vendorHolds.brandt.watchedSec === wW.time);
  for (const r of VENDOR_CFG.restock.ladder) wW.account.features.add(r.flag);
  leaveTown(wW);
  wW.time += 1; // one second — no beat can genuinely have passed
  enterTown(wW);
  check('W: the quantum change alone resolves NOTHING — no phantom catchup, no windfall find',
    commRow(wW) === undefined && wW.vendorHolds.brandt.watchedSec === wW.time);

  // LEGACY SAVES: a pre-beat-law ordinal converts under the live quantum.
  seedGlobalRandom(0x77e2);
  const wV = makeSimWorld('warrior', 0x5b5b);
  const legacy = {
    brandt: {
      locks: [], commission: { kind: 'skill' as const, id: STARTER_SKILLS[0] },
      ordinal: 40,
    },
  };
  const cleanLegacy = sanitizeVendorHolds(legacy, {});
  check('V: (setup) the legacy row survives the sanitizer wearing its beat index',
    cleanLegacy.brandt?.ordinal === 40 && cleanLegacy.brandt.watchedSec === undefined);
  check('V: adoption converts a legacy beat index to wall time under the live quantum',
    wV.adoptWorldState({ ...wV.serializeWorldState(), vendorHolds: cleanLegacy }) === true
    && wV.vendorHolds.brandt?.watchedSec === 40 * RESTOCK_SEC);
}

// ------------------------------------------------ H. THE COUNTER LAW (roof)
// A roofed vendor serves only patrons under the SAME roof: the smithy's
// open apron sits inside dwell radius but outside the roof — the counter
// stays shut until the patron steps onto the flagstone.
{
  seedGlobalRandom(0x77e2);
  const wH = makeSimWorld('warrior', 0x40f1);
  openMarket(wH);
  enterTown(wH);
  const smith = wH.actors.find(a => !a.dead && a.defId && MONSTERS[a.defId]?.npcRole === 'vendor')!;
  const roofAt = (p: { x: number; y: number }): unknown =>
    (wH as unknown as { roofedStructureAt(q: { x: number; y: number }): unknown }).roofedStructureAt(p);
  check('H: Brandt stands under her own slate (the smithy roof is real)', roofAt(smith.pos) !== null);
  check('H: under the shared roof, the counter serves', wH.nearSmith(wH.localSeat) === true);

  // Walk the compass at ~150px until the roof ends — the open apron.
  let apron: { x: number; y: number } | null = null;
  for (let a = 0; a < 16 && !apron; a++) {
    const p = { x: smith.pos.x + Math.cos(a * Math.PI / 8) * 150, y: smith.pos.y + Math.sin(a * Math.PI / 8) * 150 };
    if (roofAt(p) === null) apron = p;
  }
  check('H: an open apron point stands inside dwell radius', apron !== null);
  if (apron) {
    wH.player.pos.x = apron.x;
    wH.player.pos.y = apron.y;
    check('H: from the apron — radius met, roof unshared — the counter stays shut',
      wH.nearSmith(wH.localSeat) === false);
    parkAtSmith(wH);
    check('H: stepping back onto the flagstone re-opens it', wH.nearSmith(wH.localSeat) === true);
  }
}

console.log(failed ? `\n${failed} CHECK(S) FAILED` : '\nALL PASS');
process.exit(failed ? 1 : 0);
