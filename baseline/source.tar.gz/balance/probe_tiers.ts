// THE TIER FABRIC PROBE — the walkable layers pinned structurally
// (engine/tiers.ts): the region rows (including the N-story terrace/ramp
// families), the crossing law across arbitrary spans, all three carves
// (needles decks + sewer ducts + the switchback summits), per-story deck
// reachability, THE ASCENT LAW (entry → summit on foot), determinism, and
// THE ELEVATION LAW (engine/los.ts RayElev): height-aware sight/shot over
// the stack — same-story duels over open deck, rim duels refereed by the
// lerped eye line, the flat flight law, the doodad story band, and the
// SIGHT VEIL's drawn parity (render/vis/sightVeil.ts, headless) — plus
// THE PROACTIVE HUNT (RIG J): World.pathField(story) per-story fields
// (makeTierNav — link cells as walkable seams), the tier-less identity
// law (flat zones return the same object for every story), the stair
// election (World.tierLinkToward), the live crossing (an un-witnessed
// deck hunter elects a ramp and changes story toward a valley player),
// and THE SEVERED BAND (ai.ts severedBandGoal / TIER_CFG.severedBandReach):
// a flanker's orbit defers to the approach lane across a story gap and
// crosses, while long kits keep their rim duel and stand-ground styles
// keep their posts — and THE MAP TELL (RIG M): tierMapTell (ui/panels.ts),
// the world map's fog-gated stacked-ground read, pinned pure and against
// the real minted defs — plus its COLOR half THE TIER TINT (RIG M′):
// tierMapTint, the node fill's story shade (higher = lighter, under =
// darker, byte-zero on storyless ground) — and THE STORY TABLE (RIG P):
// storyTable (engine/tiers.ts), the per-story spawn axis's fold, LIVE at
// spawnPacks since the story fold (2026-08-06: identity + ledger census,
// stream-neutral, the envelope honored on synthetic rows and the real
// pinnacle gale debut) — and LAYER SOVEREIGNTY (RIG Q, batch 40): cross-tier
// touch/pop/block sealed live on a rooted garden — the mallet and the
// touch sweep answer only the striker's own story (with surface controls
// proving the gate alive), a surface trunk neither blocks nor sentinel-
// snaps the under-story walker, summons wear their caster's story, and
// the crossings still serve both ends — and THE DIRECT SEAT'S STAMP
// (RIG R, batch 41): the tierseal coda's suspicion adjudicated — the
// aloft stamp is DEF-driven (LandmarkDef.siteTier at placeLandmark's
// builder tail) and covers the direct placeLandmarkById path too, so the
// mere court's pieces wear the lane's story; the underLane intent census
// (a seat's story can never be sensed from lid ground — the def carries
// the intent) and the flat-control purity pin hold the law's two rims.
//   npx tsx balance/probe_tiers.ts

import '../src/data/clusters';
import '../src/data/formations';
import '../src/engine/landmarkBuilders';
import '../src/data/landmarks';
import '../src/engine/layoutRecipes';
import '../src/engine/interiorGen';
import '../src/data/massifs';
import '../src/data/compositions';
import '../src/data/settled';
// (the horn_gate door's live def registers there — rig O16's pin.)
import '../src/data/lairs';
// (the mere lane + court register there — rig R's pins; the lair fold is
// pure off-lane, so no existing rig's stream moves.)
import '../src/data/merelake';

import { Rng } from '../src/core/rng';
import { readFileSync } from 'node:fs'; // (RIG T — THE SOVEREIGNTY ROSTER's source census)
import { resolve } from 'node:path';
import { mixHex, vec } from '../src/core/math';
import { severedBandGoal, updateAI, type KernelCtx } from '../src/engine/ai';
import type { Actor } from '../src/engine/actor';
import { SEG_CFG } from '../src/engine/segments';
import { mod } from '../src/engine/stats';
import { makeSimWorld } from '../src/sim/arena';
import { seedGlobalRandom } from '../src/sim/rng';
import {
  doodadRuleOf, generateLayout, hasLayout, landmarkOf, registerCluster,
  registerComposition, registerDoodadRule, registerLandmark,
  validateCompositions, type Doodad,
  type GeneratedLayout,
} from '../src/engine/levelgen'; // (landmarkOf joined for O16 — the horn_gate live-def pin)
import { applyBuild } from '../src/sim/builds'; // (RIG Q — bar-learned casts through useSkill)
import { lairRows } from '../src/engine/lairs'; // (RIG R — the underLane intent census)
import { castRay, LOS_CFG } from '../src/engine/los';
import { makeSkillInstance } from '../src/engine/skills';
import { SKILLS } from '../src/data/skills';
import { SightVeil } from '../src/render/vis/sightVeil';
import { GridWalkField } from '../src/world/gridWalk';
import { regionKind } from '../src/world/regions';
import { massKindOf } from '../src/engine/massif';
import {
  landingTier, linkFlipTier, linkSpanOf, makeTierView, MAX_TIER,
  resolveTierCrossing, storyReachable, storyTable, tierElevOf, tierFloorAt,
  tierFloorOf, tierLinkOf, UNDER_TIER_LANES,
  floorStoryOf, tierEnclosure, // (RIG S — THE ENCLOSURE LAW)
} from '../src/engine/tiers';
import { insideBounds } from '../src/world/shape';
import { TILESETS } from '../src/data/tilesets';
import type { StampSpec, ZoneDef } from '../src/data/zones';
import { tierMapTell, tierMapTint } from '../src/ui/panels';
import { VIS_CFG } from '../src/render/vis/visConfig';

let fails = 0;
const check = (name: string, ok: boolean, detail = ''): void => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`);
  if (!ok) fails++;
};

// --- RIG A: the registry weave ----------------------------------------------------
{
  check('A1 needles layout registered', hasLayout('needles'));
  check('A2 butte kind seats butte_top', massKindOf('butte')?.region === 'butte_top');
  const top = regionKind('butte_top'), span = regionKind('butte_span');
  const ramp = regionKind('tier_ramp'), duct = regionKind('sewer_duct');
  const uw = regionKind('sewer_under_wall'), well = regionKind('culvert_well');
  check('A3 butte_top: wall below, floor above', !!top && !top.walkable && top.tier === 1 && !!top.blocksShot);
  check('A4 butte_span: one cell, two floors', !!span && !!span.walkable && span.tier === 1 && !span.blocksShot);
  check('A5 tier_ramp + culvert_well are CROSSINGS', !!ramp?.tierLink && !!well?.tierLink && !!ramp?.walkable && !!well?.walkable);
  check('A6 sewer_duct: street above keeps its face', !!duct && !!duct.walkable && duct.tier === 1 && !duct.visual && !!duct.tierVisual);
  check('A7 sewer_under_wall: brick above, tunnel below', !!uw && !uw.walkable && uw.tier === 1 && !!uw.visual && !!uw.tierVisual);
}

// --- RIG B: the crossing law (pure) --------------------------------------------------
{
  const cell: Record<string, string> = { '0,0': 'tier_ramp', '1,0': 'butte_top', '-1,0': 'ground' };
  const grid = { regionAt: (x: number, y: number) => cell[`${Math.round(x / 30)},${Math.round(y / 30)}`] ?? 'ground', cell: 30 };
  check('B1 link → deck-only ground flips 0→1',
    resolveTierCrossing(grid, 0, vec(0, 0), vec(30, 0)) === 1);
  check('B2 link → valley-only ground flips 1→0',
    resolveTierCrossing(grid, 1, vec(0, 0), vec(-30, 0)) === 0);
  check('B3 off-link steps never flip',
    resolveTierCrossing(grid, 0, vec(-30, 0), vec(-60, 0)) === 0);
  check('B4 predicates', tierFloorOf('butte_top') && tierFloorOf('tier_ramp') && tierLinkOf('culvert_well') && !tierFloorOf('ground'));
}

// --- RIG B′: the N-STORY laws (pure) --------------------------------------------------
{
  // The terrace/ramp family stands, story by story.
  let family = true;
  for (let k = 1; k <= MAX_TIER; k++) {
    const t = regionKind(`peak_terrace_${k}`), r = regionKind(`peak_ramp_${k}`);
    family = family && !!t && !t.walkable && !!t.blocks && t.tier === k && !!t.blocksShot && !!t.blocksSight
      && !!r && !!r.tierLink && r.tier === k && (k === 1 ? !!r.walkable : !r.walkable && !!r.blocks);
  }
  check(`B5 the family stands to MAX_TIER (${MAX_TIER})`, family);
  // Span derivation: walkable links touch the ground floor; high stairs
  // join the story below — no new field needed anywhere.
  const spans = (id: string): string => linkSpanOf(regionKind(id)!).join(':');
  check('B6 span derivation', spans('tier_ramp') === '0:1' && spans('culvert_well') === '0:1'
    && spans('peak_ramp_1') === '0:1' && spans('peak_ramp_2') === '1:2' && spans(`peak_ramp_${MAX_TIER}`) === `${MAX_TIER - 1}:${MAX_TIER}`);
  // The crossing law across a high span.
  const cell: Record<string, string> = { '0,0': 'peak_ramp_2', '1,0': 'peak_terrace_2', '-1,0': 'peak_terrace_1' };
  const grid = { regionAt: (x: number, y: number) => cell[`${Math.round(x / 30)},${Math.round(y / 30)}`] ?? 'ground', cell: 30 };
  check('B7 high stair → upper bench flips 1→2',
    resolveTierCrossing(grid, 1, vec(0, 0), vec(30, 0)) === 2);
  check('B8 high stair → lower bench flips 2→1',
    resolveTierCrossing(grid, 2, vec(0, 0), vec(-30, 0)) === 1);
  check('B9 the ladder toggle flips to the span\'s other end',
    linkFlipTier('peak_ramp_2', 2) === 1 && linkFlipTier('peak_ramp_2', 1) === 2
    && linkFlipTier('culvert_well', 0) === 1 && linkFlipTier('culvert_well', 1) === 0);
  check('B10 per-story floors', tierFloorAt('peak_terrace_3', 3) && !tierFloorAt('peak_terrace_3', 2)
    && !tierFloorAt('peak_terrace_3', 0) && tierFloorAt('peak_ramp_3', 2) && tierFloorAt('peak_ramp_3', 3)
    && !tierFloorAt('peak_ramp_3', 0) && tierFloorAt('tier_ramp', 0) && tierFloorAt('tier_ramp', 1));
  check('B11 elevations for flights', tierElevOf('ground') === 0 && tierElevOf('wall') === null
    && tierElevOf('butte_top') === 1 && tierElevOf('peak_terrace_4') === 4 && tierElevOf('peak_ramp_4') === 4);
}

// --- RIG F: the drawn-read data (steps + cliff flags) ---------------------------------
{
  const steps = (id: string): boolean => !!regionKind(id)?.visual?.steps;
  const cliff = (id: string): boolean => !!regionKind(id)?.visual?.cliff;
  let rampSteps = true;
  for (let k = 1; k <= MAX_TIER; k++) rampSteps = rampSteps && steps(`peak_ramp_${k}`);
  check('F1 every stepped way declares its treads',
    steps('tier_ramp') && steps('butte_span') && steps('tor_mouth') && rampSteps);
  let terrCliff = true;
  for (let k = 1; k <= MAX_TIER; k++) terrCliff = terrCliff && cliff(`peak_terrace_${k}`);
  check('F2 the open rims declare the cliff read', cliff('butte_top') && terrCliff);
  check('F3 covered layers stay unbroken (no cliff leak)',
    !cliff('tor_gallery') && !cliff('sewer_under_wall') && !cliff('sewer_duct'));
}

// --- Layout harness ------------------------------------------------------------------
const arena = { w: 3400, h: 2500 };
const entry = vec(150, arena.h / 2);
const exits = [vec(arena.w - 150, arena.h / 2), vec(arena.w / 2, 150)];
const THEME = { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' };
function gen(id: string, layoutType: string, layout: StampSpec[], layoutParams: Record<string, unknown>, seed: number,
  genOpts?: { shape?: 'rect' | 'ellipse' }): { out: GeneratedLayout; def: ZoneDef } {
  const def = {
    id, name: `QA ${id}`, level: 8, size: { w: arena.w, h: arena.h },
    theme: THEME, layout, objective: { kind: 'clear' }, exits: [], map: { x: 0, y: 0 },
    layoutType, layoutParams, seed,
    ...(genOpts?.shape ? { shape: genOpts.shape } : {}),
  } as unknown as ZoneDef;
  const out = generateLayout(def, arena, new Rng(seed), entry, exits);
  return { out, def };
}
/** Census + deck-reachability over the tier layers: per STORY, BFS that
 *  story's floor from every link whose span touches it; every floor cell of
 *  the story must be reached (no orphan deck, no orphan bench). */
function tierStats(out: GeneratedLayout, levels = 1): { tierCells: number; linkCells: number; orphan: number } | null {
  const grid = out.walk;
  if (!(grid instanceof GridWalkField)) return null;
  const view = makeTierView(grid);
  const cs = grid.cell;
  const cols = grid.cols, rows = grid.rows;
  const at = (gx: number, gy: number): string => grid.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
  let tierCells = 0, linkCells = 0, orphan = 0;
  const idx = (gx: number, gy: number): number => gy * cols + gx;
  for (let gy = 0; gy < rows; gy++) {
    for (let gx = 0; gx < cols; gx++) {
      const k = at(gx, gy);
      if (tierFloorOf(k)) tierCells++;
      if (tierLinkOf(k)) linkCells++;
    }
  }
  for (let t = 1; t <= levels; t++) {
    const seen = new Uint8Array(cols * rows);
    const q: number[] = [];
    for (let gy = 0; gy < rows; gy++) {
      for (let gx = 0; gx < cols; gx++) {
        const k = at(gx, gy);
        if (!tierLinkOf(k)) continue;
        const [a, b] = linkSpanOf(regionKind(k)!);
        if (a !== t && b !== t) continue;
        const n = idx(gx, gy);
        if (!seen[n]) { seen[n] = 1; q.push(n); }
      }
    }
    for (let h = 0; h < q.length; h++) {
      const c = q[h], cx = c % cols, cy = Math.floor(c / cols);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        const nx = cx + dx, ny = cy + dy;
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
        const n = idx(nx, ny);
        if (seen[n] || !tierFloorAt(at(nx, ny), t)) continue;
        seen[n] = 1; q.push(n);
      }
    }
    for (let gy = 0; gy < rows; gy++) {
      for (let gx = 0; gx < cols; gx++) {
        const k = at(gx, gy);
        if (tierFloorAt(k, t) && !tierLinkOf(k) && !seen[idx(gx, gy)]) orphan++;
      }
    }
  }
  void view;
  return { tierCells, linkCells, orphan };
}

/** THE ASCENT LAW: BFS over (cell, story) states from the valley entry —
 *  same-story steps on that story's floor, story flips on link cells (the
 *  crossing law's graph form). True iff the TOP bench is stood upon. */
function ascentReaches(grid: GridWalkField, from: { x: number; y: number }, top: number): boolean {
  const cs = grid.cell, cols = grid.cols, rows = grid.rows;
  const at = (gx: number, gy: number): string => grid.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
  const idx = (gx: number, gy: number, t: number): number => (t * rows + gy) * cols + gx;
  const seen = new Uint8Array(cols * rows * (top + 1));
  const q: [number, number, number][] = [];
  const g0x = Math.min(cols - 1, Math.max(0, Math.floor(from.x / cs)));
  const g0y = Math.min(rows - 1, Math.max(0, Math.floor(from.y / cs)));
  if (!tierFloorAt(at(g0x, g0y), 0)) return false;
  seen[idx(g0x, g0y, 0)] = 1; q.push([g0x, g0y, 0]);
  for (let h = 0; h < q.length; h++) {
    const [cx, cy, t] = q[h];
    const kHere = at(cx, cy);
    const rkHere = regionKind(kHere);
    if (t === top && rkHere?.tier === top && !rkHere.tierLink) return true;
    if (rkHere?.tierLink) {
      const [a, b] = linkSpanOf(rkHere);
      const other = t === a ? b : t === b ? a : -1;
      if (other >= 0 && other <= top && !seen[idx(cx, cy, other)]) {
        seen[idx(cx, cy, other)] = 1; q.push([cx, cy, other]);
      }
    }
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
      if (seen[idx(nx, ny, t)] || !tierFloorAt(at(nx, ny), t)) continue;
      seen[idx(nx, ny, t)] = 1; q.push([nx, ny, t]);
    }
  }
  return false;
}

// --- RIG C: the needles (open exposure) ---------------------------------------------
{
  const ts = TILESETS.needles;
  for (const seed of [515001, 515002, 515003]) {
    const { out, def } = gen('qa_needles', 'needles', ts.layout, { ...ts.layoutParams }, seed);
    const st = tierStats(out);
    if (!st) { check(`C needles grid (seed ${seed})`, false); continue; }
    check(`C1 the decks STAND (seed ${seed})`, st.tierCells > 150, `cells=${st.tierCells}`);
    check(`C2 the ramps CUT (seed ${seed})`, st.linkCells > 0, `links=${st.linkCells}`);
    check(`C3 no orphan deck (seed ${seed})`, st.orphan === 0, `orphans=${st.orphan}`);
    check(`C4 the zone DECLARES its layer (seed ${seed})`,
      def.tiers?.kind === 'over' && def.tiers?.exposure === 'open');
  }
  const a = gen('qa_needles', 'needles', ts.layout, { ...ts.layoutParams }, 999);
  const b = gen('qa_needles', 'needles', ts.layout, { ...ts.layoutParams }, 999);
  const fp = (o: GeneratedLayout): string => o.doodads.map(d => `${d.kind}:${Math.round(d.pos.x)},${Math.round(d.pos.y)}`).join('|');
  check('C5 needles byte-deterministic', fp(a.out) === fp(b.out));
}

// --- RIG D: the sewer under-lattice (covered exposure) --------------------------------
{
  const metro = TILESETS.metropolis;
  const warrens = metro.variants?.find(v => v.name === 'the warrens');
  let carved = 0, orphans = 0, declared = 0, tried = 0;
  for (const seed of [616001, 616002, 616003, 616004, 616005, 616006]) {
    const { out, def } = gen('qa_warrens', 'district', warrens?.layout ?? metro.layout,
      { ...metro.layoutParams, ...warrens?.layoutParams, sewerTier: 1 }, seed);
    tried++;
    const st = tierStats(out);
    if (!st || st.tierCells === 0) continue; // the lattice honestly declined (no clear legs)
    carved++;
    orphans += st.orphan;
    if (def.tiers?.kind === 'under' && def.tiers?.exposure === 'covered') declared++;
  }
  check('D1 the duct web carves in most warrens', carved >= 4, `${carved}/${tried}`);
  check('D2 no orphan duct anywhere', orphans === 0, `orphans=${orphans}`);
  check('D3 carved zones DECLARE covered/under', declared === carved, `${declared}/${carved}`);
}

// --- RIG E: the switchback summit (the multi-story debut) ------------------------------
{
  const ts = TILESETS.pinnacle;
  check('E0 pinnacle rides the switchback above the crowns',
    ts?.biome === 'highland' && ts?.forceLayout === 'switchback' && hasLayout('switchback')
    && !!ts.depthAffinity && !ts.geoAffinity);
  const runCase = (name: string, params: Record<string, unknown>, seed: number): void => {
    const { out, def } = gen('qa_peak', 'switchback', ts.layout, { ...ts.layoutParams, ...params }, seed);
    const grid = out.walk;
    if (!(grid instanceof GridWalkField)) { check(`${name}: grid stands`, false); return; }
    const lv = def.tiers?.levels ?? 0;
    check(`${name}: the zone declares its stack`,
      def.tiers?.kind === 'over' && def.tiers?.exposure === 'open' && !!def.tiers?.rimDuels && lv >= 2,
      `levels=${lv}`);
    if (lv < 1) return;
    const cs = grid.cell, cols = grid.cols, rows = grid.rows;
    const at = (gx: number, gy: number): string => grid.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    const terr = new Array(lv + 1).fill(0), ramps = new Array(lv + 1).fill(0);
    for (let gy = 0; gy < rows; gy++) {
      for (let gx = 0; gx < cols; gx++) {
        const k = at(gx, gy);
        let m = /^peak_terrace_(\d+)$/.exec(k);
        if (m) { if (+m[1] <= lv) terr[+m[1]]++; continue; }
        m = /^peak_ramp_(\d+)$/.exec(k);
        if (m && +m[1] <= lv) ramps[+m[1]]++;
      }
    }
    const all = (arr: number[]): boolean => { for (let t = 1; t <= lv; t++) if (arr[t] <= 0) return false; return true; };
    check(`${name}: every bench STANDS`, all(terr), JSON.stringify(terr.slice(1)));
    check(`${name}: every rim is CUT`, all(ramps), JSON.stringify(ramps.slice(1)));
    const st = tierStats(out, lv);
    check(`${name}: no orphan bench on any story`, !!st && st.orphan === 0, `orphans=${st?.orphan}`);
    check(`${name}: THE ASCENT LAW — the peak is reached on foot`, ascentReaches(grid, entry, lv));
    check(`${name}: the valley skirt carries every exit`, exits.every(e => grid.reachable(entry, e)));
    // The crown keeps a reward: peakKit furniture stamped to the TOP story.
    const topKit = out.doodads.filter(d => (d as { tier?: number }).tier === lv);
    check(`${name}: the crown is DRESSED (story-stamped kit)`, topKit.length >= 1, `top-tier doodads=${topKit.length}`);
  };
  runCase('E1 the great cone', { peakArc: 'full', peakLevels: [4, 5] }, 717001);
  runCase('E2 the shoulder road', { peakArc: 'half', peakLevels: [3, 4] }, 717002);
  runCase('E3 the rolled face', {}, 717003);
  // Determinism: same seed, byte-equal furniture AND byte-equal ground.
  const fpr = (o: GeneratedLayout): string => {
    const g = o.walk as GridWalkField;
    let s = o.doodads.map(d => `${d.kind}:${Math.round(d.pos.x)},${Math.round(d.pos.y)}`).join('|');
    for (let gy = 0; gy < g.rows; gy += 2) for (let gx = 0; gx < g.cols; gx += 2) s += g.regionAt(gx * g.cell + 15, gy * g.cell + 15).length;
    return s;
  };
  const a = gen('qa_peak', 'switchback', ts.layout, { ...ts.layoutParams }, 717009);
  const b = gen('qa_peak', 'switchback', ts.layout, { ...ts.layoutParams }, 717009);
  check('E4 the summit is byte-deterministic', fpr(a.out) === fpr(b.out));
}

// --- RIG H: THE TOUCH-DOWN LAW (the flight fabric's landing) ---------------------
// landingTier — the story a body wears when its wings fold: keep the current
// story while its floor still stands, else the floor under it answers; true
// walls keep the story for the mover snap to resolve on the body's own layer.
{
  check('H1 a settling body keeps a floor that still stands',
    landingTier('butte_top', 1) === 1 && landingTier('ground', 0) === 0
    && landingTier('tier_ramp', 0) === 0 && landingTier('tier_ramp', 1) === 1
    && landingTier('culvert_well', 1) === 1);
  check('H2 landing over the valley re-seats the valley\'s story',
    landingTier('ground', 1) === 0 && landingTier('ground', 5) === 0);
  check('H3 alighting on a deck wears it — however many stories the climb',
    landingTier('butte_top', 0) === 1 && landingTier('peak_terrace_4', 0) === 4
    && landingTier('peak_terrace_2', 5) === 2);
  check('H4 a true wall keeps the story (the mover snap resolves)',
    landingTier('wall', 1) === 1 && landingTier('wall', 0) === 0);
}

// --- RIG G: THE ELEVATION LAW (sight/shot over the stack) ------------------------
// The one occlusion ray (engine/los.ts castRay + RayElev) judged over a REAL
// needles carve: a blocking cell that is tier FLOOR stops only rays below its
// deck (lerped eye → eye), doodads fill one story of air above their own, and
// the SIGHT VEIL's queries mirror the ray exactly (drawn == tested).
{
  interface P { x: number; y: number }
  interface Spots { A: P; B: P; D: P; R: P; Rin: P; V1: P; V2: P }
  /** Hunt one butte for the rig's seats: two interior deck cells (A, B), a
   *  deep-interior cell D behind rim cell R (Rin = one cell behind R), and
   *  valley points V1 (2 cells out) / V2 (8 cells out) on R's own outward
   *  lane — every lane cell verified so the geometry is the law's, never
   *  the carve's accident. */
  const elevSpots = (grid: GridWalkField): Spots | null => {
    const cs = grid.cell, cols = grid.cols, rows = grid.rows;
    const at = (gx: number, gy: number): string => grid.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    const c = (gx: number, gy: number): P => ({ x: gx * cs + cs / 2, y: gy * cs + cs / 2 });
    const isTop = (gx: number, gy: number): boolean =>
      gx >= 0 && gy >= 0 && gx < cols && gy < rows && at(gx, gy) === 'butte_top';
    const isValley = (gx: number, gy: number): boolean =>
      gx >= 0 && gy >= 0 && gx < cols && gy < rows
      && !tierFloorOf(at(gx, gy)) && grid.isWalkable(gx * cs + cs / 2, gy * cs + cs / 2);
    const interior = (gx: number, gy: number): boolean => {
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!isTop(gx + dx, gy + dy)) return false;
      }
      return true;
    };
    for (let gy = 1; gy < rows - 1; gy++) {
      for (let gx = 1; gx < cols - 1; gx++) {
        // A row-run of ≥ 6 interior cells: A and B are its ends (same deck).
        let run = 0;
        while (interior(gx + run, gy)) run++;
        if (run < 6) continue;
        const A = c(gx, gy), B = c(gx + run - 1, gy);
        // R: a rim cell with an 8-cell straight valley lane outward, and 5
        // straight deck cells behind it (D sits at the fifth).
        for (let ry = 1; ry < rows - 1; ry++) {
          for (let rx = 1; rx < cols - 1; rx++) {
            if (!isTop(rx, ry)) continue;
            for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
              let lane = true;
              for (let k = 1; k <= 8 && lane; k++) lane = isValley(rx + ox * k, ry + oy * k);
              if (!lane) continue;
              let deck = true;
              for (let k = 1; k <= 5 && deck; k++) deck = isTop(rx - ox * k, ry - oy * k);
              if (!deck) continue;
              return {
                A, B, D: c(rx - ox * 5, ry - oy * 5), R: c(rx, ry),
                Rin: c(rx - ox, ry - oy),
                V1: c(rx + ox * 2, ry + oy * 2), V2: c(rx + ox * 8, ry + oy * 8),
              };
            }
          }
        }
      }
    }
    return null;
  };
  let grid: GridWalkField | null = null;
  let spots: Spots | null = null;
  for (const seed of [515001, 515002, 515003, 515004, 515005]) {
    const ts = TILESETS.needles;
    const { out } = gen('qa_needles_elev', 'needles', ts.layout, { ...ts.layoutParams }, seed);
    if (!(out.walk instanceof GridWalkField)) continue;
    const s = elevSpots(out.walk);
    if (s) { grid = out.walk; spots = s; break; }
  }
  check('G0 the rig finds its butte', !!spots);
  if (grid && spots) {
    const { A, B, D, R, Rin, V1, V2 } = spots;
    const eye = LOS_CFG.elev.eye;
    const env = { doodadsAt: () => [] as readonly Doodad[], walk: grid };
    const s = (t: number): { from: number; to: number } => ({ from: t + eye, to: t + eye });
    const pair = (a: number, b: number): { from: number; to: number } => ({ from: a + eye, to: b + eye });
    check('G1 the legacy flat ray still blocks (no elev = the old read)',
      castRay(env, A, B, 'sight') !== null);
    check('G2 a same-story deck duel is open air (sight + shot)',
      castRay(env, A, B, 'sight', s(1)) === null
      && castRay(env, A, B, 'shot', s(1)) === null);
    check('G3 the deep bench hides from the valley (lerped eye line)',
      castRay(env, V1, D, 'sight', pair(0, 1)) !== null);
    check('G4 a near-rim stander is SEEN from afar (the lerp clears the lip)',
      castRay(env, V2, Rin, 'sight', pair(0, 1)) === null
      && castRay(env, V2, R, 'sight', pair(0, 1)) === null);
    check('G5 the flat flight law: valley arrows die on the cliff, deck arrows rain out',
      castRay(env, V1, D, 'shot', s(0)) !== null
      && castRay(env, D, V2, 'shot', s(1)) === null);
    // The doodad story band: a body fills [tier, tier+band) of air.
    const mid = { x: (V2.x + R.x) / 2, y: (V2.y + R.y) / 2 };
    const rock = { pos: vec(mid.x, mid.y), radius: 20, kind: 'rock', rot: 0 } as unknown as Doodad;
    const envRock = { doodadsAt: () => [rock] as readonly Doodad[], walk: null };
    check('G6 a valley trunk stops valley rays and spares the deck flight',
      castRay(envRock, V2, R, 'sight', pair(0, 0)) !== null
      && castRay(envRock, V2, R, 'sight', pair(1, 1)) === null);
    rock.tier = 1;
    check('G7 deck furniture never shades the street below',
      castRay(envRock, V2, R, 'sight', pair(0, 0)) === null
      && castRay(envRock, V2, R, 'sight', pair(1, 1)) !== null);
    // THE VEIL PARITY (render/vis/sightVeil.ts, headless): the drawn pass's
    // queries walk the same lerp — pixels and rays can never disagree.
    const veilAt = (eyeP: P, tier: number, q: P, qT: number): number => {
      const veil = new SightVeil();
      veil.update({
        player: { pos: eyeP, tier }, walk: grid, zone: {},
        doodads: [] as Doodad[], doodadsNear: () => [], doodadRev: 0,
      }, 0, 1400, 1000);
      return veil.occludedAt(q, qT);
    };
    check('G8 veil: a same-story neighbor draws SOLID (the reported bug)',
      veilAt(A, 1, B, 1) === 0);
    check('G9 veil: the deep bench stays dark from the valley',
      veilAt(V1, 0, D, 1) > 0.2);
    check('G10 veil: the rim-stander pokes above the cliff dark',
      veilAt(V2, 0, R, 1) === 0);
    check('G11 veil: the cliff base hides from the deep deck; the far floor shows',
      veilAt(D, 1, V1, 0) > 0.2 && veilAt(D, 1, V2, 0) === 0);
  }
}

// --- RIG I: THE BAND LAW (tether bands vs. masonry) ------------------------------
// A tether band is not a placement but a LINE strung between two anchors, so its
// arc has to run from BOTH of them to the ground it burns (LOS_CFG.tetherLinks +
// World.tetherOcclusion/tetherSees): masonry across the run eats the bite AND the
// ally mend, the attitude is DATA rather than a literal at the tick site, a
// skill's own `occlusion` word still overrides, a phasing owner burns through —
// and every hittable body is refereed against its OWN line, so a serpent's coils
// can never disagree about one pillar.
{
  check('I1 the band lanes are DATA (LOS_CFG.tetherLinks), payload lanes blocked',
    LOS_CFG.tetherLinks.caster === 'blocked' && LOS_CFG.tetherLinks.network === 'blocked'
    && LOS_CFG.tetherLinks.target === 'blocked' && LOS_CFG.tetherLinks.pack === 'blocked'
    // Momentary payload-less visual arcs stay unenrolled — unlisted reads free,
    // exactly as unlisted delivery types do.
    && LOS_CFG.tetherLinks.zap === undefined);

  const w = makeSimWorld('summoner', 0x7be1);
  type Band = ReturnType<typeof makeSimWorld>['tethers'][number];
  const drive = (dt: number): void =>
    (w as unknown as { updateTethers(dt: number): void }).updateTethers(dt);

  // The band runs due east through the arena's middle; ONE wall stands on its
  // line at the midpoint. It severs the run past itself from either end, and
  // shadows nothing that stands wide enough to be seen around.
  const cx = 800, cy = 600;
  const A = { x: cx - 300, y: cy }, B = { x: cx + 300, y: cy };
  const far = { x: cx + 150, y: cy };   // ON the band, east of the wall
  const wide = { x: cx, y: cy + 90 };   // ON the band, wide of the wall
  w.player.pos = vec(A.x, A.y);
  const anchor = w.createMonster('zombie', 3, 'player');
  anchor.pos = vec(B.x, B.y);
  w.actors.push(anchor);
  w.doodads.push({ pos: vec(cx, cy), radius: 50, kind: 'wall' } as never);
  w.markDoodadsChanged();

  check('I2 the fixture is honest: the wall eats the west line to the far seat, and neither line to the wide one',
    !w.lineOfFire(vec(A.x, A.y), vec(far.x, far.y))
    && w.lineOfFire(vec(B.x, B.y), vec(far.x, far.y))
    && w.lineOfFire(vec(A.x, A.y), vec(wide.x, wide.y))
    && w.lineOfFire(vec(B.x, B.y), vec(wide.x, wide.y)));

  /** A fresh body per case — one tether tick is deliberately a heavy blow, so
   *  no seat is ever asked to answer twice. */
  const seat = (team: 'enemy' | 'player', at: { x: number; y: number }): Actor => {
    const e = w.createMonster('zombie', 3, team);
    e.pos = vec(at.x, at.y);
    w.actors.push(e);
    return e;
  };
  /** Re-string the ONE band under test (the attitude resolves once per band,
   *  so every case gets a fresh one). */
  const band = (over: Partial<Band> = {}): Band => {
    const t: Band = {
      a: w.player, b: anchor, owner: w.player,
      skillId: 'probe_band', link: 'target',
      amounts: { physical: 500 }, heal: 0, affects: 'enemies',
      width: 120, remaining: 999, tickTimer: 0, color: '#fff',
      ax: A.x, ay: A.y, bx: B.x, by: B.y,
      ...over,
    };
    w.tethers.length = 0;
    w.tethers.push(t);
    return t;
  };

  {
    const walled = seat('enemy', far), open = seat('enemy', wide);
    const t = band();
    const l0 = walled.life, o0 = open.life;
    drive(0.5);
    check('I3 the band lane reads BLOCKED off the registry', w.tetherOcclusion(t) === 'blocked');
    check('I4 a hostile the band only reaches THROUGH stone takes no tick', walled.life === l0);
    check('I5 ...while one the whole band still reaches is bitten', open.life < o0);
  }
  {
    // The mend obeys the same wall — succor is not a loophole.
    const ally = seat('player', far), mate = seat('player', wide);
    ally.life = 10; mate.life = 10;
    band({ amounts: {}, heal: 200, affects: 'allies' });
    drive(0.5);
    check('I6 a walled-off ally receives no mend either', ally.life === 10);
    check('I7 ...while an ally the band reaches is healed', mate.life > 10);
  }
  {
    // A positive `phasing` on the owner frees the whole band, exactly as it
    // frees every other delivery lane.
    const walled = seat('enemy', far);
    w.player.sheet.setSource('probe_phasing', [mod('phasing', 'flat', 1)]);
    const t = band();
    const l0 = walled.life;
    drive(0.5);
    check('I8 a phasing owner\'s band burns straight through the stone',
      w.tetherOcclusion(t) === 'free' && walled.life < l0);
    w.player.sheet.setSource('probe_phasing', []);
  }
  {
    // The laying skill's own word still overrides the lane default.
    const walled = seat('enemy', far);
    const t = band({ inst: { def: { id: 'probe_free', delivery: { type: 'target', occlusion: 'free' } } } as never });
    const l0 = walled.life;
    drive(0.5);
    check('I9 the skill\'s own `occlusion: free` overrides the lane',
      w.tetherOcclusion(t) === 'free' && walled.life < l0);
  }
  {
    // THE SEGMENT GRAIN: a serpent whose HEAD stands past the wall and whose
    // first coil stands wide of it. Gated once per actor centre the head's
    // blocked line would spare the whole creature; gated per BODY the coil is
    // honestly bitten — and the flash lands on the coil that was actually hit.
    const coiled = seat('enemy', far);
    coiled.worm = {
      length: 1, spacing: 30, taper: 0.9, hittable: true,
      segments: [vec(wide.x, wide.y)],
    };
    band();
    const c0 = coiled.life;
    drive(0.5);
    check('I10 a serpent\'s coils each answer their OWN line (walled head, open coil → the coil bites)',
      coiled.life < c0 && coiled.worm.flash?.[0] === SEG_CFG.flashTime);
  }
}

// --- RIG J: THE PROACTIVE HUNT (per-story pathField + the stair election) --------
// The other half of the tier chase: a pursuer that never SAW a crossing still
// routes onto a link and changes story on its own hunt. World.pathField(story)
// serves each story's own floor (makeTierNav — links as walkable seams), flat
// zones return the identical old field for EVERY story (object identity), and
// the live run drives a deck zombie down a ramp toward a valley player with
// the reactive aiTierGoal lane provably silent throughout.
{
  const w = makeSimWorld('warrior', 0x71e21);
  // THE STREAM LAW (re-pinned 2026-09-06): this rig deals its OWN hand — the
  // sovereignty gate's spacing skip changed how many draws the earlier rigs'
  // AI ticks spend, and J's mints rode the shared stream they left behind.
  seedGlobalRandom(0x71e21);
  const hyp = (a: { x: number; y: number }, b: { x: number; y: number }): number =>
    Math.hypot(a.x - b.x, a.y - b.y);

  // J1 — THE IDENTITY LAW on tier-less ground, both lanes. The sim arena
  // (convex nav) and a farmland mint (walk grid, no def.tiers) must answer
  // every story with the SAME object the flat call returns.
  {
    const f0 = w.pathField();
    check('J1a a tier-less convex zone answers every story with ONE field',
      !!f0 && w.pathField(0) === f0 && w.pathField(3) === f0);
    const zid = w.devMintTileset('farmland', 1, 5, { seed: 909170 });
    const g0 = w.pathField();
    check('J1b a tier-less GRID zone answers every story with the base grid',
      !!zid && !!g0 && w.pathField(0) === g0 && w.pathField(2) === g0 && w.pathField(9) === g0);
  }

  // The needles fixture: mint through the REAL path (placeZoneAt → loadZone),
  // then hunt the carve for the rig's seats — a ramp (link cluster), an
  // interior deck cell a real walk from it, and a valley cell the ramp's foot
  // can reach. Seeds re-rolled until the geometry stands (the RIG G idiom).
  interface JSpots { deck: { x: number; y: number }; ramp: { x: number; y: number }; valley: { x: number; y: number } }
  const findSpots = (grid: GridWalkField): JSpots | null => {
    const cs = grid.cell, cols = grid.cols, rows = grid.rows;
    const at = (gx: number, gy: number): string => grid.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    const c = (gx: number, gy: number): { x: number; y: number } => ({ x: gx * cs + cs / 2, y: gy * cs + cs / 2 });
    const links: [number, number][] = [];
    for (let gy = 1; gy < rows - 1; gy++) {
      for (let gx = 1; gx < cols - 1; gx++) if (tierLinkOf(at(gx, gy))) links.push([gx, gy]);
    }
    for (const [lx, ly] of links) {
      // The link's own story-1 country: BFS deck floor (links included) and
      // keep the interior deck cells (all four neighbours story-1 floor).
      const seen = new Uint8Array(cols * rows);
      const q: number[] = [ly * cols + lx];
      seen[ly * cols + lx] = 1;
      const deck: [number, number][] = [];
      for (let h = 0; h < q.length; h++) {
        const cell = q[h], cx = cell % cols, cy = Math.floor(cell / cols);
        const k = at(cx, cy);
        if (tierFloorAt(k, 1) && !tierLinkOf(k)) {
          let interior = true;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
            if (!tierFloorAt(at(cx + dx, cy + dy), 1)) { interior = false; break; }
          }
          if (interior) deck.push([cx, cy]);
        }
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
          const nx = cx + dx, ny = cy + dy;
          if (nx < 1 || ny < 1 || nx >= cols - 1 || ny >= rows - 1) continue;
          const n = ny * cols + nx;
          if (seen[n] || !tierFloorAt(at(nx, ny), 1)) continue;
          seen[n] = 1; q.push(n);
        }
      }
      // The hunter's seat: an interior deck cell a REAL march from the stair
      // (5–10 cells — routing, not adjacency), yet near enough that the
      // whole fixture fits one detection bubble.
      let seat: [number, number] | null = null, seatD = 0;
      for (const [gx, gy] of deck) {
        const d = Math.hypot(gx - lx, gy - ly);
        if (d >= 5 && d <= 10 && d > seatD) { seatD = d; seat = [gx, gy]; }
      }
      if (!seat) continue;
      // The quarry's ground: open valley floor (no story above it), a
      // mid-range walk from the stair's foot, connected to it, and inside
      // the hunter's detect bubble (≤ 13 cells ≈ 390 px < the warrior's 442).
      const ramp = c(lx, ly);
      let valley: { x: number; y: number } | null = null, vScore = Infinity;
      for (let gy = 1; gy < rows - 1; gy++) {
        for (let gx = 1; gx < cols - 1; gx++) {
          const k = at(gx, gy);
          if (tierFloorOf(k) || tierLinkOf(k)) continue;
          const p = c(gx, gy);
          if (!grid.isWalkable(p.x, p.y)) continue;
          const dCells = Math.hypot(gx - lx, gy - ly);
          if (dCells < 8 || dCells > 14) continue;
          if (Math.hypot(gx - seat[0], gy - seat[1]) > 13) continue;
          // RIM STANDOFF: no story floor within 4 cells — a rim-duel claw
          // from the lip must never reach the quarry, so the DESCENT is the
          // only road to blood (the thing under test).
          let standoff = true;
          for (let oy = -4; oy <= 4 && standoff; oy++) {
            for (let ox = -4; ox <= 4; ox++) {
              const nx = gx + ox, ny = gy + oy;
              if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
              if (tierFloorOf(at(nx, ny))) { standoff = false; break; }
            }
          }
          if (!standoff) continue;
          const score = Math.abs(dCells - 12);
          if (score < vScore && grid.reachable(vec(ramp.x, ramp.y), vec(p.x, p.y))) {
            vScore = score; valley = p;
          }
        }
      }
      if (valley) return { deck: c(seat[0], seat[1]), ramp, valley };
    }
    return null;
  };

  let grid: GridWalkField | null = null;
  let spots: JSpots | null = null;
  for (const [i, seed] of [909171, 909172, 909173].entries()) {
    const zid = w.devMintTileset('needles', 2 + i, 8, { seed, layoutType: 'needles' });
    if (!zid) continue;
    const pf = w.pathField(0);
    if (!(pf instanceof GridWalkField)) continue;
    const s = findSpots(pf);
    if (s) { grid = pf; spots = s; break; }
  }
  check('J0 the rig finds its butte, stair and valley', !!grid && !!spots);

  if (grid && spots) {
    const { deck, ramp, valley } = spots;
    // A quiet stage: the mint's own fauna leaves (this rig hunts alone).
    for (const a of w.actors) if (a !== w.player) a.dead = true;
    w.update(1 / 30);
    w.player.pos = vec(valley.x, valley.y);
    w.player.tier = 0;

    // J2 — the per-story field itself.
    const pf1 = w.pathField(1);
    check('J2a story 1 gets its OWN field; story 0 keeps the base grid',
      !!pf1 && pf1 !== grid && w.pathField(0) === grid && w.pathField() === grid);
    if (pf1) {
      check('J2b the deck is floor up here and wall below',
        pf1.isWalkable(deck.x, deck.y) && !grid.isWalkable(deck.x, deck.y));
      check('J2c the valley is floor below and wall up here',
        !pf1.isWalkable(valley.x, valley.y) && grid.isWalkable(valley.x, valley.y));
      check('J2d the link is a SEAM — floor on BOTH fields',
        pf1.isWalkable(ramp.x, ramp.y) && grid.isWalkable(ramp.x, ramp.y));
      check('J2e the story field is cached (one object per story per grid)',
        w.pathField(1) === pf1);
    }

    // J3 — the stair election, unit grain. The hunter is chosen with care:
    // the shambling zombie is AUTHORED mindless (pathing 'none' — it can
    // never elect anything), and tight-range kernels (the flanker's orbit)
    // steer DIRECTLY once in band — only the basic APPROACH kernel walks
    // moveToward the whole way in, which is the lane under test. A skeleton
    // warrior: basic brain, field pathing, breathless bone (no kite lapse).
    const m = w.createMonster('skeleton_warrior', 8, 'enemy');
    m.pos = vec(deck.x, deck.y);
    m.tier = 1;
    w.actors.push(m);
    const seat = w.tierLinkToward(m, valley);
    check('J3a the election returns a crossing on the hunter\'s own floor',
      !!seat && tierLinkOf(pf1?.regionAt?.(seat.x, seat.y)) && (pf1?.isWalkable(seat.x, seat.y) ?? false),
      seat ? `${Math.round(seat.x)},${Math.round(seat.y)}` : 'null');
    check('J3b an own-floor goal elects nothing (the field handles it)',
      w.tierLinkToward(m, deck) === null);

    // J4 — THE LIVE CROSSING: the deck hunter, engagement held (the rim
    // duel: target + aggro + the alerted all-around gaze re-primed per
    // frame — brains are the CALLER's to tick, the main.ts/runner idiom),
    // no crossing ever witnessed — it must elect the ramp, ride the ladder
    // toggle and close on the valley player, with the REACTIVE goal lane
    // silent the whole run.
    const d0 = hyp(m.pos, w.player.pos);
    // The quarry is the fixture, not the fight: tank it through the SHEET
    // (a life mod never gates targeting the way `invulnerable` would).
    w.player.sheet.setSource('probe_tank', [mod('life', 'flat', 1e6)]);
    w.player.life = w.player.maxLife();
    let sawLink = false, usedReactive = false;
    let steps = 0;
    for (; steps < 1800; steps++) {
      m.aiTargetId = w.player.id;
      m.aggroed = true;
      m.alertUntil = w.time + 5;
      for (const a of w.actors) updateAI(a, w, 1 / 30);
      w.update(1 / 30);
      sawLink = sawLink || m.onTierLink;
      usedReactive = usedReactive || m.aiTierGoal !== undefined;
      if (m.tier === 0 && !m.onTierLink && hyp(m.pos, w.player.pos) < 240) break;
      if (m.dead || w.player.dead) break;
    }
    const d1 = hyp(m.pos, w.player.pos);
    check('J4a the un-witnessed hunter crosses a link and changes story',
      !m.dead && m.tier === 0 && sawLink,
      `tier=${m.tier} link=${sawLink} dead=${m.dead} steps=${steps}`);
    check('J4b ...proactively — the reactive aiTierGoal lane stayed silent', !usedReactive);
    check('J4c ...and closes on the valley player', d1 < 240 && d1 < d0,
      `dist ${Math.round(d0)} → ${Math.round(d1)}`);
    check('J4d the quarry never crossed (the un-witnessed premise held)', w.player.tier === 0);
    // J5 — the crossing rode the LADDER TOGGLE: the zone-local ledger (the
    // reactive lane's source, untouched by this pass) stamped the hunter.
    const crossings = (w as unknown as { tierCrossings: { actorId: number }[] }).tierCrossings;
    check('J5 the ledger stamped the hunter\'s own crossing', crossings.some(r => r.actorId === m.id),
      `${crossings.length} stamped`);

    // J6 — THE SEVERED BAND (TIER_CFG.severedBandReach): the same fixture,
    // a FLANKER-brain hunter. Its orbit kernel steers directly once flat
    // distance sits in band — before the deferral it pinned at the rim
    // above the quarry for a full minute, the stair election one cell away
    // and never consulted (the measured stall this law exists for). Severed
    // now, runKernel yields to the approach lane and it crosses like the
    // warrior did.
    m.dead = true; // the warrior leaves the stage
    w.update(1 / 30);
    const g = w.createMonster('deadwake_ghoul', 8, 'enemy');
    g.pos = vec(deck.x, deck.y);
    g.tier = 1;
    w.actors.push(g);
    const gd0 = hyp(g.pos, w.player.pos);
    let gSawLink = false, gReactive = false;
    let gSteps = 0;
    for (; gSteps < 1800; gSteps++) {
      g.aiTargetId = w.player.id;
      g.aggroed = true;
      g.alertUntil = w.time + 5;
      for (const a of w.actors) updateAI(a, w, 1 / 30);
      w.update(1 / 30);
      gSawLink = gSawLink || g.onTierLink;
      gReactive = gReactive || g.aiTierGoal !== undefined;
      if (g.tier === 0 && !g.onTierLink && hyp(g.pos, w.player.pos) < 240) break;
      if (g.dead || w.player.dead) break;
    }
    const gd1 = hyp(g.pos, w.player.pos);
    check('J6a THE SEVERED BAND: the flanker defers its orbit and crosses',
      !g.dead && g.tier === 0 && gSawLink,
      `tier=${g.tier} link=${gSawLink} steps=${gSteps}`);
    check('J6b ...closing like the warrior did', gd1 < 240 && gd1 < gd0,
      `dist ${Math.round(gd0)} → ${Math.round(gd1)}`);
    check('J6c ...with the reactive lane still silent', !gReactive);

    // J7 — THE REACH GATE at unit grain (mint-independent by design: LIVE
    // archer conduct is legitimately free — a blocked volley lane lets
    // approach march and honestly elect the stair, which is the PREVIOUS
    // law working — so this rig pins the severed-band VERDICT at its own
    // exported seam, never the walk).
    g.dead = true;
    w.update(1 / 30);
    const ar = w.createMonster('skeleton_archer', 8, 'enemy');
    ar.pos = vec(deck.x, deck.y);
    ar.tier = 1;
    w.actors.push(ar);
    const g2 = w.createMonster('deadwake_ghoul', 8, 'enemy');
    g2.pos = vec(deck.x, deck.y);
    g2.tier = 1;
    w.actors.push(g2);
    const ctxOf = (a: Actor): KernelCtx =>
      ({ a, world: w, target: w.player, spec: {}, goal: w.player.pos } as unknown as KernelCtx);
    const sg = severedBandGoal(ctxOf(g2), 'orbit');
    check('J7a the melee band reads SEVERED (claw cannot cross a story)',
      !!sg && Math.abs(sg.x - w.player.pos.x) < 1 && Math.abs(sg.y - w.player.pos.y) < 1);
    check('J7b a kit that RAINS OUT never defers (bone_arrow 470 > the reach dial)',
      severedBandGoal(ctxOf(ar), 'approach') === null
      && severedBandGoal(ctxOf(ar), 'orbit') === null);
    check('J7c stand-ground styles are exempt however short the kit',
      severedBandGoal(ctxOf(g2), 'hold') === null
      && severedBandGoal(ctxOf(g2), 'turtle') === null
      && severedBandGoal(ctxOf(g2), 'interpose') === null);
    check('J7d authored mindlessness never defers',
      severedBandGoal({ ...ctxOf(g2), spec: { style: 'orbit', pathing: 'none' } } as KernelCtx, 'orbit') === null);
    g2.tier = 0; // a valley hunter shares the quarry's floor —
    check('J7e a shared floor reads no severance', severedBandGoal(ctxOf(g2), 'orbit') === null);
  }
}

// --- RIG M: THE MAP TELL (the world map's tier read, ui/panels.ts) ----------------
// tierMapTell distills ZoneDef.tiers for the map node — PURE, fog-gated by the
// SAME predicate the biome fill and zone-kind glyph ride (the loop's
// `known || scouted` arrives as `revealed`): null on flat ground, null while
// fogged, 'open' and 'covered' exposures distinguishable at a glance, the
// stack hinted through `floors`. The real recipes then ground it: minted
// needles / warrens / switchback defs speak through the same helper the
// panel calls.
{
  check('M1 flat ground tells nothing', tierMapTell({}, true) === null);
  const open = tierMapTell({ tiers: { kind: 'over', exposure: 'open' } }, true);
  const covered = tierMapTell({ tiers: { kind: 'under', exposure: 'covered' } }, true);
  check('M2 an open two-layer zone tells its stack', open?.mark === 'open' && open?.floors === 2);
  check('M3 a covered lattice tells its stack', covered?.mark === 'covered' && covered?.floors === 2);
  check('M4 the two exposures read DIFFERENT', !!open && !!covered
    && open.mark !== covered.mark && open.tint !== covered.tint);
  check('M5 THE FOG GATE: an unrevealed zone keeps its secret',
    tierMapTell({ tiers: { kind: 'over', exposure: 'open' } }, false) === null
    && tierMapTell({}, false) === null);
  const stack = tierMapTell({ tiers: { kind: 'over', exposure: 'open', levels: 3 } }, true);
  check('M6 a multi-story stack hints TALLER than the classic pair',
    !!stack && !!open && stack.floors > open.floors, `floors=${stack?.floors}`);
  const tall = tierMapTell({ tiers: { kind: 'over', exposure: 'open', levels: 9 } }, true);
  check('M7 ...clamped to what a node can legibly stack', tall?.floors === stack?.floors);
  // The real stamps: the defs the recipes mint (RIG C/D/E's own fixtures)
  // answer through the helper exactly as the authored shapes did.
  const nd = gen('qa_map_needles', 'needles', TILESETS.needles.layout,
    { ...TILESETS.needles.layoutParams }, 515001);
  check('M8 a minted needles def tells open — and only once revealed',
    tierMapTell(nd.def, true)?.mark === 'open' && tierMapTell(nd.def, false) === null);
  const metro = TILESETS.metropolis;
  const warrens = metro.variants?.find(v => v.name === 'the warrens');
  let carved = 0, told = 0;
  for (const seed of [616001, 616002, 616003, 616004, 616005, 616006]) {
    const { def } = gen('qa_map_warrens', 'district', warrens?.layout ?? metro.layout,
      { ...metro.layoutParams, ...warrens?.layoutParams, sewerTier: 1 }, seed);
    if (!def.tiers) continue; // the lattice honestly declined (RIG D's tolerance)
    carved++;
    if (tierMapTell(def, true)?.mark === 'covered') told++;
  }
  check('M9 every carved warren tells covered', carved >= 1 && told === carved, `${told}/${carved}`);
  const pk = gen('qa_map_peak', 'switchback', TILESETS.pinnacle.layout,
    { ...TILESETS.pinnacle.layoutParams }, 717001);
  check('M10 a minted summit stacks taller than the classic pair',
    tierMapTell(pk.def, true)?.floors === 3, `floors=${tierMapTell(pk.def, true)?.floors}`);
}

// --- RIG N: THE UNDER-TIER LANES + THE ROOT TIER (batch 23 — THE ROOTED WEB) ------
// The sewer carve generalized into a REGISTERED vocabulary (UNDER_TIER_LANES,
// engine/tiers.ts) and the garden's debut lane: root galleries sunk beneath
// the plot's floor, dialed by `underTier`/`underTierChance` at the
// generateLayout tail (any recipe, no recipe edits — the trapworks-pass
// idiom), taproot throats as the crossings, and the surface faces' taproot
// gates pulled down into the galleries STORY-STAMPED (doorTier 'seat' —
// drawn == dwelled from below; World's mouthTier gate is the runtime half).
{
  // N1 the registry: both lanes stand; the roots lane seats the garden door.
  check('N1 the lane registry', !!UNDER_TIER_LANES.sewer && !!UNDER_TIER_LANES.roots
    && UNDER_TIER_LANES.roots.deepDoorKinds?.includes('taproot_gate') === true
    && UNDER_TIER_LANES.roots.doorTier === 'seat'
    && UNDER_TIER_LANES.sewer.doorTier === undefined);
  const duct = regionKind('root_duct'), well = regionKind('root_well');
  check('N2 root_duct: the plot above keeps its face',
    !!duct && !!duct.walkable && duct.tier === 1 && !duct.visual && !!duct.tierVisual);
  check('N3 root_well is a CROSSING', !!well?.tierLink && !!well?.walkable && well.tier === 1);
  // N4-N8 the carve on a real garden face (petalfields' parkland recipe),
  // chance forced — gates forced too, so the relocation has bodies to seat.
  const pf = TILESETS.petalfields;
  let carved = 0, declared = 0, throats = 0, orphans = 0;
  let sunkGates = 0, sunkOffStory = 0, surfGates = 0;
  for (const seed of [818001, 818002, 818003, 818004, 818005, 818006]) {
    const { out, def } = gen('qa_roots', 'parkland',
      [...pf.layout, { kind: 'taproot_gate', count: [2, 2] } as StampSpec],
      { ...pf.layoutParams, underTier: 'roots', underTierChance: 1 }, seed);
    const st = tierStats(out);
    if (!st || st.tierCells === 0) continue; // the lattice honestly declined (RIG D's tolerance)
    carved++;
    orphans += st.orphan;
    if (def.tiers?.kind === 'under' && def.tiers?.exposure === 'covered'
      && def.tiers?.lane === 'roots') declared++;
    throats += out.doodads.filter(d => d.kind === 'taproot_throat').length;
    const grid = out.walk as GridWalkField;
    for (const d of out.doodads) {
      if (d.kind !== 'taproot_gate') continue;
      if ((d as { tier?: number }).tier === 1) {
        sunkGates++;
        // drawn == dwelled: a sunken gate stands on the story's own floor.
        const k = grid.regionAt(d.pos.x, d.pos.y);
        if (!(k === 'root_duct' || k === 'root_well')) sunkOffStory++;
      } else surfGates++;
    }
  }
  check('N4 the root tier carves in most plots', carved >= 4, `${carved}/6`);
  check('N5 carved plots DECLARE covered/under + the lane', declared === carved, `${declared}/${carved}`);
  check('N6 every carved plot wears its throats', carved === 0 || throats >= carved * 2, `throats=${throats}`);
  check('N7 no orphan gallery anywhere', orphans === 0, `orphans=${orphans}`);
  check('N8 gates SINK story-stamped onto the story\'s own floor',
    sunkGates >= 1 && sunkOffStory === 0,
    `sunk=${sunkGates} offStory=${sunkOffStory} surface=${surfGates}`);
  // N9 absent == identical: a dial-less plot mints flat — no root region, no
  // tiers stamp (the tail pass reads nothing, draws nothing).
  {
    const { underTier: _u, underTierChance: _c, ...flat } = (pf.layoutParams ?? {}) as Record<string, unknown>;
    const { out, def } = gen('qa_roots_flat', 'parkland', pf.layout, flat, 818001);
    const st = tierStats(out);
    check('N9 absent == identical: no dial, no layer',
      (st?.tierCells ?? 0) === 0 && def.tiers === undefined);
  }
  // N10 determinism: same seed, byte-equal furniture AND ground.
  const fpN = (o: GeneratedLayout): string => {
    const g = o.walk as GridWalkField;
    let s = o.doodads.map(d => `${d.kind}:${Math.round(d.pos.x)},${Math.round(d.pos.y)}:${(d as { tier?: number }).tier ?? 0}`).join('|');
    for (let gy = 0; gy < g.rows; gy += 2) for (let gx = 0; gx < g.cols; gx += 2) s += g.regionAt(gx * g.cell + 15, gy * g.cell + 15).length;
    return s;
  };
  const na = gen('qa_roots', 'parkland', [...pf.layout, { kind: 'taproot_gate', count: [2, 2] } as StampSpec],
    { ...pf.layoutParams, underTier: 'roots', underTierChance: 1 }, 818009);
  const nb = gen('qa_roots', 'parkland', [...pf.layout, { kind: 'taproot_gate', count: [2, 2] } as StampSpec],
    { ...pf.layoutParams, underTier: 'roots', underTierChance: 1 }, 818009);
  check('N10 the root tier is byte-deterministic', fpN(na.out) === fpN(nb.out));
}

// --- RIG N2: THE SECOND LANE (batch 24 — the crypts under the downs) --------------
// The vocabulary's proof of generality: a THIRD row (sewer/roots/crypts)
// registered from its own kit file (data/catacombs.ts, loaded via the sim
// arena's side-effect imports), carving the SAME engine with nothing but
// different data — bone regions, lych stairs, the downs' named crypt gates
// sunk story-stamped. Grammar = RIG N's, verbatim, on the downs' own massif
// recipe (a mint that rolls another fabric's layer first — the massif bores
// — honestly declines: one zone, one stack; the carve rate absorbs it).
{
  check('N2.1 the crypts lane registry (kit-file registration)',
    !!UNDER_TIER_LANES.crypts
    && UNDER_TIER_LANES.crypts.deepDoorKinds?.includes('crypt_gate') === true
    && UNDER_TIER_LANES.crypts.doorTier === 'seat'
    && UNDER_TIER_LANES.crypts.duct === 'crypt_duct'
    && UNDER_TIER_LANES.crypts.stairKind === 'crypt_stair');
  const duct = regionKind('crypt_duct'), well = regionKind('crypt_well');
  check('N2.2 crypt_duct: the turf above keeps its face',
    !!duct && !!duct.walkable && duct.tier === 1 && !duct.visual && !!duct.tierVisual);
  check('N2.3 crypt_well is a CROSSING', !!well?.tierLink && !!well?.walkable && well.tier === 1);
  const dn = TILESETS.downs;
  check('N2.4 the downs SHIP the dial (underTier crypts on the base face)',
    (dn.layoutParams as Record<string, unknown> | undefined)?.underTier === 'crypts');
  let carved = 0, declared = 0, stairs = 0, orphans = 0;
  let sunkGates = 0, sunkOffStory = 0, surfGates = 0;
  for (const seed of [824001, 824002, 824003, 824004, 824005, 824006]) {
    const { out, def } = gen('qa_crypts', 'massif',
      [...dn.layout, { kind: 'crypt_gate', count: [2, 2] } as StampSpec],
      { ...dn.layoutParams, underTier: 'crypts', underTierChance: 1 }, seed);
    const st = tierStats(out);
    if (!st || st.tierCells === 0) continue; // another layer stood first, or the lattice declined
    if (def.tiers?.kind === 'under' && def.tiers?.lane === 'crypts' && def.tiers?.exposure === 'covered') declared++;
    else continue; // a massif-bore layer is not this rig's business
    carved++;
    orphans += st.orphan;
    stairs += out.doodads.filter(d => d.kind === 'crypt_stair').length;
    const grid = out.walk as GridWalkField;
    for (const d of out.doodads) {
      if (d.kind !== 'crypt_gate') continue;
      if ((d as { tier?: number }).tier === 1) {
        sunkGates++;
        // drawn == dwelled: a sunken gate stands on the story's own floor.
        const k = grid.regionAt(d.pos.x, d.pos.y);
        if (!(k === 'crypt_duct' || k === 'crypt_well')) sunkOffStory++;
      } else surfGates++;
    }
  }
  check('N2.5 the crypts carve under most heaths', carved >= 3, `${carved}/6`);
  check('N2.6 every carved heath wears its lych stairs', carved === 0 || stairs >= carved * 2, `stairs=${stairs}`);
  check('N2.7 no orphan gallery anywhere', orphans === 0, `orphans=${orphans}`);
  check('N2.8 crypt gates SINK story-stamped onto the story\'s own floor',
    sunkGates >= 1 && sunkOffStory === 0,
    `sunk=${sunkGates} offStory=${sunkOffStory} surface=${surfGates}`);
  // absent == identical: strip the SHIPPED dial — the heath mints FLAT (no
  // crypt region, no lane-tagged tiers stamp).
  {
    const { underTier: _u, underTierChance: _c, ...flat } = (dn.layoutParams ?? {}) as Record<string, unknown>;
    const { out, def } = gen('qa_crypts_flat', 'massif', dn.layout, flat, 824001);
    const flatCrypt = ((): boolean => {
      const g = out.walk;
      if (!(g instanceof GridWalkField)) return false;
      for (let gy = 0; gy < g.rows; gy++) {
        for (let gx = 0; gx < g.cols; gx++) {
          const k = g.regionAt(gx * g.cell + 15, gy * g.cell + 15);
          if (k === 'crypt_duct' || k === 'crypt_well') return true;
        }
      }
      return false;
    })();
    check('N2.9 absent == identical: no dial, no crypt layer',
      !flatCrypt && def.tiers?.lane !== 'crypts');
  }
  // Determinism: same seed, byte-equal furniture AND ground.
  const fpN2 = (o: GeneratedLayout): string => {
    const g = o.walk as GridWalkField;
    let s = o.doodads.map(d => `${d.kind}:${Math.round(d.pos.x)},${Math.round(d.pos.y)}:${(d as { tier?: number }).tier ?? 0}`).join('|');
    for (let gy = 0; gy < g.rows; gy += 2) for (let gx = 0; gx < g.cols; gx += 2) s += g.regionAt(gx * g.cell + 15, gy * g.cell + 15).length;
    return s;
  };
  const na2 = gen('qa_crypts', 'massif', [...dn.layout, { kind: 'crypt_gate', count: [2, 2] } as StampSpec],
    { ...dn.layoutParams, underTier: 'crypts', underTierChance: 1 }, 824009);
  const nb2 = gen('qa_crypts', 'massif', [...dn.layout, { kind: 'crypt_gate', count: [2, 2] } as StampSpec],
    { ...dn.layoutParams, underTier: 'crypts', underTierChance: 1 }, 824009);
  check('N2.10 the crypt tier is byte-deterministic', fpN2(na2.out) === fpN2(nb2.out));
  // N2.11 THE RIM LAW (task_e2243782): the SAME carve on an ELLIPSE def — the
  // playable ground is the inscribed ellipse (clampPos projects every body
  // inside it), the carve grid is rect-blind, and the corners the rim seals
  // off are exactly where the farthest-seat preferences loved to seat doors
  // (the 264px dead-door divergence). Every DWELL fixture — crypt gates on
  // BOTH stories, the wells' lych stairs — must stand inside the rim at the
  // mouth clamp's own 28u margin (the math re-derived here, deliberately not
  // imported: the rig must not test through the law it pins), and the lane
  // must still FUNCTION on ellipse ground (the law heals seats, never
  // starves the layer).
  {
    const inRim = (p: { x: number; y: number }): boolean => {
      const rx = Math.max(8, arena.w / 2 - 28), ry = Math.max(8, arena.h / 2 - 28);
      const nx = (p.x - arena.w / 2) / rx, ny = (p.y - arena.h / 2) / ry;
      return nx * nx + ny * ny <= 1;
    };
    let outOfRim = 0, sunkE = 0, stairsE = 0, gatesE = 0;
    for (const seed of [824021, 824022, 824023, 824024, 824025, 824026]) {
      const { out } = gen('qa_crypts_ellipse', 'massif',
        [...dn.layout, { kind: 'crypt_gate', count: [2, 2] } as StampSpec],
        { ...dn.layoutParams, underTier: 'crypts', underTierChance: 1 }, seed, { shape: 'ellipse' });
      for (const d of out.doodads) {
        if (d.kind !== 'crypt_gate' && d.kind !== 'crypt_stair') continue;
        if (d.kind === 'crypt_gate') { gatesE++; if ((d as { tier?: number }).tier === 1) sunkE++; }
        else stairsE++;
        if (!inRim(d.pos)) outOfRim++;
      }
    }
    check('N2.11 the rim law: every ellipse dwell seat (gates + stairs) stands inside the rim',
      outOfRim === 0, `${outOfRim} beyond the rim (gates=${gatesE} sunk=${sunkE} stairs=${stairsE})`);
    check('N2.11b the ellipse lane still functions (sunk gates + stairs exist across the seeds)',
      sunkE >= 1 && stairsE >= 2, `sunk=${sunkE} stairs=${stairsE}`);
  }
}

// --- RIG N3: THE ARRIVAL STORY (the arrivalStory law — batch 25) ------------------
// Arianna's live report (2026-08-03): entering the Undergrowth THROUGH a
// story-seated taproot gate left her IMMOBILE in the pocket (the stale layer
// index met the cave's empty tier view at every clamp), and the climb-out
// stood her on the plot face ABOVE the gallery instead of at the door. The
// law pinned here, both directions, on REAL minted geometry:
//   inbound — a zone arrival lands on the GROUND story (tier 0) and a real
//     step lands (mobility is the symptom, so mobility is the assert);
//   outbound — the climb-out re-seats the party at the mouth ON the mouth's
//     own recorded story (caveReturn.tier), standing on story floor, mobile;
//   the rung — the exact-resume ladder writes + rebuilds the story, so her
//     literal repro (restart mid-cave, then exit) lands story-true too;
//   the classic mouth — tier-0 doors keep the classic step-off bytes.
// Downs twin (crypt gates → the catacombs) walks the same law.
{
  seedGlobalRandom(0xa15701);
  type N3Cm = { pos: { x: number; y: number }; seed: number; kind: string; underSpan?: string; mouthTier?: number };
  type N3Innards = {
    enterSidezone(cm: { pos: { x: number; y: number }; seed: number; kind: string; underSpan?: string }): void;
    travelThrough(e: { to: string; side: 'n' | 's' | 'e' | 'w' }): void;
    caveEntrances: N3Cm[];
    walk: { regionAt?(x: number, y: number): string } | null;
  };
  const regionAtOf = (w: ReturnType<typeof makeSimWorld>, x: number, y: number): string | undefined =>
    innardsOf(w).walk?.regionAt?.(x, y);
  const innardsOf = (w: ReturnType<typeof makeSimWorld>): N3Innards => w as unknown as N3Innards;
  /** Strip live hostiles so the walk asserts measure the GRID, not a shove. */
  const clearField = (w: ReturnType<typeof makeSimWorld>): void => {
    for (const a of w.actors) { if (a.team === 'enemy' && !a.dead) a.dead = true; }
  };
  /** Best displacement over four compass walks from `seat` (real moveActor
   *  steps — the immobility bug refused every one of these). */
  const bestStep = (w: ReturnType<typeof makeSimWorld>, seat: { x: number; y: number }): number => {
    let best = 0;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      w.player.pos.x = seat.x; w.player.pos.y = seat.y;
      for (let i = 0; i < 6; i++) w.moveActor(w.player, dx, dy, 0.1);
      best = Math.max(best, Math.hypot(w.player.pos.x - seat.x, w.player.pos.y - seat.y));
    }
    w.player.pos.x = seat.x; w.player.pos.y = seat.y;
    return best;
  };
  /** Mint tileset zones on pinned seeds until one carries a SUNK named gate
   *  (mouthTier 1 — the relocated door on the story's own floor). */
  const mintWithSunkGate = (
    w: ReturnType<typeof makeSimWorld>, tileset: string, gate: string, seeds: number[],
  ): { zoneId: string; cm: N3Cm } | null => {
    for (let i = 0; i < seeds.length; i++) {
      const zid = w.devMintTileset(tileset, i, 8, { seed: seeds[i] });
      if (!zid) continue;
      const cm = innardsOf(w).caveEntrances.find(en => en.kind === gate && en.mouthTier === 1);
      if (cm) return { zoneId: zid, cm };
    }
    return null;
  };
  const walkLane = (label: string, tileset: string, gate: string, seeds: number[]): void => {
    const w = makeSimWorld('warrior', 0x1157);
    w.player.invulnerable = true;
    const found = mintWithSunkGate(w, tileset, gate, seeds);
    check(`N3.1 ${label}: a mint stands with a SUNK ${gate} (story-seated door)`, !!found);
    if (!found) return;
    const inN = innardsOf(w);
    const gardenId = w.zone.id;
    const mouthAt = { x: found.cm.pos.x, y: found.cm.pos.y };
    // The dwell's honest state: standing ON the gate, on ITS story (the
    // mouthTier gate guarantees this pairing live; the probe reaches the
    // private seam structurally — the dwell is merely enterSidezone's input).
    w.player.pos.x = mouthAt.x; w.player.pos.y = mouthAt.y;
    w.player.tier = 1;
    inN.enterSidezone(found.cm);
    check(`N3.2 ${label}: the gate opens a pocket`, w.zone.id.startsWith('cave_'), w.zone.id);
    const pocketId = w.zone.id;
    // INBOUND — the arrival story is the GROUND story, and a step LANDS.
    check(`N3.3 ${label}: the arrival wears the ground story (tier 0)`, w.player.tier === 0, `tier=${w.player.tier}`);
    clearField(w);
    const inStep = bestStep(w, { x: w.player.pos.x, y: w.player.pos.y });
    check(`N3.4 ${label}: the arrival is MOBILE (a real step lands)`, inStep > 15, `step=${inStep.toFixed(1)}px`);
    check(`N3.5 ${label}: the rung remembers the mouth's story`, w.caveReturn?.tier === 1,
      `caveReturn.tier=${w.caveReturn?.tier}`);
    // THE RUNG — the save writes the story; the rebuild restores it (her
    // literal repro: restart mid-cave, THEN climb out).
    const save = w.serializeWorldState();
    const rungs = save.player?.cave?.rungs ?? [];
    check(`N3.6 ${label}: the written rung carries the story`,
      rungs.length >= 1 && rungs[rungs.length - 1].tier === 1,
      `rungs=${JSON.stringify(rungs.map(r => r.tier ?? 0))}`);
    const w2 = makeSimWorld('warrior', 0x1158);
    w2.player.invulnerable = true;
    const adopted = w2.adoptWorldState(save);
    w2.resumeSpawn('exact', save.player);
    check(`N3.7 ${label}: the resumed wake stands in the pocket with the rung's story rebuilt`,
      adopted && w2.zone.id === pocketId && w2.caveReturn?.tier === 1,
      `zone=${w2.zone.id} tier=${w2.caveReturn?.tier}`);
    // OUTBOUND on the RESUMED world (the restart repro): climb out, land ON
    // the mouth wearing ITS story, standing on story floor, mobile.
    clearField(w2);
    innardsOf(w2).travelThrough({ to: gardenId, side: 'n' });
    const p2 = w2.player;
    const dBack = Math.hypot(p2.pos.x - mouthAt.x, p2.pos.y - mouthAt.y);
    check(`N3.8 ${label}: the climb-out stands AT the door (no step off a sunken mouth)`,
      w2.zone.id === gardenId && dBack < 2, `zone=${w2.zone.id} d=${dBack.toFixed(1)}`);
    const doorDd = w2.doodads.filter(dd => dd.kind === gate)
      .sort((a2, b2) => Math.hypot(a2.pos.x - mouthAt.x, a2.pos.y - mouthAt.y)
        - Math.hypot(b2.pos.x - mouthAt.x, b2.pos.y - mouthAt.y))[0];
    check(`N3.9 ${label}: the return wears the mouth's story on story floor`,
      p2.tier === 1 && tierFloorAt(regionAtOf(w2, p2.pos.x, p2.pos.y), 1),
      `tier=${p2.tier} kind=${regionAtOf(w2, p2.pos.x, p2.pos.y)}`
      + (doorDd ? ` doorDd=${doorDd.pos.x.toFixed(0)},${doorDd.pos.y.toFixed(0)}`
        + `@${regionAtOf(w2, doorDd.pos.x, doorDd.pos.y)} rowNudge=${Math.hypot(mouthAt.x - doorDd.pos.x, mouthAt.y - doorDd.pos.y).toFixed(1)}px` : ' doorDd=NONE'));
    // The pairing law (task_e2243782): the drawn door and the dwell seat are
    // ONE point — a story-seated mouth keeps its exact relocated seat (the
    // mouthSeat rule), so the return stands AT the drawn gate, never on
    // ground a clamp projected it to.
    check(`N3.9b ${label}: the drawn door stands AT the dwell seat (drawn == dwelled)`,
      !!doorDd && Math.hypot(mouthAt.x - doorDd.pos.x, mouthAt.y - doorDd.pos.y) < 2,
      doorDd ? `rowNudge=${Math.hypot(mouthAt.x - doorDd.pos.x, mouthAt.y - doorDd.pos.y).toFixed(1)}px` : 'doorDd=NONE');
    clearField(w2);
    const outStep = bestStep(w2, { x: p2.pos.x, y: p2.pos.y });
    check(`N3.10 ${label}: the return is MOBILE on its story`, outStep > 15, `step=${outStep.toFixed(1)}px`);
    // THE CLASSIC MOUTH keeps its bytes: a ground-story door (synthetic,
    // the F idiom) still steps off the hole on exit, tier 0 throughout.
    const seat = { x: p2.pos.x, y: p2.pos.y };
    p2.tier = 0;
    innardsOf(w2).enterSidezone({ pos: seat, seed: 4242, kind: 'cave_entrance' });
    const classicPocket = w2.zone.id;
    check(`N3.11 ${label}: the classic descent still opens (tier 0 rung)`,
      classicPocket.startsWith('cave_') && (w2.caveReturn?.tier ?? 0) === 0, classicPocket);
    innardsOf(w2).travelThrough({ to: gardenId, side: 'n' });
    check(`N3.12 ${label}: the classic climb-out keeps the step off the hole, ground story`,
      w2.zone.id === gardenId && w2.player.tier === 0
      && Math.abs(w2.player.pos.y - (seat.y + 40)) < 45 && Math.abs(w2.player.pos.x - seat.x) < 45,
      `tier=${w2.player.tier} at=${w2.player.pos.x.toFixed(0)},${w2.player.pos.y.toFixed(0)} mouth=${seat.x.toFixed(0)},${seat.y.toFixed(0)}`);
  };
  // (petalfields for the WALK: the parkland face rolls sunk gates on early
  // pinned seeds. The forest face's starvation that once dropped stalkwood's
  // promised gates entirely is healed by THE DOOR GUARANTEE — levelgen's
  // doorGuaranteeSeat — pinned as its own census below at N3.13.)
  walkLane('garden', 'petalfields', 'taproot_gate', [951001, 951002, 951003, 951004, 951005, 951006, 951007, 951008, 951009, 951010]);
  // (952006 was once skipped here: its ellipse mint seated the sunk gate
  // beyond the rim — the dead-door divergence. THE RIM LAW now guarantees
  // in-shape dwell seats, so the original family stands and that once-cursed
  // mint is this lane's own regression specimen; N3.9b pins the pairing.)
  // (Ladder re-pinned 2026-08-04, the hunt-debts pass: the bone-massif rows
  // joining the downs base + barrowfield mixes re-rolled those faces' mints,
  // and none of the original 16 stood a sunk gate any longer — 952017-952020
  // appended through THIS rig's own run (the process-stream law; 952020 is
  // the finder). The walked specimens before it, 952006 included, stand.)
  walkLane('downs', 'downs', 'crypt_gate', [952001, 952002, 952003, 952004, 952005, 952006, 952007, 952008, 952009, 952010, 952011, 952012, 952013, 952014, 952015, 952016, 952017, 952018, 952019, 952020]);
  // THE DOOR GUARANTEE (levelgen doorGuaranteeSeat — the stalkwood heal):
  // the packed forest face whose 10-seed census once placed ZERO of its
  // promised common [1,1] taproot gates now stands one on EVERY mint —
  // same devMint lane, same seed family that measured the starvation.
  {
    const w = makeSimWorld('warrior', 0x1159);
    let stood = 0, tried = 0;
    for (let i = 0; i < 6; i++) {
      const zid = w.devMintTileset('stalkwood', i, 8, { seed: 951001 + i });
      if (!zid) continue;
      tried++;
      if (w.doodads.some(d => d.kind === 'taproot_gate')) stood++;
    }
    check('N3.13 the door guarantee: every stalkwood mint stands its promised taproot gate',
      tried >= 4 && stood === tried, `${stood}/${tried}`);
  }
}

// --- RIG O: THE ALOFT SEAT (batch 28 — LandmarkDef.siteTier / CompositionSite.siteTier)
// THE ALOFT LANE: a claim SEATED on an upper story deliberately. The laws
// pinned here on probe-local qa_aloft content (the real debut — the baboon
// king's midden — walks probe_lairs): the aimed story dart with THE
// QUANTIZE-HOP KILLER (the judged center IS the built center), THE
// SOVEREIGN CENTER (never a ramp, never a shared deck), THE RIM LAW
// (ellipse mints keep the dwell seat in-shape), THE STORY ROAD (every seat
// asserted reachable through the stack's own links), the story stamp on the
// builder's furniture, THE ALOFT WINDOW for composition entries, the
// story-less refusal (plains places nothing, loudly), determinism, and the
// boot-validation refusals (structures + POI clusters at aloft sites).
// The engine-substrate A/B (absent == byte-identical vs pristine HEAD,
// 15 tilesets × 5 seeds) was proven worktree-grade at build time — the rig
// pins the lane's live behavior (the sitewalk rig-S precedent).
{
  seedGlobalRandom(0xa10f2);
  registerDoodadRule('qa_aloft_door', { overlap: 'trigger', spacing: 60 });
  registerLandmark({
    id: 'qa_aloft_site', builder: 'den_mouth', size: [180, 250], clearSite: true,
    siteTier: 1,
    params: {
      mouthKind: 'qa_aloft_door',
      dress: [
        { kind: 'bone_pile', count: [3, 5], radius: [10, 15] },
        { kind: 'rock', count: [1, 3], radius: [12, 18] },
      ],
    },
  });
  registerCluster({
    id: 'qa_aloft_cairns', anchor: { radius: 26 },
    pieces: [{ kind: 'cairn', radius: [10, 14], count: [3, 5], ring: [20, 70], rot: true }],
  });
  registerComposition({
    id: 'qa_aloft_court',
    sites: [{ id: 'perch', radius: [60, 90], siteTier: 1 }],
    post: [{ kind: 'cluster', cluster: 'qa_aloft_cairns', at: 'perch', count: [1, 1] }],
  });

  const tsO = TILESETS.needles;
  const WO = 3600, HO = 2700;
  const entryO = vec(140, HO / 2);
  const exitsO = [vec(WO - 140, HO / 2)];
  const mkAloft = (over: Partial<ZoneDef>): ZoneDef => ({
    id: 'qa_aloft_zone', name: 'QA Aloft', level: 8,
    size: { w: WO, h: HO },
    theme: { ...tsO.theme },
    layoutType: 'needles',
    layout: tsO.layout,
    layoutParams: { ...tsO.layoutParams },
    objective: { kind: 'none' },
    packs: tsO.packs,
    exits: [{ to: 'qa_aloft_home', side: 's' }],
    map: { x: 0, y: 0 }, seed: 0,
    geo: { biomeDepth: 0.7 },
    landmarks: [{ landmark: 'qa_aloft_site', chance: 1 }],
    ...over,
  });
  const genO = (def: ZoneDef, seed: number): GeneratedLayout =>
    generateLayout({ ...def, seed }, { w: WO, h: HO }, new Rng(seed), entryO, exitsO);

  // O1-O4: the 12-seed forced sweep — placement, sovereign story seats, the
  // rim, the story road, the stamped ring.
  let placedO = 0, sovereignO = 0, rimO = 0, reachO = 0, ringO = 0;
  for (let i = 0; i < 12; i++) {
    const seed = (0xa10f7 + i * 7919) >>> 0;
    const out = genO(mkAloft({}), seed);
    const mouth = out.doodads.find(d => d.kind === 'qa_aloft_door');
    if (!mouth) continue;
    placedO++;
    const walkO = out.walk as GridWalkField | undefined;
    if (mouth.tier === 1 && walkO?.regionAt
      && walkO.regionAt(mouth.pos.x, mouth.pos.y) === 'butte_top') sovereignO++;
    if (insideBounds(mouth.pos, 28, { w: WO, h: HO, shape: 'rect' })) rimO++;
    if (walkO && storyReachable(walkO, entryO, mouth.pos, 1)) reachO++;
    const ring = out.doodads.filter(d => (d.kind === 'bone_pile' || d.kind === 'rock')
      && d.tier === 1 && Math.hypot(d.pos.x - mouth.pos.x, d.pos.y - mouth.pos.y) < 160);
    if (ring.length >= 2) ringO++;
  }
  check('O1 the aloft dart seats the claim (12-seed forced sweep)', placedO >= 11, `${placedO}/12`);
  check('O2 every seat is a SOVEREIGN story center (butte_top, tier-stamped mouth)',
    sovereignO === placedO, `${sovereignO}/${placedO}`);
  check('O3 every seat obeys the rim and the STORY ROAD reaches it from the entry',
    rimO === placedO && reachO === placedO, `rim=${rimO} road=${reachO} of ${placedO}`);
  check('O4 the midden ring is the STORY\'s furniture (≥2 aloft-stamped pieces at the door)',
    ringO >= Math.max(1, placedO - 2), `${ringO}/${placedO}`);

  // O5: the ellipse batch — the rim law bites where the shape does.
  let placedE = 0, rimE = 0;
  for (let i = 0; i < 6; i++) {
    const seed = (0xe111 + i * 7919) >>> 0;
    const out = genO(mkAloft({ shape: 'ellipse' }), seed);
    const mouth = out.doodads.find(d => d.kind === 'qa_aloft_door');
    if (!mouth) continue;
    placedE++;
    if (insideBounds(mouth.pos, 28, { w: WO, h: HO, shape: 'ellipse' })) rimE++;
  }
  check('O5 ellipse mints keep every aloft dwell seat in-shape', placedE >= 4 && rimE === placedE,
    `placed=${placedE} rim=${rimE}`);

  // O6: THE ALOFT WINDOW — a composition site on the story: its cluster
  // pieces gate on the story's floor and wear its stamp.
  let cairnsAloft = 0, cairnsUnstamped = 0;
  for (let i = 0; i < 8; i++) {
    const seed = (0xc0a7 + i * 104729) >>> 0;
    const out = genO(mkAloft({
      landmarks: [],
      compositions: [{ composition: 'qa_aloft_court', chance: 1 }],
    }), seed);
    const walkO = out.walk as GridWalkField | undefined;
    for (const d of out.doodads) {
      if (d.kind !== 'cairn') continue;
      const onStory = !!walkO?.regionAt && tierFloorAt(walkO.regionAt(d.pos.x, d.pos.y), 1);
      if (d.tier === 1 && onStory) cairnsAloft++;
      else if (onStory && d.tier === undefined) cairnsUnstamped++;
    }
  }
  check('O6 the aloft window stamps the bundle onto the story (cairns aloft, none unstamped)',
    cairnsAloft >= 6 && cairnsUnstamped === 0, `aloft=${cairnsAloft} unstamped=${cairnsUnstamped}`);

  // O7: the story-less refusal — a plains mint places NOTHING (no valley
  // fallback), and the same def keeps generating (no crash, exits carved).
  let refusedOk = true;
  for (let i = 0; i < 6; i++) {
    const seed = (0xbee5 + i * 104729) >>> 0;
    const out = genO(mkAloft({ layoutType: undefined, layoutParams: {} }), seed);
    if (out.doodads.some(d => d.kind === 'qa_aloft_door')) refusedOk = false;
  }
  check('O7 a story-less layout refuses the aloft claim whole (no valley seat, ever)', refusedOk);

  // O8: determinism — same seed, same stack (kind:pos:tier print).
  {
    const a = genO(mkAloft({}), 0xd00d);
    const b = genO(mkAloft({}), 0xd00d);
    const print = (o: GeneratedLayout): string =>
      o.doodads.map(d => `${d.kind}:${Math.round(d.pos.x)},${Math.round(d.pos.y)}:${d.tier ?? 0}`).join('|');
    check('O8 the aloft seat is deterministic (same seed, same stack)', print(a) === print(b));
  }

  // O9: the boot-validation refusals — masonry and tier-0 promises never
  // stand at an aloft site.
  registerCluster({
    id: 'qa_aloft_poi_cairns', anchor: { radius: 26 }, poi: true,
    pieces: [{ kind: 'cairn', radius: [10, 14], count: [1, 2] }],
  });
  registerComposition({
    id: 'qa_aloft_bad',
    sites: [{ id: 'perch', radius: [60, 90], siteTier: 1 }],
    post: [
      { kind: 'structure', structure: 'watchtower', at: 'perch', count: [1, 1] },
      { kind: 'cluster', cluster: 'qa_aloft_poi_cairns', at: 'perch', count: [1, 1] },
    ],
  });
  const errsO = validateCompositions();
  check('O9 validation refuses structures + POI clusters at aloft sites',
    errsO.some(e => e.includes('qa_aloft_bad') && e.includes('flatten the story'))
    && errsO.some(e => e.includes('qa_aloft_bad') && e.includes('tier-0 promise')),
    errsO.filter(e => e.includes('qa_aloft_bad')).join(' | ') || '(no errors)');
}

// --- RIG O, THE MULTI-STORY SWEEP (batch 29 — siteTier 2+ over the switchback)
// The lane beyond needles' one-story stack, pinned on the pinnacle's own
// faces (the 40-seed sweeps measured 100% sovereign/rim/road on every placed
// seat at stories 2, 3 and 4, rect and ellipse): the aimed story dart, the
// quantize-hop killer, the sovereign center and the story road all hold with
// the seat an annulus BENCH crossed by k stacked ramps instead of a butte
// top. THE DART BUDGET (LandmarkDef.siteTryMul — the dress budget's landmark
// sibling, this sweep's one lane fix) widens the starved half-cone (story-3
// bench seats 20/40 forced mints at the standing 18 darts, 34/40 at mul 3 —
// every refusal honest, every added seat lawful). THE EYRIE RING
// (data/compositions.ts — the aloft composition lane's first authored
// content) is pinned on the needles face it ships on; the wind faces were
// measured storyless (zero over-story floor cells) and refused the claim.
{
  seedGlobalRandom(0x51ee7);
  registerDoodadRule('qa_summit_door', { overlap: 'trigger', spacing: 60 });
  const dressQ = [
    { kind: 'bone_pile', count: [3, 5] as [number, number], radius: [10, 15] as [number, number] },
    { kind: 'rock', count: [1, 3] as [number, number], radius: [12, 18] as [number, number] },
  ];
  for (const story of [2, 3]) {
    registerLandmark({
      id: `qa_summit_site_${story}`, builder: 'den_mouth', size: [180, 250], clearSite: true,
      siteTier: story, params: { mouthKind: 'qa_summit_door', dress: dressQ },
    });
  }
  registerLandmark({
    id: 'qa_summit_site_3_wide', builder: 'den_mouth', size: [180, 250], clearSite: true,
    siteTier: 3, siteTryMul: 3, params: { mouthKind: 'qa_summit_door', dress: dressQ },
  });

  const tsQ = TILESETS.pinnacle;
  const WQ = 3000, HQ = 2350;
  const entryQ = vec(140, HQ / 2);
  const exitsQ = [vec(WQ - 140, HQ / 2)];
  const coneParams = { ...tsQ.layoutParams, ...tsQ.variants![0].layoutParams };
  const shoulderParams = { ...tsQ.layoutParams, ...tsQ.variants![1].layoutParams };
  const mkSummit = (over: Partial<ZoneDef>): ZoneDef => ({
    id: 'qa_summit_zone', name: 'QA Summit', level: 14,
    size: { w: WQ, h: HQ },
    theme: { ...tsQ.theme },
    layoutType: 'switchback',
    layout: tsQ.layout,
    layoutParams: { ...tsQ.layoutParams },
    objective: { kind: 'none' },
    packs: tsQ.packs,
    exits: [{ to: 'qa_summit_home', side: 's' }],
    map: { x: 0, y: 0 }, seed: 0,
    geo: { biomeDepth: 0.85 },
    ...over,
  });
  const sweepQ = (
    over: Partial<ZoneDef>, story: number, seedBase: number, n: number,
  ): { placed: number; lawful: number; offStory: number } => {
    let placed = 0, lawful = 0, offStory = 0;
    for (let i = 0; i < n; i++) {
      const seed = (seedBase + i * 7919) >>> 0;
      const def = mkSummit({ ...over, seed });
      const out = generateLayout(def, { w: WQ, h: HQ }, new Rng(seed), entryQ, exitsQ);
      const mouth = out.doodads.find(d => d.kind === 'qa_summit_door');
      if (!mouth) continue;
      placed++;
      const walkQ = out.walk as GridWalkField | undefined;
      const rk = walkQ?.regionAt ? regionKind(walkQ.regionAt(mouth.pos.x, mouth.pos.y)) : undefined;
      const sovereign = mouth.tier === story && !!rk && !rk.tierLink && !rk.walkable && rk.tier === story;
      if (!sovereign) { offStory++; continue; }
      const shapeQ = (def.shape ?? 'rect') as 'rect' | 'ellipse';
      if (insideBounds(mouth.pos, 28, { w: WQ, h: HQ, shape: shapeQ })
        && !!walkQ && storyReachable(walkQ, entryQ, mouth.pos, story)) lawful++;
    }
    return { placed, lawful, offStory };
  };

  // O10: story 2 on the cone face — the bench annulus seats like the butte.
  const o10 = sweepQ({ layoutParams: coneParams, landmarks: [{ landmark: 'qa_summit_site_2', chance: 1 }] }, 2, 0x51ee7, 8);
  check('O10 story-2 seats on the cone face: every placed seat sovereign, in-rim, road-reached',
    o10.placed >= 7 && o10.offStory === 0 && o10.lawful === o10.placed,
    `placed=${o10.placed}/8 lawful=${o10.lawful} offStory=${o10.offStory}`);

  // O11: story 3 on the base face — three stacked ramps, one BFS.
  const o11 = sweepQ({ landmarks: [{ landmark: 'qa_summit_site_3', chance: 1 }] }, 3, 0x51ee7 + 3 * 977, 8);
  check('O11 story-3 seats cross the stacked ramps (sovereign + rim + the layered story road)',
    o11.placed >= 5 && o11.offStory === 0 && o11.lawful === o11.placed,
    `placed=${o11.placed}/8 lawful=${o11.lawful} offStory=${o11.offStory}`);

  // O12: the ellipse batch at story 2 — the rim law where the shape bites.
  const o12 = sweepQ({ shape: 'ellipse', landmarks: [{ landmark: 'qa_summit_site_2', chance: 1 }] }, 2, 0xe11b5e, 8);
  check('O12 ellipse mints keep every multi-story dwell seat in-shape and lawful',
    o12.placed >= 5 && o12.offStory === 0 && o12.lawful === o12.placed,
    `placed=${o12.placed}/8 lawful=${o12.lawful} offStory=${o12.offStory}`);

  // O13: THE DART BUDGET — the starved half-cone (story 3) at the standing 18
  // darts vs siteTryMul 3, same seed ladder: strictly more seats, all lawful,
  // and the misses stay whole refusals in BOTH forms (offStory 0 everywhere).
  const leanQ = sweepQ({ layoutParams: shoulderParams, landmarks: [{ landmark: 'qa_summit_site_3', chance: 1 }] }, 3, 0x51ee7 + 5 * 977, 10);
  const wideQ = sweepQ({ layoutParams: shoulderParams, landmarks: [{ landmark: 'qa_summit_site_3_wide', chance: 1 }] }, 3, 0x51ee7 + 5 * 977, 10);
  check('O13 siteTryMul widens the starved face and every added seat obeys the laws',
    wideQ.placed > leanQ.placed && wideQ.offStory === 0 && leanQ.offStory === 0
    && wideQ.lawful === wideQ.placed && leanQ.lawful === leanQ.placed,
    `lean=${leanQ.placed}/10 wide=${wideQ.placed}/10`);

  // O14: THE EYRIE RING — the authored composition on the face it ships on:
  // the heart aloft, the ring ≥2 tier-stamped pieces, no unstamped stray on
  // sovereign top ground, and the needles row + registry refs standing.
  const tsN = TILESETS.needles;
  let eyrieRinged = 0, eyrieStrays = 0, eyrieHearts = 0;
  for (let i = 0; i < 8; i++) {
    const seed = (0xe4e1e + i * 7919) >>> 0;
    const defN: ZoneDef = {
      id: 'qa_eyrie_zone', name: 'QA Eyrie', level: 8,
      size: { w: 3600, h: 2700 }, theme: { ...tsN.theme },
      layoutType: 'needles', layout: tsN.layout, layoutParams: { ...tsN.layoutParams },
      objective: { kind: 'none' }, packs: tsN.packs,
      exits: [{ to: 'qa_eyrie_home', side: 's' }],
      map: { x: 0, y: 0 }, seed, geo: { biomeDepth: 0.7 },
      compositions: [{ composition: 'eyrie_ring', chance: 1 }],
    };
    const out = generateLayout(defN, { w: 3600, h: 2700 }, new Rng(seed), vec(140, 1350), [vec(3460, 1350)]);
    const walkN = out.walk as GridWalkField | undefined;
    const heart = out.doodads.find(d => d.kind === 'bone_pile' && d.tier === 1);
    if (!heart) continue;
    eyrieHearts++;
    const ringN = out.doodads.filter(d =>
      (d.kind === 'dead_tree' || d.kind === 'rock' || d.kind === 'veld_grass')
      && d.tier === 1 && Math.hypot(d.pos.x - heart.pos.x, d.pos.y - heart.pos.y) < 100);
    if (ringN.length >= 2) eyrieRinged++;
    eyrieStrays += out.doodads.filter(d => {
      if (!(d.kind === 'dead_tree' || d.kind === 'rock' || d.kind === 'veld_grass' || d.kind === 'bone_pile')) return false;
      if (d.tier !== undefined || Math.hypot(d.pos.x - heart.pos.x, d.pos.y - heart.pos.y) >= 100) return false;
      const rk = walkN?.regionAt ? regionKind(walkN.regionAt(d.pos.x, d.pos.y)) : undefined;
      return !!rk && !rk.walkable && !rk.tierLink && rk.tier === 1;
    }).length;
  }
  check('O14 the eyrie ring stands aloft on the needles face (hearts + rings, zero unstamped strays)',
    eyrieHearts >= 6 && eyrieRinged >= 5 && eyrieStrays === 0,
    `hearts=${eyrieHearts}/8 ringed=${eyrieRinged} strays=${eyrieStrays}`);
  check('O14 the needles row ships the ring and validation stands clean on it',
    (tsN.compositions ?? []).some(r => r.composition === 'eyrie_ring' && r.chance > 0 && r.chance <= 1)
    && !validateCompositions().some(e => e.includes('eyrie_ring')),
    (tsN.compositions ?? []).map(r => r.composition).join(','));

  // O15: THE WIND-FACE REFUSAL — the aetherial archipelagos stack no
  // over-story (the eyrie's measured refusal-with-cause: an aloft site
  // starves there structurally; their aloft flavor stays the vane roost).
  // A future wind recipe that grows real stories moves this pin on purpose.
  const tsW = TILESETS.aether_drift;
  let windStoryCells = 0;
  for (let i = 0; i < 3; i++) {
    const seed = (0xa11d + i) >>> 0;
    const defW: ZoneDef = {
      id: 'qa_wind_zone', name: 'QA Wind', level: 14,
      size: { w: 2600, h: 2000 }, theme: { ...tsW.theme },
      layoutType: 'aether_drift', layout: tsW.layout, layoutParams: { ...tsW.layoutParams },
      objective: { kind: 'none' }, packs: tsW.packs,
      exits: [{ to: 'qa_wind_home', side: 's' }],
      map: { x: 0, y: 0 }, seed,
    };
    const out = generateLayout(defW, { w: 2600, h: 2000 }, new Rng(seed), vec(140, 1000), [vec(2460, 1000)]);
    const walkW = out.walk as GridWalkField | undefined;
    if (!walkW) continue;
    for (let gy = 0; gy < walkW.rows; gy++) {
      for (let gx = 0; gx < walkW.cols; gx++) {
        if (tierFloorOf(walkW.regionAt(gx * walkW.cell + walkW.cell / 2, gy * walkW.cell + walkW.cell / 2))) windStoryCells++;
      }
    }
  }
  check('O15 the wind faces stack no over-story (the eyrie\'s refusal stands structural)',
    windStoryCells === 0, `storyCells=${windStoryCells}`);

  // O16: THE FIRST LIVE CONSUMER — the horn gate (data/lairs.ts, THE
  // SLEEPLESS WATCH) wears the lane for real: siteTier 3 over the pinnacle,
  // and the dart budget's first live value (O13 pinned siteTryMul's widening
  // on qa content; this pins that a live def actually ships it — the
  // probes-kept-aim law). Batch-30 sweep measured the def at the mul: base
  // 40/40, cone 40/40, shoulder 36/40, every placed seat sovereign/rim/road
  // — the 8-seed probe keeps the cone bar.
  const liveDef = landmarkOf('horn_gate_site');
  check('O16 the live crown def ships the lane (siteTier 3 + the first live siteTryMul, no tier-0 promises)',
    liveDef?.siteTier === 3 && liveDef?.siteTryMul === 3
    && !liveDef?.poi && !liveDef?.mustReach && liveDef?.clearSite === true);
  let livePlaced = 0, liveLawful = 0, liveOff = 0;
  for (let i = 0; i < 8; i++) {
    const seed = (0x51ee9 + i * 7919) >>> 0;
    const defL = mkSummit({ layoutParams: coneParams, landmarks: [{ landmark: 'horn_gate_site', chance: 1 }], seed });
    const out = generateLayout(defL, { w: WQ, h: HQ }, new Rng(seed), entryQ, exitsQ);
    const mouth = out.doodads.find(d => d.kind === 'horn_gate');
    if (!mouth) continue;
    livePlaced++;
    const walkL = out.walk as GridWalkField | undefined;
    const rk = walkL?.regionAt ? regionKind(walkL.regionAt(mouth.pos.x, mouth.pos.y)) : undefined;
    if (!(mouth.tier === 3 && !!rk && !rk.tierLink && !rk.walkable && rk.tier === 3)) { liveOff++; continue; }
    if (insideBounds(mouth.pos, 28, { w: WQ, h: HQ, shape: 'rect' })
      && !!walkL && storyReachable(walkL, entryQ, mouth.pos, 3)) liveLawful++;
  }
  check('O16 the horn gate seats the third terrace lawfully on the cone face',
    livePlaced >= 7 && liveOff === 0 && liveLawful === livePlaced,
    `placed=${livePlaced}/8 lawful=${liveLawful} offStory=${liveOff}`);
}

// --- RIG M′: THE TIER TINT (the map tell's color half — batch 37) -----------------
// tierMapTint (ui/panels.ts) folds a zone's story stack into its node FILL:
// 'over' stacks mix toward VIS_CFG.mapTierTint.overTo (the terrace
// convention's pale crown — higher = lighter, the ground bake's own ascent),
// 'under' stacks toward underTo (the tell's darken target), strength =
// stories × perStory capped at max. The laws pinned here: BYTE-ZERO on
// storyless ground and under fog (the input string returned untouched), the
// DERIVATION (the fold is exactly one mixHex through the dials — drawn ==
// derived), direction (over lighter / under darker), the cap, the non-6-hex
// pass-through (mixHex's contract honored, never garbled), the dial-zero
// ablation, and the real minted defs (RIG C/D/E's own pinned seeds re-gen —
// no new seed enters the file).
{
  const lum = (hex: string): number =>
    [1, 3, 5].reduce((s, i) => s + parseInt(hex.slice(i, i + 2), 16), 0);
  const cfg = VIS_CFG.mapTierTint;
  const BASE = '#6b6a5e';
  const expect = (levels: number | undefined, kind: 'over' | 'under', fill: string): string =>
    mixHex(fill, kind === 'under' ? cfg.underTo : cfg.overTo,
      Math.min(cfg.max, Math.max(1, Math.floor(levels ?? 1)) * cfg.perStory));

  check('M′1 storyless ground keeps its fill BYTE-IDENTICAL',
    tierMapTint({}, true, BASE) === BASE && tierMapTint({}, false, BASE) === BASE);
  check('M′2 THE FOG GATE: an unrevealed stack keeps its fill',
    tierMapTint({ tiers: { kind: 'over', exposure: 'open' } }, false, BASE) === BASE);
  const over1 = tierMapTint({ tiers: { kind: 'over', exposure: 'open' } }, true, BASE);
  const over3 = tierMapTint({ tiers: { kind: 'over', exposure: 'open', levels: 3 } }, true, BASE);
  const under1 = tierMapTint({ tiers: { kind: 'under', exposure: 'covered' } }, true, BASE);
  check('M′3 the derivation: one mixHex through the dials, both directions',
    over1 === expect(undefined, 'over', BASE) && over3 === expect(3, 'over', BASE)
    && under1 === expect(undefined, 'under', BASE));
  check('M′4 higher = lighter (the terrace convention), under = darker',
    lum(over1) > lum(BASE) && lum(over3) > lum(over1) && lum(under1) < lum(BASE));
  const over9 = tierMapTint({ tiers: { kind: 'over', exposure: 'open', levels: 9 } }, true, BASE);
  check('M′5 the cap: a nine-story fantasy tints no further than the capped stack',
    over9 === expect(9, 'over', BASE) && lum(over9) <= lum(mixHex(BASE, cfg.overTo, cfg.max)) + 3
    && cfg.perStory > 0 && cfg.max >= cfg.perStory);
  check('M′6 a non-6-hex fill passes through untouched (never garbled)',
    tierMapTint({ tiers: { kind: 'over', exposure: 'open' } }, true, '#999') === '#999');
  {
    // THE ABLATION: the dial at 0 kills the read whole (the kill-switch law).
    // VIS_CFG is type-readonly, not frozen — mutate under a restore.
    const dial = cfg as unknown as { perStory: number };
    const kept = dial.perStory;
    dial.perStory = 0;
    const off = tierMapTint({ tiers: { kind: 'over', exposure: 'open', levels: 4 } }, true, BASE);
    dial.perStory = kept;
    check('M′7 the dial at 0 is the whole read OFF (byte-identical everywhere)', off === BASE);
  }
  // The real stamps, on RIG C/D/E's own pinned seeds (no new seed enters):
  // a minted summit tints toward the crown, a carved warren toward the dark,
  // and fog holds both back.
  const pkT = gen('qa_tint_peak', 'switchback', TILESETS.pinnacle.layout,
    { ...TILESETS.pinnacle.layoutParams }, 717001);
  const pkFill = tierMapTint(pkT.def, true, BASE);
  check('M′8 a minted summit lifts toward the crown pale — and fog holds it',
    pkFill === expect(pkT.def.tiers?.levels, 'over', BASE) && lum(pkFill) > lum(BASE)
    && tierMapTint(pkT.def, false, BASE) === BASE);
  const metroT = TILESETS.metropolis;
  const warrensT = metroT.variants?.find(v => v.name === 'the warrens');
  let carvedT = 0, sankT = 0;
  for (const seed of [616001, 616002, 616003, 616004, 616005, 616006]) {
    const { def } = gen('qa_tint_warrens', 'district', warrensT?.layout ?? metroT.layout,
      { ...metroT.layoutParams, ...warrensT?.layoutParams, sewerTier: 1 }, seed);
    if (!def.tiers) continue; // the lattice honestly declined (RIG D's tolerance)
    carvedT++;
    if (lum(tierMapTint(def, true, BASE)) < lum(BASE)) sankT++;
  }
  check('M′9 every carved warren sinks toward the dark', carvedT >= 1 && sankT === carvedT,
    `${sankT}/${carvedT}`);
}

// --- RIG P: THE STORY TABLE (the per-story spawn axis — LIVE since the story fold) ----
// storyTable (engine/tiers.ts) is the fold for PackTableEntry.storyPresence —
// the presence vocabulary over the STORY axis ("harder kin near the crown").
// Built cold in batch 37; the story fold (2026-08-06, batch 39) LANDED the
// consumer: spawnPacks (world.ts) rolls tier membership + story BEFORE the
// type pick and folds every tiered-ground pack's table at its ROLLED story
// (ground packs at 0 — a from-the-benches row is absent from the valley;
// flat zones skip the fold entirely, A/B-proven byte-identical). The laws
// pinned: THE IDENTITY FAST PATH + THE LEDGER (absent == byte-identical for
// every table off the ledger; the ledger's tables fold live — the pinnacle
// gale debut; a rogue axis row is NAMED), the envelope honored on synthetic
// rows and the real debut (presenceMul's own math), the never-starve
// fallback, no input mutation, and STREAM NEUTRALITY (folding consumes no
// rng — the fold itself re-pins nothing; the HOIST's reorder in tiered
// zones is the consumer's own, per-seed re-pins dated where they landed).
{
  // P1 the identity fast path + THE LEDGER census, over every live packs
  // table (TilesetDef.packs is required; variants carry no packs of their
  // own). THE STORY FOLD LANDED (2026-08-06, batch 39): spawnPacks folds
  // every tiered-ground pack at its ROLLED story (world.ts — the story
  // roll hoisted above the type pick), and the pinnacle's gale row is the
  // debut — so the census now reads against the ledger: a table ON it must
  // fold LIVE (a new object where the envelope bites), every table OFF it
  // still folds to ITSELF on every story (absent == byte-identical), and a
  // new storyPresence row lands its ledger entry in this same commit or
  // this check NAMES the rogue — the tripwire, re-armed.
  const LIVE_STORY_TABLES = ['pinnacle'];
  let tables = 0, identity = 0, live = 0;
  const rogue: string[] = [];
  for (const [tid, ts] of Object.entries(TILESETS)) {
    const t = ts.packs.table;
    if (!t.length) continue;
    if (LIVE_STORY_TABLES.includes(tid)) {
      if (storyTable(t, 0) !== t && storyTable(t, 3) !== t) live++;
      continue;
    }
    tables++;
    if (storyTable(t, 0) === t && storyTable(t, 3) === t) identity++;
    else rogue.push(tid);
  }
  check('P1 axis-less tables fold to THEMSELVES on every story; the ledger folds live',
    tables >= 10 && identity === tables && live === LIVE_STORY_TABLES.length,
    `${identity}/${tables} identity${rogue.length ? ' (rogue: ' + rogue.join(',') + ')' : ''}, ${live}/${LIVE_STORY_TABLES.length} live`);
  // P1b the debut envelope, honored on the REAL pinnacle table: the gale
  // absent from the valley floor, half-weight at the first bench, full from
  // the second — and the valley's own kin untouched by the fold.
  {
    const t = TILESETS.pinnacle.packs.table;
    const at = (s: number, id: string): number | undefined =>
      storyTable(t, s).find(r => r.id === id)?.weight;
    check('P1b the gale claims the benches (valley absent → ½ → full), the condor holds',
      at(0, 'gale_elemental') === undefined && at(1, 'gale_elemental') === 1
      && at(2, 'gale_elemental') === 2 && at(3, 'gale_elemental') === 2
      && at(0, 'crag_condor') === 3 && at(2, 'crag_condor') === 3);
  }
  // P2 the envelope, honored: { from: 2, fadeIn: 2 } — absent on the valley
  // floor, half at the first bench, full at the second (presenceMul's math).
  const rows = [
    { id: 'valley_kin', weight: 2 },
    { id: 'crown_kin', weight: 1, storyPresence: { from: 2, fadeIn: 2 } },
  ];
  const at = (story: number): Record<string, number> => {
    const m: Record<string, number> = {};
    for (const r of storyTable(rows, story)) m[r.id] = r.weight;
    return m;
  };
  const w0 = at(0), w1 = at(1), w2 = at(2);
  check('P2 the crown kin climbs the benches (0 → ½ → full), the valley kin holds',
    w0.crown_kin === undefined && Math.abs((w1.crown_kin ?? 0) - 0.5) < 1e-9
    && Math.abs((w2.crown_kin ?? 0) - 1) < 1e-9
    && w0.valley_kin === 2 && w1.valley_kin === 2 && w2.valley_kin === 2);
  check('P3 a fully-gated story falls back to the unshaped input (never starve)',
    storyTable([{ id: 'grazer', weight: 3, storyPresence: { to: 0 } }], 4)[0].weight === 3);
  check('P4 the fold never mutates its input (rows keep their authored weights)',
    rows[1].weight === 1 && rows.length === 2 && storyTable(rows, 1) !== rows);
  {
    // P5 STREAM NEUTRALITY: the fold between two seeded draws leaves the
    // stream exactly where the control run left it.
    const restoreA = seedGlobalRandom(0x7157a);
    const control = Math.random();
    restoreA();
    const restoreB = seedGlobalRandom(0x7157a);
    storyTable(rows, 2);
    storyTable(TILESETS.pinnacle.packs.table, 5);
    const after = Math.random();
    restoreB();
    check('P5 folding consumes NO rng (the cold lever re-pins nothing)', after === control);
  }
}

// --- RIG Q: LAYER SOVEREIGNTY (batch 40 — cross-tier touch, pop and block sealed) --
// Arianna's garden report made law: each layer is untouchable by anything on
// another layer. The fixture is the reported bug verbatim — surface furniture
// (a dew bead, a bloom-stalk trunk; tier-unstamped = story 0) standing over
// the root web, a body IN the web (tier 1) beneath it. Pinned, live:
//   POP  — the mallet (strikeSurfaces: every damaging delivery's surface
//          seam) and the touch/near sweep (updateBrittle) answer only the
//          striker's own story; the SAME blows from the surface still pop
//          (the gate is alive, not dead).
//   BLOCK — clampPos walks a story-1 body straight through a surface trunk;
//          the unstuck sentinel (pointInSolid/findFreeSpot on the body's OWN
//          story) no longer snap-teleports the under-story runner out from
//          beneath every tree it passes under; the story pathfield never saw
//          doodads to begin with (regions only — asserted).
//   STORY — a summon minted below joins its caster's layer (spawnMinion
//          stamps caster.tier — the flight law's sibling), confined to the
//          story's own floor.
//   LINKS — crossings still serve BOTH ends (the well flips both ways; the
//          throat prop is inert to every gate by rule).
// All gates are pure reads at runtime seams — generation untouched, flat
// zones compare 0 === 0 everywhere (byte-identical by construction).
{
  const w = makeSimWorld('sorcerer', 0x40a11);
  // The casts must ride the BAR (the applyBuild lane): a loose instance's
  // summons are orphans the reconciler culls at full life — learned skills
  // are the real player pipeline this rig claims to pin.
  const sovWarns = applyBuild(w, {
    id: 'sov_probe', classId: 'sorcerer', level: 9,
    skills: [{ id: 'frost_nova', level: 3 }, { id: 'heat_split', level: 1 }],
  }, 7);
  if (sovWarns.length) console.log('RIG Q build warnings:', sovWarns.join(' | '));
  const p = w.player;
  const novaInst = p.skills.find(s => s?.def.id === 'frost_nova');
  const splitInst = p.skills.find(s => s?.def.id === 'heat_split');
  // The touch fixture's own kind: brittle on TOUCH (the garden ships none at
  // 'touch' grain — pods and beads are 'hit'; the sweep under test is the same).
  registerDoodadRule('qa_sov_pod', { overlap: 'inert', brittle: { on: ['touch'], text: 'popped' } });

  // Q0 — the stage: a REAL garden-country mint (stalkwood: underTier 'roots'
  // at 0.8) hunted until the lane carves, then a straight 5-cell duct run.
  let grid: GridWalkField | null = null;
  let run: { x: number; y: number; ax: number; ay: number } | null = null; // center + run axis
  for (const [i, seed] of [404101, 404102, 404103, 404104, 404105, 404106].entries()) {
    const zid = w.devMintTileset('stalkwood', 3 + i, 8, { seed });
    if (!zid || w.zone.tiers?.lane !== 'roots') continue;
    const pf = w.pathField(0);
    if (!(pf instanceof GridWalkField)) continue;
    const cs = pf.cell, cols = pf.cols, rows = pf.rows;
    const at = (gx: number, gy: number): string => pf.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    outer:
    for (let gy = 1; gy < rows - 1; gy++) {
      for (let gx = 3; gx < cols - 3; gx++) {
        let h = true, v = true;
        for (let o = -2; o <= 2; o++) {
          if (at(gx + o, gy) !== 'root_duct') h = false;
          if (at(gx, gy + o) !== 'root_duct') v = false;
        }
        if (h || v) {
          run = { x: gx * cs + cs / 2, y: gy * cs + cs / 2, ax: h ? 1 : 0, ay: h ? 0 : 1 };
          grid = pf;
          break outer;
        }
      }
    }
    if (run) break;
  }
  check('Q0 the rig finds a rooted garden and a straight duct run', !!grid && !!run);

  if (grid && run) {
    const cs = grid.cell;
    // A quiet stage (the RIG J idiom): this rig strikes alone.
    for (const a of w.actors) if (a !== p) a.dead = true;
    w.update(1 / 30);
    // The fixtures, planted as the report describes them: SURFACE bodies
    // (no tier stamp = story 0) standing over the web — the bead + touch pod
    // at one end of the run, the trunk at the other.
    const seatA = vec(run.x - run.ax * cs * 2, run.y - run.ay * cs * 2);
    const seatB = vec(run.x + run.ax * cs * 2, run.y + run.ay * cs * 2);
    const bead: Doodad = { pos: vec(seatA.x, seatA.y), radius: 12, kind: 'dew_bead' };
    const pod: Doodad = { pos: vec(seatA.x, seatA.y), radius: 10, kind: 'qa_sov_pod' };
    const trunk: Doodad = { pos: vec(seatB.x, seatB.y), radius: 40, kind: 'bloom_stalk' };
    w.doodads.push(bead, pod, trunk);
    w.markDoodadsChanged();
    check('Q0b the fixture premise holds (hit-brittle bead, blocking trunk, surface stamps)',
      doodadRuleOf('dew_bead').brittle?.on.includes('hit') === true
      && doodadRuleOf('bloom_stalk').blocksMove === true
      && (bead.tier ?? 0) === 0 && (trunk.tier ?? 0) === 0);

    // Q1 — POP FROM BELOW, SEALED: a story-1 nova at the bead's own seat
    // pops nothing of the street's, and five seconds of standing ON the
    // touch pod never accrues it. (Before the gate: both popped — the
    // report's gap 1.) The long window also clears the nova's cooldown
    // for the control cast.
    check('Q1a the bar carries the rig\'s kit', !!novaInst && !!splitInst);
    p.pos = vec(seatA.x, seatA.y);
    p.tier = 1;
    p.fillResources();
    const q1press = w.useSkill(p, novaInst!, { x: p.pos.x, y: p.pos.y });
    for (let i = 0; i < 150; i++) w.update(1 / 30);
    check('Q1 an under-story nova pops NO surface furniture above the web',
      q1press && !bead.gone && !pod.gone,
      `press=${q1press} bead=${bead.gone ? 'popped' : 'stands'} pod=${pod.gone ? 'popped' : 'stands'}`);

    // Q2 — THE CONTROL (the gate is alive): the SAME ground at story 0 —
    // one tick of standing pops the touch pod, and the same nova (pressed
    // a step clear of the bead's solid, so the rescue snap never moves the
    // cast) pops the bead.
    p.tier = 0;
    w.update(1 / 30); // the touch sweep fires on the first surface tick
    p.pos = vec(seatA.x + run.ax * 40, seatA.y + run.ay * 40);
    p.fillResources();
    const q2press = w.useSkill(p, novaInst!, { x: p.pos.x, y: p.pos.y });
    for (let i = 0; i < 60; i++) w.update(1 / 30);
    check('Q2 the same blows from the surface still pop both',
      q2press && bead.gone === true && pod.gone === true,
      `press=${q2press} bead=${bead.gone ? 'popped' : 'stands'} pod=${pod.gone ? 'popped' : 'stands'}`);

    // Q3 — BLOCK BELOW, SEALED: the trunk's move surface (bodyScale 0.3 →
    // r=12) plus the mover's 12 gives a 24u push zone. A story-1 clamp to a
    // point 12u past the bole's heart stands; the story-0 clamp is pushed
    // clear — one seam, both stories, opposite verdicts.
    const dest = vec(seatB.x + run.ax * 12, seatB.y + run.ay * 12);
    const from = vec(seatB.x - run.ax * cs, seatB.y - run.ay * cs);
    p.tier = 1;
    const thru = w.clampPos(vec(dest.x, dest.y), 12, from, { mover: p });
    p.tier = 0;
    const stop = w.clampPos(vec(dest.x, dest.y), 12, from, { mover: p });
    check('Q3 a surface trunk yields to the under-story walker and stops the surface one',
      Math.hypot(thru.x - dest.x, thru.y - dest.y) < 1
      && Math.hypot(stop.x - seatB.x, stop.y - seatB.y) > 20,
      `thru=${Math.round(Math.hypot(thru.x - dest.x, thru.y - dest.y))}u off dest, stop=${Math.round(Math.hypot(stop.x - seatB.x, stop.y - seatB.y))}u off bole`);

    // Q3b — THE SENTINEL judges on the body's OWN story: parked at the
    // bole's heart on story 1, the unstuck sentinel (every ~16 frames)
    // leaves the runner exactly where it stands; the same park at story 0
    // is a genuine embed and the rescue snaps it clear. (Before the gate:
    // the story-1 runner was snap-teleported out from under every tree —
    // the report's "trees block travel down there".)
    p.tier = 1;
    p.pos = vec(seatB.x, seatB.y);
    for (let i = 0; i < 48; i++) w.update(1 / 30);
    const heldD = Math.hypot(p.pos.x - seatB.x, p.pos.y - seatB.y);
    p.tier = 0;
    p.pos = vec(seatB.x, seatB.y);
    for (let i = 0; i < 48; i++) w.update(1 / 30);
    const rescuedD = Math.hypot(p.pos.x - seatB.x, p.pos.y - seatB.y);
    check('Q3b the sentinel holds the under-story runner and rescues the surface embed',
      heldD < 1 && rescuedD > 20, `held=${heldD.toFixed(1)}u rescued=${Math.round(rescuedD)}u`);

    // Q3c — the story pathfield never knew the trunk (regions only): the
    // bole's cell is open floor to the web's own field.
    const pf1 = w.pathField(1);
    check('Q3c the story field reads the bole\'s ground as its own open floor',
      !!pf1 && pf1 !== grid && pf1.isWalkable(seatB.x, seatB.y));

    // Q4 — THE SUMMON'S STORY: a double called from the web joins the web —
    // caster's story stamped at mint, confined to the story's own floor.
    p.tier = 1;
    p.pos = vec(seatA.x, seatA.y);
    p.fillResources();
    const q4press = w.useSkill(p, splitInst!, { x: p.pos.x, y: p.pos.y });
    for (let i = 0; i < 20; i++) w.update(1 / 30);
    const dbl = w.actors.find(a => !a.dead && a.defId === 'heat_double');
    if (!q4press) console.log('RIG Q: heat_split press refused');
    check('Q4 the under-story summon wears its caster\'s story on the story\'s own floor',
      !!dbl && dbl.tier === 1 && (pf1?.isWalkable(dbl.pos.x, dbl.pos.y) ?? false),
      dbl ? `tier=${dbl.tier}` : 'no double stood');

    // Q5 — LINKS SERVE BOTH ENDS: the well flips either story to the other,
    // and the throat prop is inert to every gate by its own rule (never
    // blocking, never brittle — no gate can seal a crossing).
    const throatRule = doodadRuleOf(UNDER_TIER_LANES.roots.stairKind);
    check('Q5 the crossings stay whole (well flips both ways; the throat blocks/pops nothing)',
      linkFlipTier('root_well', 0) === 1 && linkFlipTier('root_well', 1) === 0
      && tierFloorAt('root_well', 0) && tierFloorAt('root_well', 1)
      && !throatRule.blocksMove && !throatRule.brittle);
  }
}

// --- RIG R: THE DIRECT SEAT'S STAMP (the mere court — batch 41 adjudication) -------
// The tierseal coda (batch 40) suspected the grotto's direct
// placeLandmarkById path skipped the tier stamp on its landmark doodads.
// ADJUDICATED FALSE: the aloft stamp is DEF-driven (LandmarkDef.siteTier at
// placeLandmark's builder tail, levelgen.ts) and runs identically for darted
// and directly-seated landmarks — the court's pieces wear the lane's story.
// These pins hold the law's three sides:
//  · THE INTENT CENSUS (R1): under-lane ground is BOTH stories' floor (the
//    lid law — floor0 AND floor1 true), so a seat's story can NEVER be
//    sensed from the ground; the def's siteTier IS the intent channel.
//    Every lair row claiming an underLane must name a landmark def that
//    carries it — a future lane row that forgets is named here, not found
//    as invisible furniture under some lake.
//  · THE LIVE SEAT (R2/R3): a bias-forced mere (probe_meadowmere RIG C's
//    exact fixture — same id, params, seed, so the court provably stands):
//    the court stone wears tier 1 on its own story's floor, and every
//    den-dress piece standing on mere ground is stamped (pieces thrown
//    past the rim keep tier 0 honestly — surface litter by the placer's
//    own law).
//  · THE CONTROL (R4): a dial-less meadow mints ZERO tier fields anywhere
//    (doodads and spawn rows both) — the stamp never leaks to flat ground.
{
  const shirkers = lairRows()
    .filter(r => r.seat.underLane && ((landmarkOf(r.landmark)?.siteTier ?? 0) < 1))
    .map(r => r.id);
  check('R1 every underLane lair row names a siteTier landmark (the intent channel)',
    shirkers.length === 0, shirkers.length ? `shirkers: ${shirkers.join(', ')}` : '');

  const arena = { w: 2600, h: 1900 };
  const entry = vec(150, arena.h / 2);
  const exits = [vec(arena.w - 150, arena.h / 2), vec(arena.w / 2, 150)];
  const THEME = { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' };
  const gen = (id: string, layoutParams: Record<string, unknown>, seed: number): GeneratedLayout => {
    const def = {
      id, name: `QA ${id}`, level: 8, size: { w: arena.w, h: arena.h },
      theme: THEME, layout: TILESETS.meadow.layout as StampSpec[],
      objective: { kind: 'clear' }, exits: [], map: { x: 0, y: 0 },
      layoutType: 'plains', layoutParams, seed,
      tileset: 'meadow', geo: { biomeDepth: 0.3 },
    } as unknown as ZoneDef;
    return generateLayout(def, arena, new Rng(seed), entry, exits);
  };
  const MERE_GROUND = ['mere_shore', 'mere_water', 'mere_water_fading', 'mere_bed'];

  const out = gen('qa_mere_court', { underTier: 'mere', underTierChance: 1, underLairBias: 1e6 }, 936001);
  const g = out.walk as GridWalkField;
  const stone = out.doodads.find(d => d.kind === 'mere_court_stone');
  check('R2 the directly-seated court stone wears the lane\'s story on its own floor',
    !!stone && (stone as { tier?: number }).tier === 1
    && tierFloorAt(g.regionAt(stone.pos.x, stone.pos.y), 1),
    stone ? `tier=${(stone as { tier?: number }).tier} ground=${g.regionAt(stone.pos.x, stone.pos.y)}` : 'no court stood');
  // Every den-dress piece ON mere ground is stamped; rim spill keeps tier 0.
  let onStory = 0, stamped = 0, rimSpill = 0, rimStamped = 0;
  if (stone) {
    for (const d of out.doodads) {
      if (d.kind !== 'mere_bloom' && d.kind !== 'standing_stone') continue;
      if (Math.hypot(d.pos.x - stone.pos.x, d.pos.y - stone.pos.y) >= 160) continue;
      const k = g.regionAt(d.pos.x, d.pos.y);
      const t = (d as { tier?: number }).tier;
      if (MERE_GROUND.includes(k)) { onStory++; if (t === 1) stamped++; }
      else { rimSpill++; if (t !== undefined) rimStamped++; }
    }
  }
  check('R3 every den-dress piece on mere ground is stamped; rim spill stays honestly flat',
    onStory >= 2 && stamped === onStory && rimStamped === 0,
    `onStory=${stamped}/${onStory} rimSpill=${rimSpill} rimStamped=${rimStamped}`);

  const flat = gen('qa_tiers_flat', {}, 936001);
  const flatStamps = flat.doodads.filter(d => (d as { tier?: number }).tier !== undefined).length
    + (flat.landmarkSpawns ?? []).filter(r => r.tier !== undefined).length;
  check('R4 the control: a dial-less lea mints ZERO tier fields (no stamp leaks to flat ground)',
    flatStamps === 0, `stamps=${flatStamps}`);
}

// --- RIG S: THE ENCLOSURE LAW (a body never leaves an ENCLOSED story) --------------
// (engine/tiers.ts tierEnclosure + world.ts's push lane; docs/engine/tiers.md.)
// The rim fall is OPEN country's toy — knock them off the butte. An ENCLOSED
// stack (an under-layer's ceiling, a building's storey) has no rim to fall
// off: the push lane's clamp holds the body at its story's edge exactly as it
// holds feet, tier kept. Pinned live on the real mints:
//   S0 the resolver (derived words, the explicit word winning both ways, the
//      recipes' own stamps) + the floor read behind THE SPOILS STORY;
//   S1 THE ROOTWAYS (the reported bug): a body in a root duct shoved at the
//      duct's side toward surface-only ground stays in the duct at tier 1 —
//      before the law the rim fall read the surface as a floor "beneath" and
//      landed the runner on the street over its own tunnel;
//   S2 THE BUTTE (the open case, unchanged): the same shove off a rim FALLS.
{
  check('S0a the enclosure word derives: under ⇒ enclosed, interior ⇒ enclosed, open country ⇒ open, no stack ⇒ open',
    tierEnclosure({ kind: 'under', exposure: 'covered' }) === 'enclosed'
    && tierEnclosure({ kind: 'over', exposure: 'open', interior: true }) === 'enclosed'
    && tierEnclosure({ kind: 'over', exposure: 'open' }) === 'open'
    && tierEnclosure(undefined) === 'open');
  check('S0b the explicit word wins both ways',
    tierEnclosure({ kind: 'over', exposure: 'open', enclosure: 'enclosed' }) === 'enclosed'
    && tierEnclosure({ kind: 'under', exposure: 'covered', enclosure: 'open' }) === 'open');
  const needlesDef = gen('qa_needles_s', 'needles', TILESETS.needles.layout, { ...TILESETS.needles.layoutParams }, 515001).def;
  check('S0c the recipes\' own stamps: the needles stay OPEN (no word, derived); an under lane reads ENCLOSED',
    !!needlesDef.tiers && needlesDef.tiers.enclosure === undefined && tierEnclosure(needlesDef.tiers) === 'open'
    && tierEnclosure({ kind: 'under', exposure: 'covered', lane: 'roots' }) === 'enclosed');
  check('S0d floorStoryOf — the lowest story a body could stand on the cell: ground/both-floor cells the ground\'s, a story-only cell its story\'s, a link its span\'s low end, a wall nobody\'s',
    floorStoryOf('ground') === 0 && floorStoryOf('butte_span') === 0 && floorStoryOf('sewer_duct') === 0
    && floorStoryOf('butte_top') === 1 && floorStoryOf('peak_terrace_2') === 2 && floorStoryOf('tier_ramp') === 0
    && floorStoryOf('rampart') === 0 && floorStoryOf(undefined) === 0);

  const w = makeSimWorld('warrior', 0x5ea11);
  const p = w.player;
  const settle = (n: number): void => { for (let i = 0; i < n; i++) w.update(1 / 30); };
  type EdgeSeat = { x: number; y: number; dir: number };
  /** A cell of `kind` with two cells of `beyond`-qualifying ground past one
   *  of its four sides — the overshoot a shove reads. */
  const findEdge = (kind: string, beyond: (k: string) => boolean): EdgeSeat | null => {
    const pf = w.pathField(0);
    if (!(pf instanceof GridWalkField)) return null;
    const cs = pf.cell, cols = pf.cols, rows = pf.rows;
    const at = (gx: number, gy: number): string => pf.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    for (let gy = 2; gy < rows - 2; gy++) {
      for (let gx = 2; gx < cols - 2; gx++) {
        if (at(gx, gy) !== kind) continue;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
          if (!beyond(at(gx + dx, gy + dy)) || !beyond(at(gx + 2 * dx, gy + 2 * dy))) continue;
          return { x: gx * cs + cs / 2, y: gy * cs + cs / 2, dir: Math.atan2(dy, dx) };
        }
      }
    }
    return null;
  };
  const surfaceOnly = (k: string): boolean => tierFloorAt(k, 0) && !tierFloorOf(k) && !tierLinkOf(k);
  const shove = (seat: EdgeSeat): void => {
    for (const a of w.actors) if (a !== p) a.dead = true;
    settle(1);
    p.pos = vec(seat.x, seat.y); p.tier = 1; p.onTierLink = false; p.push = null;
    w.pushActor(p, seat.dir, 320);
  };

  let duct: EdgeSeat | null = null;
  for (const [i, seed] of [505101, 505102, 505103, 505104, 505105, 505106].entries()) {
    const zid = w.devMintTileset('stalkwood', 3 + i, 8, { seed });
    if (!zid || w.zone.tiers?.lane !== 'roots') continue;
    duct = findEdge('root_duct', surfaceOnly);
    if (duct) break;
  }
  check('S1a the rig finds a rooted garden and a duct cell whose side opens onto surface-only ground', !!duct);
  if (duct) {
    check('S1b the rooted garden declares an ENCLOSED under-stack (the ceiling, derived — no word on the def)',
      w.zone.tiers?.kind === 'under' && w.zone.tiers.enclosure === undefined && tierEnclosure(w.zone.tiers) === 'enclosed');
    shove(duct);
    settle(40);
    const k = w.walk!.regionAt!(p.pos.x, p.pos.y);
    check('S1c shoved at the duct\'s side, the runner STAYS in the roots: tier 1 kept, on the roots\' own floor, unstaggered — never surfaced through the ceiling',
      p.tier === 1 && tierFloorAt(k, 1) && !p.push && !p.isStunned(), `tier ${p.tier} on ${k}`);
  }

  let rim: EdgeSeat | null = null;
  for (const [i, seed] of [505201, 505202, 505203].entries()) {
    const zid = w.devMintTileset('needles', 6 + i, 8, { seed, layoutType: 'needles' });
    if (!zid) continue;
    rim = findEdge('butte_top', surfaceOnly);
    if (rim) break;
  }
  check('S2a the rig finds a butte rim over open valley floor', !!rim);
  if (rim) {
    check('S2b the needles declare OPEN country (the rim is a drop)', tierEnclosure(w.zone.tiers) === 'open' && w.zone.tiers?.exposure === 'open');
    shove(rim);
    settle(2);
    const fell = p.tier === 0, staggered = p.isStunned();
    settle(38);
    const k = w.walk!.regionAt!(p.pos.x, p.pos.y);
    check('S2c the same shove off the butte\'s rim FALLS (the open case, unchanged): tier 0, staggered, standing on the valley floor',
      fell && staggered && p.tier === 0 && surfaceOnly(k), `tier ${p.tier} on ${k}`);
  }
}

// --- RIG T: LAYER SOVEREIGNTY, THE BODIES (the sovereignty gate) -------------------
// Arianna's report: an entity on ANOTHER story moved or body-blocked the
// hero on hers — an "invisible wall" (inside a stack or a covered layer the
// other story's bodies are culled from the draw, so the shoulder they threw
// had no visible thrower). The law: bodies on different stories share a
// screen, never a touch — ONE predicate (engine/tiers.ts sameStory) at every
// body-vs-body and body-vs-hazard seam. Pinned two ways:
//   T0 THE ROSTER — every seam that reaches bodies by proximity carries the
//      gate (a source census over the named methods: a new seam joins the
//      roster, or the census names it as gateless).
//   T1/T2 THE LIVE LAW on the real mints — a bridge deck over the valley
//      (needles) and a duct under the street (rootways): a statue on the
//      other story standing in the hero's exact footprint never moves the
//      hero, a hard shove through it lands no slam; the same-story CONTROL
//      still parts the pair (the gate is alive, not dead).
{
  const src = readFileSync(resolve('src/engine/world.ts'), 'utf8');
  const methodBody = (text: string, name: string): string => {
    const head = new RegExp(`^  (?:private |protected |public |readonly |static |async )*${name}\\s*(?:<[^>]*>)?\\(`, 'm');
    const m = head.exec(text); if (!m) return '';
    const next = /^  (?:private |protected |public |readonly |static |async )*[A-Za-z_]\w*\s*(?:<[^>]*>)?\(/gm;
    next.lastIndex = m.index + 1;
    const n = next.exec(text);
    return text.slice(m.index, n ? n.index : text.length);
  };
  // THE DERIVED CENSUS (her word 2026-09-06: the roster must be derived,
  // never a hand list): a SEAM is any World method that ITERATES bodies
  // (the actor grid, the actor/seat lists, the lite pool) AND TESTS
  // GEOMETRY against them. Every seam either carries the gate (sameStory /
  // storyPair / hostileTo / a tier compare / the pool's story column / a
  // strike story) or names its exemption in the source — `// SOVEREIGNTY:
  // <reason>` from the closed vocabulary below (sound and scent cross
  // stories and the walk crosses after them; sight is the eye's law; sky
  // is the world-authored hitAll law; targeting rides hostility; census,
  // seat and self touch nobody). A new proximity seam is found by SHAPE
  // the day it is written: gated, marked, or named here as gateless.
  const ITER = /this\.actorsNear\(|for \(const \w+ of this\.actors\)|this\.actors\.(?:some|filter|find|forEach)\(|for \(const \w+ of (?:bodies|actors|cand|near|alive|pool)\)|for \(const \w+ of this\.seats\)|this\.seats\.(?:some|find|filter)\(|for \(const \w+ of this\.enemiesOf\(|pool\.forEach(?:In|Along)\(|i < pool\.used|for \(const \w+ of this\.localHumanSeats\(\)\)/;
  const GEO = /\bdist\(|inAoe(?:Body)?\(|shapeContains\(|Math\.hypot\(|zoneHas\(|bankCovers|sourceCover|\.reachable\(|projTouches|trapTriggerHit\(|contains\(|dx \* dx \+ dy \* dy/;
  const GATE = /sameStory\(|storyPair\(|hostileTo\(|\.tier !== |\.tier === |tier \?\? 0\) !== |tier \?\? 0\) === |!== a\.tier|pool\.story\[|strikeTier|sourceTier|z\.tier \?\?= |tier >= 1 &&|from: \w+(?:\.actor)?\.tier|windAt\(\w+\.pos, \w+\.tier\)|drop\.tier|orb\.tier|, \w+\.tier\)/;
  const REASONS = new Set(['sky', 'sound', 'scent', 'sight', 'targeting', 'census', 'seat', 'self']);
  const MARK = /\/\/ SOVEREIGNTY: (\w+)/;
  const lines = src.split('\n');
  const heads: [number, string][] = [];
  const headRe = /^  (?:private |protected |public |readonly |static |async )*([A-Za-z_]\w*)\s*(?:<[^>]*>)?\(/;
  for (let i = 0; i < lines.length; i++) { const m = headRe.exec(lines[i]); if (m && !/^(if|for|while|switch|return|const|let)$/.test(m[1])) heads.push([i, m[1]]); }
  const tally = { gated: 0, exempt: 0 }; const ungated: string[] = []; const badReason: string[] = [];
  const byReason = new Map<string, number>();
  for (let k = 0; k < heads.length; k++) {
    const [a, name] = heads[k]; const b = heads[k + 1]?.[0] ?? lines.length;
    const body = lines.slice(a, b).join('\n');
    if (!ITER.test(body) || !GEO.test(body)) continue;
    const mark = MARK.exec(body)?.[1];
    if (mark) { tally.exempt++; byReason.set(mark, (byReason.get(mark) ?? 0) + 1); if (!REASONS.has(mark)) badReason.push(`${name}:${mark}`); }
    else if (GATE.test(body)) tally.gated++;
    else ungated.push(name);
  }
  check('T0a THE DERIVED CENSUS — every proximity seam in world.ts is gated or names its exemption',
    ungated.length === 0 && tally.gated + tally.exempt >= 90,
    ungated.length ? 'GATELESS: ' + ungated.join(', ') : `gated ${tally.gated}, exempt ${tally.exempt} (${[...byReason].map(([r, n]) => `${r} ${n}`).join(', ')})`);
  check('T0a′ every exemption speaks the closed vocabulary (sky/sound/scent/sight/targeting/census/seat/self)', badReason.length === 0, badReason.join(', '));
  check('T0a″ the census still sees the seams it was born from (a regex that goes blind fails loud)',
    ['separateActors', 'sweepBodySlam', 'sweepHazardSurface', 'updateSquish', 'updateTrapworks', 'liteCarve'].every(n => { const b = methodBody(src, n); return !!b && ITER.test(b) && GEO.test(b) && GATE.test(b); }));
  const aiSrc = readFileSync(resolve('src/engine/ai.ts'), 'utf8');
  check('T0b the AI\'s flock and spacing neighbours are its own story\'s', (aiSrc.match(/b\.tier !== actor\.tier/g) ?? []).length >= 2);
  check('T0c the membranes gate their occupants and the lite pool carries its story column',
    /\(a\.tier \?\? 0\) !== \(s\.tier \?\? 0\)/.test(readFileSync(resolve('src/engine/creep.ts'), 'utf8'))
    && /\(a\.tier \?\? 0\) !== \(b\.tier \?\? 0\)/.test(readFileSync(resolve('src/engine/fog.ts'), 'utf8'))
    && /readonly story: Uint8Array/.test(readFileSync(resolve('src/engine/lite.ts'), 'utf8')));

  const w = makeSimWorld('warrior', 0x50e11);
  const p = w.player;
  const settle = (n: number): void => { for (let i = 0; i < n; i++) w.update(1 / 30); };
  /** The first cell of `kind`, with the AXIS the strip runs along (a deck, a
   *  ramp, a duct is one cell wide: a body of the hero's radius is pinned to
   *  its centre line, so the control's offset must run ALONG it). */
  type Cell = { x: number; y: number; ax: number; ay: number };
  const findCell = (kind: string): Cell | null => {
    const pf = w.pathField(0);
    if (!(pf instanceof GridWalkField)) return null;
    const cs = pf.cell;
    const at = (gx: number, gy: number): string => pf.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    for (let gy = 2; gy < pf.rows - 2; gy++) for (let gx = 2; gx < pf.cols - 2; gx++) {
      if (at(gx, gy) !== kind) continue;
      const alongX = at(gx + 1, gy) === kind || at(gx - 1, gy) === kind;
      return { x: gx * cs + cs / 2, y: gy * cs + cs / 2, ax: alongX ? 1 : 0, ay: alongX ? 0 : 1 };
    }
    return null;
  };
  /** The statue: a planted, passive body on `tier` at `at` — a failure of the
   *  gate shows as the HERO moving, never the statue. */
  const statue = (at: { x: number; y: number }, tier: number): Actor => {
    for (const a of w.actors) if (a !== p) a.dead = true;
    settle(1);
    const m = w.createMonster('skeleton_warrior', 8, 'enemy');
    m.pos = vec(at.x, at.y); m.tier = tier; m.anchored = true; m.passive = true;
    w.actors.push(m); // (createMonster mints; the caller seats — the lite promote's own idiom)
    return m;
  };
  // The stand is a hand's breadth (2px) INSIDE the statue's footprint, never
  // dead on it: the shoulder pass has no angle to push along for coincident
  // bodies (its d > 0.01 guard), so an exact overlap would pass the negative
  // for the wrong reason and fail the control for no reason.
  const stand = (at: Cell, tier: number): void => {
    p.pos = vec(at.x + 2 * at.ax, at.y + 2 * at.ay); p.tier = tier; p.onTierLink = false; p.push = null;
  };
  const off = (a: { pos: { x: number; y: number } }, at: { x: number; y: number }): number => Math.hypot(a.pos.x - at.x, a.pos.y - at.y);
  const runPair = (tag: string, at: Cell, statueTier: number, heroTier: number): void => {
    const m = statue(at, statueTier);
    stand(at, heroTier);
    settle(20);
    check(`${tag}a a statue on the OTHER story, in the hero's footprint, moves the hero not one pixel (no shoulder across a story)`,
      Math.abs(off(p, at) - 2) < 0.5 && off(m, at) < 0.5, `hero ${off(p, at).toFixed(1)}px statue ${off(m, at).toFixed(1)}px`);
    const life0 = m.life;
    w.pushActor(p, 0, 320);
    settle(30);
    check(`${tag}b a hard shove through it lands no slam: the statue keeps its life and its seat`, m.life === life0 && off(m, at) < 0.5 && !p.push);
    stand(at, statueTier);
    settle(20);
    check(`${tag}c the same-story control: the hero standing in a same-story body's footprint is shouldered clear (the gate is alive)`,
      off(p, at) >= (p.radius + m.radius) * 0.8, `${off(p, at).toFixed(1)}px`);
    m.dead = true;
  };

  // A both-floor cell over the valley: a rope span's deck first (strung only
  // between summits within reach — some deals string none), else a ramp's
  // tread (a link is floor on both its span's stories).
  let span: Cell | null = null;
  for (const [i, seed] of [505301, 505302, 505303, 505304, 505305, 505306].entries()) {
    if (!w.devMintTileset('needles', 2 + i, 8, { seed, layoutType: 'needles' })) continue;
    span = findCell('butte_span') ?? findCell('tier_ramp');
    if (span) break;
  }
  check('T1 the rig finds a both-floor cell over the valley (a span\'s deck or a ramp\'s tread)', !!span);
  if (span) runPair('T1', span, 1, 0);

  let duct: Cell | null = null;
  for (const [i, seed] of [505401, 505402, 505403, 505404, 505405, 505406].entries()) {
    if (!w.devMintTileset('stalkwood', 3 + i, 8, { seed }) || w.zone.tiers?.lane !== 'roots') continue;
    duct = findCell('root_duct');
    if (duct) break;
  }
  check('T2 the rig finds a duct under the street (one cell, two floors: the street above, the roots beneath)', !!duct);
  if (duct) runPair('T2', duct, 0, 1);
}

// --- RIG U: THE INVESTIGATION CROSSES (lures and noise across stories) ---------------
// Her ruling 2026-09-06: a lure or a noise on another story MAY reach an
// entity there — it makes it aware, and it then WALKS to the crossing and
// investigates; it never teleports. The law: A GOAL CARRIES ITS STORY
// (moveToward / tierLinkToward read `tier` on the goal; the alert mark, the
// lure, the print, the prey, the quarry stamp the story they know), and an
// arrival asks the story, never the flat distance. Pinned live on the
// needles: a butte-top hunter drawn by a VALLEY lure walks its ramp down and
// mills at the standoff on the valley (U1); an ALERT mark on the valley does
// the same and clears only there (U2); a valley hunter lured ONTO a deck
// over its head climbs instead of standing beneath it, "arrived" (U3); every
// walk is a run of strides, never a leap of cells (U4).
{
  const w = makeSimWorld('warrior', 0x1a0e5);
  seedGlobalRandom(0x1a0e5);
  const p = w.player;
  const dd = (a: { x: number; y: number }, b: { x: number; y: number }): number => Math.hypot(a.x - b.x, a.y - b.y);
  type Pt = { x: number; y: number };
  const findSpots = (): { top: Pt; deck: Pt | null; valley: Pt } | null => {
    const pf = w.pathField(0);
    if (!(pf instanceof GridWalkField)) return null;
    const cs = pf.cell, cols = pf.cols, rows = pf.rows;
    const at = (gx: number, gy: number): string => pf.regionAt(gx * cs + cs / 2, gy * cs + cs / 2);
    const c = (gx: number, gy: number): Pt => ({ x: gx * cs + cs / 2, y: gy * cs + cs / 2 });
    let top: Pt | null = null, deck: Pt | null = null;
    for (let gy = 2; gy < rows - 2 && !top; gy++) for (let gx = 2; gx < cols - 2; gx++) if (at(gx, gy) === 'butte_top') { top = c(gx, gy); break; }
    for (let gy = 2; gy < rows - 2 && !deck; gy++) for (let gx = 2; gx < cols - 2; gx++) if (at(gx, gy) === 'butte_span') { deck = c(gx, gy); break; }
    if (!top) return null;
    // The valley seat (RIG J's standoff): open ground 8–14 cells from the top with no story floor within 4 cells.
    let valley: Pt | null = null, best = Infinity;
    const tgx = Math.floor(top.x / cs), tgy = Math.floor(top.y / cs);
    for (let gy = 2; gy < rows - 2; gy++) for (let gx = 2; gx < cols - 2; gx++) {
      const k = at(gx, gy);
      if (tierFloorOf(k) || tierLinkOf(k) || !pf.isWalkable(gx * cs + cs / 2, gy * cs + cs / 2)) continue;
      const dc = Math.hypot(gx - tgx, gy - tgy);
      if (dc < 8 || dc > 14) continue;
      let clear = true;
      for (let oy = -4; oy <= 4 && clear; oy++) for (let ox = -4; ox <= 4; ox++) if (tierFloorOf(at(gx + ox, gy + oy))) { clear = false; break; }
      if (!clear) continue;
      const score = Math.abs(dc - 11);
      if (score < best) { best = score; valley = c(gx, gy); }
    }
    return valley ? { top, deck, valley } : null;
  };
  let spots: ReturnType<typeof findSpots> = null;
  // Deals are tried until one strings a rope span (the both-floor deck U3
  // needs); a top + valley alone serves U1/U2 if none does.
  let fallback: ReturnType<typeof findSpots> = null;
  for (const [i, seed] of [505501, 505502, 505503, 505504, 505505, 505506, 505507, 505508].entries()) {
    if (!w.devMintTileset('needles', 2 + (i % 4), 8, { seed, layoutType: 'needles' })) continue;
    const s = findSpots();
    if (!s) continue;
    if (s.deck) { spots = s; break; }
    fallback ??= s;
  }
  if (!spots && fallback) {
    // Re-mint the fallback deal so the world stands on it.
    w.devMintTileset('needles', 2, 8, { seed: 505501, layoutType: 'needles' });
    spots = findSpots();
  }
  check('U0 the rig finds a butte top and a valley seat (and a deck when the deal strung one)', !!spots, spots ? `deck ${spots.deck ? 'yes' : 'no'}` : 'none');
  if (spots) {
    const { top, deck, valley } = spots;
    for (const a of w.actors) if (a !== p) a.dead = true; // a quiet stage
    w.update(1 / 30);
    p.pos = vec(valley.x, valley.y); p.tier = 0; p.untargetable = true; // the hunter must stay IDLE
    const hunter = (at: Pt, tier: number): Actor => {
      const m = w.createMonster('skeleton_warrior', 8, 'enemy');
      m.pos = vec(at.x, at.y); m.tier = tier; m.onTierLink = false; m.aiTargetId = undefined;
      w.actors.push(m);
      return m;
    };
    /** Drive until `done` or the cap; report the largest single step (a
     *  stride ≈ speed/30 — a teleport is a leap of cells). */
    const drive = (m: Actor, done: () => boolean, cap = 1500): { ticks: number; maxStep: number } => {
      let maxStep = 0, ticks = 0;
      for (; ticks < cap && !done(); ticks++) {
        const px = m.pos.x, py = m.pos.y;
        for (const a of w.actors) updateAI(a, w, 1 / 30);
        w.update(1 / 30);
        maxStep = Math.max(maxStep, Math.hypot(m.pos.x - px, m.pos.y - py));
      }
      return { ticks, maxStep };
    };
    const STRIDE = 40;
    {
      const m = hunter(top, 1);
      w.setLure('qa_valley', vec(valley.x, valley.y), 4000, 1, 30, 999, 0);
      const r = drive(m, () => m.tier === 0 && dd(m.pos, valley) <= 54);
      check('U1 a butte-top hunter drawn by a valley lure walks its ramp DOWN and mills at the standoff on the valley (tier 1 → 0)',
        m.tier === 0 && dd(m.pos, valley) <= 54, `tier ${m.tier} dist ${dd(m.pos, valley).toFixed(0)} ticks ${r.ticks}`);
      check('U4a … every step of that walk is a stride, never a teleport', r.maxStep <= STRIDE, `max step ${r.maxStep.toFixed(1)}px`);
      w.setLure('qa_valley', vec(valley.x, valley.y), 1, 1, 30, 0.001, 0);
      m.dead = true; w.update(1 / 30);
    }
    {
      const m = hunter(top, 1);
      m.alertFrom = vec(valley.x, valley.y); m.alertTier = 0; m.alertUntil = w.time + 60;
      let clearedOn: number | null = null;
      const r = drive(m, () => { if (m.alertFrom && m.tier === 0 && dd(m.pos, valley) <= 40 && clearedOn === null) clearedOn = m.tier; return clearedOn !== null; });
      check('U2 an alert mark on the valley walks the butte-top investigator DOWN; the search reaches the valley and retains its mark',
        clearedOn === 0 && dd(m.pos, valley) <= 44, `searching on tier ${String(clearedOn)} dist ${dd(m.pos, valley).toFixed(0)} ticks ${r.ticks}`);
      check('U4b … stride-wise', r.maxStep <= STRIDE, `max step ${r.maxStep.toFixed(1)}px`);
      m.dead = true; w.update(1 / 30);
    }
    if (deck) {
      const m = hunter(deck, 0); // beneath the deck, on the valley floor
      w.setLure('qa_deck', vec(deck.x, deck.y), 4000, 1, 30, 999, 1);
      const r = drive(m, () => m.tier === 1 && dd(m.pos, deck) <= 54);
      check('U3 a valley hunter beneath a deck, lured ONTO the deck, climbs to it (tier 0 → 1) instead of standing under it, "arrived"',
        m.tier === 1 && dd(m.pos, deck) <= 54, `tier ${m.tier} dist ${dd(m.pos, deck).toFixed(0)} ticks ${r.ticks}`);
      check('U4c … stride-wise', r.maxStep <= STRIDE, `max step ${r.maxStep.toFixed(1)}px`);
      w.setLure('qa_deck', vec(deck.x, deck.y), 1, 1, 30, 0.001, 1);
      m.dead = true; w.update(1 / 30);
    } else {
      console.log('U3 skipped — no rope span strung in these deals (the climb is the same election U1 walked)');
    }
    p.untargetable = false;
  }
}

// --- RIG V: actual projectile flight agrees with the firing ray ------------
{
  const w = makeSimWorld('sorcerer', 0x105c);
  const grid = new GridWalkField(300, 300, 30);
  grid.fillRect(0, 0, 299, 299, true);
  w.walk = grid;
  w.zone.tiers = { kind: 'over', exposure: 'covered', levels: 1 };
  const inst = makeSkillInstance(SKILLS.firebolt, 1);
  const fly = (from: { x: number; y: number }, to: { x: number; y: number },
    tier = 0, bounces = 0, phase = false) => {
    w.projectiles = [];
    w.player.tier = tier;
    w.player.pos = vec(from.x, from.y);
    w.spawnProjectile(w.player, inst, vec(from.x, from.y), Math.atan2(to.y - from.y, to.x - from.x));
    const p = w.projectiles[0];
    p.bounces = bounces;
    p.phase = phase;
    const clear = w.lineOfFire(from, to, tier);
    // Isolate one flight frame from unrelated world updates; launch and
    // collision are the real engine paths, with a chosen traveled distance.
    (w as unknown as { updateProjectiles(dt: number): void }).updateProjectiles(
      Math.hypot(to.x - from.x, to.y - from.y) / p.speed);
    return { p, clear, alive: w.projectiles.includes(p) };
  };
  grid.fillRect(90, 90, 119, 119, false);
  const a = vec(80, 100.1), b = vec(110, 70.1);
  const corner = fly(a, b);
  check('V1 a live flight cannot skip a thin corner that blocks its firing ray',
    !corner.clear && !corner.alive && Math.abs(corner.p.pos.x - 90) < 1e-8);
  const free = fly(vec(80, 99), vec(110, 69));
  check('V2 a flight around the free corner stays alive', free.clear && free.alive);
  const phase = fly(a, b, 0, 0, true);
  check('V3 a phasing flight still passes through a blocking corner', phase.alive);
  const short = fly(vec(89, 105), vec(91, 105));
  check('V4 a short flight ends at the wall face', !short.alive && short.p.pos.x === 90);
  grid.fillRegion(90, 90, 119, 119, 'storey_wall');
  const low = fly(vec(80, 105), vec(130, 105), 0);
  const high = fly(vec(80, 105), vec(130, 105), 1);
  check('V5 a hanging partition admits ground flight and stops upstairs flight',
    low.clear && low.alive && !high.clear && !high.alive && high.p.pos.x === 90);
  const bank = fly(vec(80, 100), vec(100, 110), 1, 1);
  check('V6 an upstairs bounce reflects only the blocked axis and stays outside the partition',
    bank.alive && bank.p.bounces === 0 && bank.p.pos.x < 90
    && Math.cos(bank.p.dir) < 0 && Math.sin(bank.p.dir) > 0);
}

console.log(fails === 0 ? '\nALL PASS' : `\n${fails} FAILURE(S)`);
process.exit(fails === 0 ? 0 : 1);
