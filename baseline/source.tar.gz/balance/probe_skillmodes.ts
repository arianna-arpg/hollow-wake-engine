// ---------------------------------------------------------------------------
// ONE-OFF PROBE — THE SKILL-MODE TREES, M1 (docs/design/skill-modes.md §3/§8:
// the tree fabric). Pins, in order:
//   A. THE AUTHORED ROW + THE GRAMMAR CENSUS: wild_strike carries the full
//      exemplar (the settled 2 branches × 3 rungs + the neutral, in the
//      SUGAR form), rung 1 keeps M0's measured payloads, and EVERY def
//      wearing a tree folds through engine/skilltree.ts and validates:
//      unique node ids, every node root-reachable, THE COVER LAW (every
//      limb's terminal walk absorbs the cap points), `over` on the audited
//      whitelist (arcDeg/spreadDeg/channel.ramp/channel.rampMove), node
//      mods naming real stats, grafts naming live supports. A stray M2 row
//      fails here, never in a player's face.
//   B. THE LEVEL SEAL + THE FIELD DISCIPLINE: spends refuse below the
//      milestone, land in sanctuary (the workshop law), and refuse under
//      hot blood in the field through the standing swapRefusal words.
//   C. THE HARD LOCK + THE SPEND LAW: one point per node against the
//      bandPointsAt budget; the FIRST point into a branch SEALS the rival
//      (refusal words name the sealed path); the neutral is lock-exempt;
//      rungs chain in order; at cap the exact cover completes (3 + 1) and
//      nothing further spends. Refusals never mutate; hostile intents no-op.
//   D. THE RESOLVED VIEW REACHES THE CAST PATH (drawn == tested): delivery/
//      aim folds (M0's pins), the CHANNEL lane (instanceChannel folds
//      ramp/rampMove; unpicked returns the def's object BY REFERENCE), the
//      MODS lane (instanceInnateMods carries node mods into every sheet
//      read), and live episodes: the Long Point's held damage RAMPS where
//      the rampless branch stays flat, the Monsoon's held stride FREES
//      where the base drags, and M0's sector/arc geometry still measures
//      true under the real engine.
//   E. PERSISTENCE + THE M0 FOLD: multi-node spends survive the real
//      serializeCharacter → rebuildSkill round trip; an M0-era single-pick
//      row loads as a 1-point spend (costless by construction); orphans,
//      rival-branch picks, broken rung chains and over-budget tails drop
//      with console notes through the ONE validation seam.
//   F. THE TRANSPARENCY LAW: the full tree authored but UNPICKED is
//      byte-identical to the tree field deleted — same-seed fingerprints.
//   G. UNLEARN/RELEARN RETENTION: the instance travels whole to the bag
//      and back — spent points intact (the attunedForm idiom, now pinned).
//   H. THE MONSTER PIN CAPABILITY: a MonsterDef.skillTrees pin mints kit
//      instances with spent nodes, resolved through the views — the
//      telegraph's instanceDelivery fold shows the pinned arc (drawn ==
//      tested for enemy wedges). Capability only: the stamp is probe-local.
//   I. THE MILESTONE POPUP DISCIPLINE: a band completion banks a pip; the
//      popup request fires ONLY at the disciplined calm — never mid-combat.
//   J. THE GRAFT LANE: a node's graft injects at recalcSeat (socket-free,
//      derived, no-second-copy), and an unknown support grants silence.
//   K. THE CO-OP WIRE: treeNodes ride SkillInstW (tn) through the real
//      serializeSeatMeta → applySeatMeta round trip; hostile tn sanitizes.
//   L. THE CENSUS BRANCH AXIS: compatCensus enumerates `skill@branch`
//      terminal hosts (exactly two per moded skill), hostTreeNodes answers
//      the exact-cover allocation, parseHostId round-trips, and pinHostTree
//      derives the node grafts recalcSeat derives (every grafting host's
//      census row agrees with the live socket gate).
//   M. THE GATHER'S STRIDE (ruled 2026-08-20): a Gathered Casting
//      conversion's synthesized spec binds movement (slowed ≈ 0.5×).
//   N. THE GRAPH GRAMMAR (2026-09-04, engine/skilltree.ts): the sugar fold
//      keeps the M1 words/verdicts byte-identical (rung chains, rung-1
//      forks, a lock-free neutral, limbs = the authored branches); the
//      graph form on a probe-local fixture — any-of links, symmetric
//      excludes, a sub-fork sealing by its own name, a cross-link opening
//      either way, ranked nodes (repeated ids) through the spend
//      predicate, the loader seam, the mods fold; the derived layout
//      (deterministic, pin-overridable, collision-free across every
//      authored tree); the census's terminal walk on a graph limb.
// Run: npx tsx balance/probe_skillmodes.ts
// ---------------------------------------------------------------------------

import { bootSimEngine, makeSimWorld, SIM_CFG } from '../src/sim/arena';
import { applyBuild } from '../src/sim/builds';
import { seedGlobalRandom } from '../src/sim/rng';
import { starterBuild } from '../src/sim/data/builds';
import { SKILLS } from '../src/data/skills';
import { MONSTERS } from '../src/data/monsters';
import { SUPPORTS } from '../src/data/supports';
import { invocationTreeErrors } from '../src/engine/invocation';
import { START_ZONE } from '../src/data/zones';
import { STAT_DEFS } from '../src/engine/stats';
import {
  bandPointsAt, instanceAim, instanceChannel, instanceDelivery, impactTreeOverrideErrors, treeAuraOverrideErrors, instanceMods,
  instanceTreeMods, makeSkillInstance, MAX_SKILL_LEVEL,
  skillContextTags, supportFitsInstOrCrew, treeNodeOf, treeNodeRefusal,
  treePickOpen, treePointsSpent, treeSpentBranch, validTreeNodes,
  type SkillDef, type SkillTreeSpec,
} from '../src/engine/skills';
import {
  treeGraph, treeLimbOfNode, treeLimbs, treeNodeRanks, treeSealedSet, treeSpentCount,
  TREE_LAYOUT_CFG,
} from '../src/engine/skilltree';
import { serializeCharacter, rebuildSkill } from '../src/meta/character';
import { serializeSeatMeta, applySeatMeta } from '../src/net/snapshot';
import { compatCensus, hostIdOf, hostTreeNodes, ledgerSkillIds, parseHostId, pinHostTree } from '../src/sim/compat';
import { emptyLedger, reconcileLedger } from '../src/sim/ledger';
import { setSimTap } from '../src/engine/tap';
import { updateAI } from '../src/engine/ai';
import { vec } from '../src/core/math';
import type { MetaAction, PlayerInput } from '../src/net/intent';
import type { World } from '../src/engine/world';

let failed = 0;
const check = (name: string, ok: boolean, detail = ''): void => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`);
  if (!ok) failed++;
};

bootSimEngine();
seedGlobalRandom(0x50de);

const SPRINKLER = ['ws_sprinkler', 'ws_cloudburst', 'ws_monsoon'];
const DUELIST = ['ws_duelist', 'ws_firm_wrist', 'ws_long_point'];
const NEUTRAL = 'ws_economy';

// ------------------------------------------------- A. THE AUTHORED ROW ----
const WS = SKILLS.wild_strike;
const tree = WS.tree as SkillTreeSpec | undefined;
check('A: wild_strike carries the M1 exemplar tree', !!tree);
check('A: the pick opens at level 5 (the settled milestone)', tree?.level === 5);
check('A: duelist batch expands Wild Strike to 15 nodes and a four-rank neutral',
  tree?.nodes?.length === 15 && treeLimbs(WS).length === 2
  && treeNodeOf(WS, NEUTRAL)?.ranks === 4);
const sprinkler = treeNodeOf(WS, 'ws_sprinkler');
const duelist = treeNodeOf(WS, 'ws_duelist');
check('A: rung 1 keeps the MEASURED identity payloads (30/130 vs 16/24)',
  sprinkler?.over?.arcDeg === 30 && sprinkler?.over?.spreadDeg === 130
  && duelist?.over?.arcDeg === 16 && duelist?.over?.spreadDeg === 24);
check('A: deepening routes inherit their complete identity from the exclusive trunk',
  [DUELIST, SPRINKLER].every((route, i) => {
    const inst = makeSkillInstance(WS, 20); inst.treeNodes = route;
    return (instanceDelivery(inst) as { arcDeg?: number }).arcDeg === [16, 30][i]
      && instanceAim(inst)?.random?.spreadDeg === [24, 130][i];
  }));

// The grammar census: every tree-wearing def, hard-pinned (boot validation
// warns; this gate FAILS) — THE GRAPH LAWS (engine/skilltree.ts): the fold
// takes every wearer, ids unique, every node root-reachable, THE COVER LAW
// (each limb's terminal walk + the lock-free ground absorbs the cap
// budget), and the payload whitelist on every graph node.
const OVER_KEYS = new Set(['arcDeg', 'spreadDeg', 'channel', 'summon', 'tags', 'chargeCost', 'ground', 'castCycle', 'construct', 'reduceCooldowns', 'recallImpales', 'aura', 'invocation']);
const SUMMON_KEYS = new Set(['count', 'maxActive', 'duration', 'replenish', 'monsterId', 'pool', 'selectPool', 'crewSkills', 'crewAuras', 'crewMods', 'escort', 'shell', 'crewRules', 'crewInherit', 'crewOnDeath', 'devour', 'placeAt', 'strikeRelease']);
const OVER_CHANNEL_KEYS = new Set(['ramp', 'rampMove']);
let censusBad = '';
let treeWearers = 0;
for (const def of Object.values(SKILLS)) {
  const t = def.tree;
  if (!t) continue;
  treeWearers++;
  if (t.level < 1) censusBad += ` ${def.id}:level<1`;
  const g = treeGraph(def);
  if (!g || g.nodes.size === 0) { censusBad += ` ${def.id}:no-graph`; continue; }
  for (const d of g.dupes) censusBad += ` ${def.id}/${d}:dup-node-id`;
  if (g.order.length !== g.nodes.size) censusBad += ` ${def.id}:unreachable-nodes`;
  const budget = bandPointsAt(MAX_SKILL_LEVEL);
  const limbIds = new Set(g.limbs.flatMap(b => b.rungs.map(n => n.id)));
  const free = g.order.filter(id => !limbIds.has(id));
  const walkOf = (ids: string[]): number => {
    const all = [...ids];
    for (const id of ids) for (let r = 1; r < (g.nodes.get(id)?.ranks ?? 1); r++) all.push(id);
    return validTreeNodes(def, all, undefined, { quiet: true })?.length ?? 0;
  };
  for (const limb of g.limbs) {
    if (walkOf([...limb.rungs.map(n => n.id), ...free]) < budget) censusBad += ` ${def.id}/${limb.id}:strands-points`;
  }
  for (const id of g.order) {
    const n = g.nodes.get(id)!.node;
    for (const k of Object.keys(n.over ?? {})) {
      if (!OVER_KEYS.has(k)) censusBad += ` ${def.id}/${n.id}:over.${k}-off-whitelist`;
    }
    for (const k of Object.keys(n.over?.channel ?? {})) {
      if (!OVER_CHANNEL_KEYS.has(k)) censusBad += ` ${def.id}/${n.id}:over.channel.${k}-off-whitelist`;
    }
    if (n.over?.ground && (def.delivery.type !== 'ground' || (n.over.ground.follow !== undefined && n.over.ground.follow !== true)
      || Object.keys(n.over.ground).some(k => !['follow', 'domain', 'pulse'].includes(k)))) censusBad += ` ${def.id}/${n.id}:over.ground-invalid`;
    for (const error of impactTreeOverrideErrors(def, n)) censusBad += ` ${def.id}/${n.id}:${error}`;
    for (const error of treeAuraOverrideErrors(def, n)) censusBad += ` ${def.id}/${n.id}:${error}`;
    for (const error of invocationTreeErrors(def, n)) censusBad += ` ${def.id}/${n.id}:${error}`;
    const constructOver = n.over?.construct;
    if (constructOver && (def.delivery.type !== 'construct'
      || Object.entries(constructOver).some(([k, v]) => !['castSkillId', 'range', 'duration', 'maxActive', 'life', 'placeRange', 'domeRadius', 'domeSlow'].includes(k)
        || (k === 'castSkillId' ? !SKILLS[String(v)] : !Number.isFinite(v) || Number(v) <= 0)))) censusBad += ` ${def.id}/${n.id}:over.construct-invalid`;
    const treeChargeCost = n.over?.chargeCost;
    const reduceCooldowns = n.over?.reduceCooldowns;
    if (reduceCooldowns && (!def.effects.some(fx => fx.type === 'reduceCooldowns')
      || !Number.isFinite(reduceCooldowns.seconds) || reduceCooldowns.seconds < 0
      || !Number.isFinite(reduceCooldowns.fraction) || reduceCooldowns.fraction < 0 || reduceCooldowns.fraction > 1
      || Object.keys(reduceCooldowns).some(k => !['seconds', 'fraction'].includes(k)))) censusBad += ` ${def.id}/${n.id}:over.reduceCooldowns-invalid`;
    const castCycle = n.over?.castCycle;
    if (castCycle && (!def.castCycle || !Number.isInteger(castCycle.count) || castCycle.count < 1
      || !castCycle.buff.id || !(castCycle.buff.duration > 0)
      || Object.keys(castCycle).some(k => !['count', 'buff'].includes(k)))) censusBad += ` ${def.id}/${n.id}:over.castCycle-invalid`;
    if (treeChargeCost && (!treeChargeCost.charge
      || (treeChargeCost.amount !== 'all' && (!Number.isInteger(treeChargeCost.amount) || treeChargeCost.amount < 1))
      || Object.keys(treeChargeCost).some(k => !['charge', 'amount', 'minimum', 'damagePerCharge', 'projectilesPerCharge', 'repeatsPerCharge', 'optional'].includes(k)))) {
      censusBad += ` ${def.id}/${n.id}:over.chargeCost-invalid`;
    }
    for (const m of n.mods ?? []) {
      if (!STAT_DEFS[m.stat]) censusBad += ` ${def.id}/${n.id}:mod-stat-${m.stat}-unknown`;
    }
    for (const k of Object.keys(n.over?.summon ?? {})) {
      if (!SUMMON_KEYS.has(k)) censusBad += ` ${def.id}/${n.id}:over.summon.${k}-off-whitelist`;
    }
    if (n.graft && !SUPPORTS[n.graft.support]) censusBad += ` ${def.id}/${n.id}:graft-${n.graft.support}-unknown`;
  }
}
check('A: the tree census — every wearer folds clean under the graph laws, whitelist clean',
  censusBad === '', censusBad || `${treeWearers} wearer(s)`);

// ------------------------- B. THE LEVEL SEAL + THE FIELD DISCIPLINE -------
const w: World = makeSimWorld('swashbuckler', 0x5eed);
const seat = w.localSeat;
const build = starterBuild('swashbuckler', 4); // gem level 2 — below the milestone
build.bar = ['wild_strike'];
const warns = applyBuild(w, build, 0x9ea7);
if (warns.length) console.log('  build warnings:', warns.join(' | '));
const inst = seat.meta.knownSkills.get('wild_strike')!;
const pick = (nodeId: string): void =>
  w.applyAction(seat, { t: 'pickTreeNode', skillId: 'wild_strike', nodeId });

check('B: the sim arena is sanctuary ground', w.zone.objective?.kind === 'safe');
check('B: below the milestone the row is sealed', !treePickOpen(inst) && inst.level < 5);
pick('ws_duelist');
check('B: a sealed spend refuses — state untouched', inst.treeNodes === undefined);
check('B: the refusal speaks the milestone', treeNodeRefusal(inst, 'ws_duelist') === 'the path opens at level 5');
inst.level = 5;
check('B: at level 5 the row opens with ONE point', treePickOpen(inst) && bandPointsAt(inst.level) === 1);
pick('ws_duelist');
check('B: the spend lands in sanctuary (the workshop law)',
  inst.treeNodes?.length === 1 && inst.treeNodes[0] === 'ws_duelist');
check('B: the bar instance IS the book instance (the spend reaches the cast path)',
  seat.actor.skills.some(s => s === inst));

// ------------------------ C. THE HARD LOCK + THE SPEND LAW ----------------
check('C: the branch is DERIVED from spent nodes', treeSpentBranch(inst)?.id === 'ws_duelist');
pick('ws_sprinkler');
check('C: THE HARD LOCK — the rival branch refuses, state untouched',
  inst.treeNodes?.length === 1 && inst.treeNodes[0] === 'ws_duelist');
check('C: the lock speaks the sealed path\'s own name',
  treeNodeRefusal(inst, 'ws_sprinkler') === "The Sprinkler's path is sealed");
pick('ws_long_point');
check('C: the rung chain — rung 3 before rung 2 refuses',
  inst.treeNodes?.length === 1
  && treeNodeRefusal(inst, 'ws_long_point') === 'The Firm Wrist comes first');
pick('ws_firm_wrist');
check('C: one point at level 5 — the second spend refuses on the budget',
  inst.treeNodes?.length === 1
  && treeNodeRefusal(inst, 'ws_firm_wrist') === 'no Ability point free — the next comes at level 10');
check('C: the neutral is lock-exempt but still budget-bound',
  treeNodeRefusal(inst, NEUTRAL) === 'no Ability point free — the next comes at level 10');
inst.level = 10;
pick(NEUTRAL);
check('C: at level 10 the neutral lands beside the committed branch (2/2 spent)',
  inst.treeNodes?.length === 2 && inst.treeNodes[1] === NEUTRAL
  && treeSpentBranch(inst)?.id === 'ws_duelist');
inst.level = 20;
pick('ws_firm_wrist');
pick('ws_long_point');
check('C: the exact cover completes at cap — the walked branch + the neutral',
  inst.treeNodes?.length === 4 && treePointsSpent(inst) === bandPointsAt(20));
check('C: at the cover every remaining node is sealed or spent',
  treeNodeRefusal(inst, 'ws_sprinkler') === "The Sprinkler's path is sealed"
  && treeNodeRefusal(inst, 'ws_cloudburst') === "The Sprinkler's path is sealed");
pick('ws_duelist');
check('C: a re-spend of a walked node no-ops', inst.treeNodes?.length === 4);
pick('no_such_node');
w.applyAction(seat, { t: 'pickTreeNode', skillId: 'wild_strike' } as unknown as MetaAction);
w.applyAction(seat, { t: 'pickTreeNode', skillId: 7, nodeId: 'ws_duelist' } as unknown as MetaAction);
w.applyAction(seat, { t: 'pickTreeNode', skillId: 'no_such_skill', nodeId: 'ws_duelist' } as unknown as MetaAction);
check('C: bogus/malformed/hostile intents no-op through the validator',
  inst.treeNodes?.length === 4);

// Into the field: the discipline bites the FIRST spend where sanctuary
// doesn't waive it (the hard lock means there is no re-pick to gate).
const field = Object.values(w.zoneMap).find(z =>
  z.id !== START_ZONE && !z.boundless && z.objective?.kind !== 'safe');
check('B: the chart offers unsafe ground', !!field, field?.id ?? 'none');
w.loadZone(field!.id);
for (const a of w.actors) if (a.team === 'enemy') a.dead = true;
inst.treeNodes = undefined; // a fresh tree for the field test
w.lastCombatAt = w.time; // hot blood
pick('ws_duelist');
check('B: hot blood refuses the first spend, in the standing words',
  inst.treeNodes === undefined
  && w.swapRefusal(seat, 'socket') === 'the blood is still hot');
w.time += 30; // the calm returns
pick('ws_duelist');
{
  // (a fresh read — tsc narrowed treeNodes to undefined through the
  // opaque applyAction mutation above)
  const now = seat.meta.knownSkills.get('wild_strike')!.treeNodes;
  check('B: the calm re-opens the hands — the spend lands',
    now?.length === 1 && now[0] === 'ws_duelist');
}

// ------------------------------- D. THE RESOLVED VIEW ---------------------
inst.treeNodes = ['ws_duelist'];
check('D: picked, instanceDelivery folds the arc (duelist 16)',
  (instanceDelivery(inst) as { arcDeg?: number }).arcDeg === 16);
check('D: picked, instanceAim folds the sector (duelist 24)',
  instanceAim(inst)?.random?.spreadDeg === 24);
inst.treeNodes = undefined;
check('D: UNPICKED, the resolvers return the def\'s own objects BY REFERENCE',
  instanceDelivery(inst) === WS.delivery && instanceAim(inst) === WS.aim
  && instanceChannel(inst) === WS.channel);
inst.treeNodes = [...DUELIST];
check('D: the Long Point folds a damage ramp into the resolved channel',
  instanceChannel(inst)?.ramp?.per === 0.06 && WS.channel?.ramp === undefined);
inst.treeNodes = [...SPRINKLER];
check('D: the Monsoon folds a stride ramp into the resolved channel',
  instanceChannel(inst)?.rampMove?.per === 0.08 && WS.channel?.rampMove === undefined);

// THE MODS LANE: node mods reach every sheet read via instanceInnateMods.
const tags = skillContextTags(WS);
const sheetOf = (stat: string): number =>
  seat.actor.sheet.get(stat, tags, instanceMods(inst));
inst.treeNodes = undefined;
const baseAtk = sheetOf('attackSpeed');
const baseCrit = sheetOf('critChance');
const baseMob = sheetOf('channelMobility');
inst.treeNodes = ['ws_sprinkler', 'ws_cloudburst'];
check('D: the Cloudburst\'s attackSpeed mod reaches the sheet (+0.12 on the increased lane)',
  Math.abs(sheetOf('attackSpeed') - baseAtk - 0.12) < 0.001,
  `${baseAtk.toFixed(3)} → ${sheetOf('attackSpeed').toFixed(3)}`);
inst.treeNodes = ['ws_duelist', 'ws_firm_wrist'];
check('D: the Firm Wrist\'s critChance mod reaches the sheet (+7% flat)',
  Math.abs(sheetOf('critChance') - baseCrit - 0.07) < 0.001,
  `${baseCrit.toFixed(3)} → ${sheetOf('critChance').toFixed(3)}`);
inst.treeNodes = [NEUTRAL];
check('D: the neutral\'s channelMobility mod reaches the sheet (+0.05 flat per rank)',
  Math.abs(sheetOf('channelMobility') - baseMob - 0.05) < 0.001);
inst.treeNodes = undefined;

// The cast path itself: rolled bearings + victims through the REAL engine
// (M0's geometry pins — rung 1 alone, the identity payloads).
function castEpisode(nodes: string[] | undefined, seed: number, opts?: {
  moveX?: boolean; seconds?: number;
}): {
  maxAbsBearingDeg: number; victims: number; casts: number;
  earlyHit: number; lateHit: number; earlyDx: number; lateDx: number;
} {
  const restore = seedGlobalRandom(seed);
  try {
    const ww = makeSimWorld('swashbuckler', seed);
    const b = starterBuild('swashbuckler', 20);
    b.bar = ['wild_strike'];
    if (nodes) {
      b.skills = b.skills.map(s => s.id === 'wild_strike' ? { ...s, treeNodes: [...nodes] } : s);
    }
    applyBuild(ww, b, 0x9ea7);
    const st = ww.localSeat;
    const p = ww.player;
    const slot = p.skills.findIndex(s => s?.def.id === 'wild_strike');
    const gap = 70;
    const victims = new Set<number>();
    const seconds = opts?.seconds ?? 20;
    for (const bDeg of [0, -25, 25, -50, 50]) {
      const ang = bDeg * Math.PI / 180;
      const d = ww.createMonster('target_dummy', 1, 'enemy');
      d.pos = vec(p.pos.x + Math.cos(ang) * gap, p.pos.y + Math.sin(ang) * gap);
      ww.actors.push(d);
    }
    let casts = 0, frameCasts = 0, maxAbs = 0;
    let earlyHit = 0, earlyN = 0, lateHit = 0, lateN = 0;
    let t = 0;
    setSimTap({
      onCast: (caster, i2) => {
        if (caster === p && i2.def.id === 'wild_strike') { casts++; frameCasts++; }
      },
      onHit: (attacker, target, result) => {
        if (attacker !== p || target === p || result.evaded || result.immune) return;
        victims.add(target.id);
        if (t >= 1 && t <= 5) { earlyHit += result.total; earlyN++; }
        if (t >= seconds - 6 && t <= seconds) { lateHit += result.total; lateN++; }
      },
    });
    const dt = SIM_CFG.dt;
    const held = new Array(8).fill(false); held[slot] = true;
    const edge = new Array(8).fill(false);
    // Stride windows accumulate per-tick |displacement| over RANGES (no
    // exact-tick float matching): early = [0.5, 3.5), late = the last 3s.
    // The walk PING-PONGS every 2s so the arena wall never clamps a window
    // (a one-way run hits the east wall at ~785px and reads zero late).
    let earlyDx = 0, lateDx = 0;
    for (let tick = 0; tick < Math.round(seconds / dt); tick++) {
      t = tick * dt;
      frameCasts = 0;
      const prevX = p.pos.x;
      const aimAt = vec(p.pos.x + gap, p.pos.y);
      const dir = Math.floor(t / 2) % 2 === 0 ? 1 : -1;
      const intent: PlayerInput = {
        dx: opts?.moveX ? dir : 0, dy: 0, aim: aimAt, held, edge,
      };
      const inputs = new Map<string, PlayerInput>();
      inputs.set(st.id, intent);
      ww.applyInputs(inputs, dt);
      for (const a of ww.actors) updateAI(a, ww, dt);
      ww.update(dt);
      const step = Math.abs(p.pos.x - prevX);
      if (t >= 0.5 && t < 3.5) earlyDx += step;
      if (t >= seconds - 3.5 && t < seconds - 0.5) lateDx += step;
      if (frameCasts > 0 && !opts?.moveX) {
        const baseAng = Math.atan2(aimAt.y - p.pos.y, aimAt.x - p.pos.x);
        let rel = (p.facing - baseAng) % (Math.PI * 2);
        if (rel > Math.PI) rel -= Math.PI * 2;
        if (rel < -Math.PI) rel += Math.PI * 2;
        maxAbs = Math.max(maxAbs, Math.abs(rel) * 180 / Math.PI);
      }
    }
    setSimTap(null);
    return {
      maxAbsBearingDeg: maxAbs, victims: victims.size, casts,
      earlyHit: earlyN ? earlyHit / earlyN : 0, lateHit: lateN ? lateHit / lateN : 0,
      earlyDx, lateDx,
    };
  } finally {
    setSimTap(null);
    restore();
  }
}

const dueEp = castEpisode(['ws_duelist'], 0xd0e1);
check('D: the duelist\'s rolled bearings live inside its 24° sector',
  dueEp.casts > 60 && dueEp.maxAbsBearingDeg <= 12.5,
  `casts ${dueEp.casts}, max |bearing| ${dueEp.maxAbsBearingDeg.toFixed(1)}°`);
check('D: the duelist touches ONLY the dead-ahead body (arc 16 through the real cone test)',
  dueEp.victims === 1, `victims ${dueEp.victims}`);
const sprEp = castEpisode(['ws_sprinkler'], 0xd0e2);
check('D: the sprinkler\'s wander rolls beyond 50° (the 130° sector is live)',
  sprEp.casts > 60 && sprEp.maxAbsBearingDeg > 50,
  `casts ${sprEp.casts}, max |bearing| ${sprEp.maxAbsBearingDeg.toFixed(1)}°`);
check('D: the sprinkler rains on the whole ring (5/5 victims)',
  sprEp.victims === 5, `victims ${sprEp.victims}`);
const baseEp = castEpisode(undefined, 0xd0e3);
check('D: unpicked, the wander honors the base 90° sector (no roll past 45°)',
  baseEp.casts > 60 && baseEp.maxAbsBearingDeg <= 45.5,
  `casts ${baseEp.casts}, max |bearing| ${baseEp.maxAbsBearingDeg.toFixed(1)}°`);

// THE RAMP EPISODE: the Long Point's held line bites deeper late in the
// hold; the rampless rung-2 build stays flat (the A/B inside the pin).
const rampEp = castEpisode([...DUELIST], 0xd0e4);
const flatEp = castEpisode(['ws_duelist', 'ws_firm_wrist'], 0xd0e4);
const rampRatio = rampEp.earlyHit > 0 ? rampEp.lateHit / rampEp.earlyHit : 0;
const flatRatio = flatEp.earlyHit > 0 ? flatEp.lateHit / flatEp.earlyHit : 0;
check('D: the Long Point\'s held damage RAMPS (late/early grows past the flat control)',
  rampRatio > flatRatio + 0.1 && rampRatio > 1.12,
  `ramp ${rampRatio.toFixed(2)} vs flat ${flatRatio.toFixed(2)}`);

// THE STRIDE EPISODE: the Monsoon frees the held stride; the rampless
// sprinkler drags at the channel's own factor throughout.
const runEp = castEpisode([...SPRINKLER], 0xd0e5, { moveX: true, seconds: 12 });
const dragEp = castEpisode(['ws_sprinkler', 'ws_cloudburst'], 0xd0e5, { moveX: true, seconds: 12 });
const runGrowth = runEp.earlyDx > 1 ? runEp.lateDx / runEp.earlyDx : 0;
const dragGrowth = dragEp.earlyDx > 1 ? dragEp.lateDx / dragEp.earlyDx : 0;
check('D: the Monsoon\'s held stride FREES (late window outruns early; the control stays flat)',
  runGrowth > dragGrowth + 0.15 && runGrowth > 1.2,
  `monsoon ${runGrowth.toFixed(2)}× vs control ${dragGrowth.toFixed(2)}×`);

// ------------------------------------ E. PERSISTENCE ----------------------
inst.treeNodes = [...DUELIST, NEUTRAL];
inst.level = 20;
const save = serializeCharacter(w);
const savedRow = save.knownSkills.find(s => s.skillId === 'wild_strike');
check('E: the full spend serializes sparse (the attunedForm idiom)',
  JSON.stringify(savedRow?.treeNodes) === JSON.stringify([...DUELIST, NEUTRAL]));
check('E: unpicked rows stay silent on the wire',
  !save.knownSkills.some(s => s.skillId !== 'wild_strike' && 'treeNodes' in s));
const rebuilt = rebuildSkill(savedRow!);
check('E: the spends survive the rebuild whole',
  JSON.stringify(rebuilt?.treeNodes) === JSON.stringify([...DUELIST, NEUTRAL]));

let noted = 0;
const realWarn = console.warn;
const countNotes = <T>(fn: () => T): T => {
  noted = 0;
  console.warn = (...args: unknown[]): void => {
    if (String(args[0] ?? '').includes('[skill tree]')) noted++;
    else realWarn(...args);
  };
  try { return fn(); } finally { console.warn = realWarn; }
};

// THE M0 FOLD: a single rung-1 pick at level ≥5 loads as a 1-point spend —
// no trim, no note, costless by construction (bandPointsAt(7) = 1).
const m0row = countNotes(() => rebuildSkill({
  skillId: 'wild_strike', level: 7, rarity: 'common', sockets: [null],
  treeNodes: ['ws_sprinkler'],
}));
check('E: THE M0 FOLD — a spike-era single pick loads as a costless 1-point spend',
  m0row?.treeNodes?.length === 1 && m0row.treeNodes[0] === 'ws_sprinkler' && noted === 0);

const orphaned = countNotes(() => rebuildSkill({ ...savedRow!, treeNodes: ['ws_retired_node'] }));
check('E: an orphaned pick drops with a console note',
  orphaned !== null && orphaned!.treeNodes === undefined && noted === 1, `noted ${noted}`);
const rival = countNotes(() => validTreeNodes(WS, ['ws_duelist', 'ws_sprinkler'], 20));
check('E: a rival-branch id drops through the one seam (the lock survives loading)',
  JSON.stringify(rival) === JSON.stringify(['ws_duelist']) && noted === 1);
const chainless = countNotes(() => validTreeNodes(WS, ['ws_long_point', 'ws_duelist'], 20));
check('E: a broken rung chain drops its stray (order enforced in id order)',
  JSON.stringify(chainless) === JSON.stringify(['ws_duelist']) && noted === 1);
const trimmed = countNotes(() => validTreeNodes(WS, ['ws_duelist', 'ws_firm_wrist', NEUTRAL], 5));
check('E: the budget trims the over-spent tail against the LEVEL (1 point at 5)',
  JSON.stringify(trimmed) === JSON.stringify(['ws_duelist']) && noted === 2);
const legacy = rebuildSkill({
  skillId: 'wild_strike', level: 3, rarity: 'common', sockets: [null],
});
check('E: a legacy row (no treeNodes) loads unchanged', legacy !== null && legacy!.treeNodes === undefined);
inst.treeNodes = undefined;

// ------------------------------ F. THE TRANSPARENCY LAW -------------------
function fingerprint(arm: 'authored' | 'stripped' | 'picked', seed: number): number {
  const savedTree = WS.tree;
  if (arm === 'stripped') delete (WS as { tree?: SkillTreeSpec }).tree;
  const restore = seedGlobalRandom(seed);
  let h = 0x811c9dc5 >>> 0;
  const mix = (n: number): void => {
    h ^= (Math.round(n * 1000) + 0x9e3779b9) >>> 0;
    h = Math.imul(h, 0x01000193) >>> 0;
  };
  try {
    const ww = makeSimWorld('swashbuckler', seed);
    const b = starterBuild('swashbuckler', 8);
    b.bar = ['wild_strike'];
    if (arm === 'picked') {
      b.skills = b.skills.map(s => s.id === 'wild_strike' ? { ...s, treeNodes: ['ws_duelist'] } : s);
    }
    applyBuild(ww, b, 0x9ea7);
    const st = ww.localSeat;
    const p = ww.player;
    const slot = p.skills.findIndex(s => s?.def.id === 'wild_strike');
    for (let i = 0; i < 3; i++) {
      const z = ww.createMonster('zombie', 8, 'enemy');
      z.pos = vec(p.pos.x + 90 + i * 30, p.pos.y + (i - 1) * 40);
      ww.actors.push(z);
    }
    setSimTap({
      onCast: (caster, i2) => { if (caster === p) mix(i2.def.id === 'wild_strike' ? 1 : 2); },
      onHit: (attacker, target, result) => {
        mix(result.total); mix(target.id); mix(attacker.id);
      },
    });
    const dt = SIM_CFG.dt;
    const held = new Array(8).fill(false); held[slot] = true;
    const edge = new Array(8).fill(false);
    for (let tick = 0; tick < Math.round(12 / dt); tick++) {
      const intent: PlayerInput = {
        dx: 0, dy: 0, aim: vec(p.pos.x + 90, p.pos.y), held, edge,
      };
      const inputs = new Map<string, PlayerInput>();
      inputs.set(st.id, intent);
      ww.applyInputs(inputs, dt);
      for (const a of ww.actors) updateAI(a, ww, dt);
      ww.update(dt);
      if (tick % 20 === 0) {
        mix(p.pos.x); mix(p.pos.y); mix(p.facing); mix(p.mana); mix(p.life);
        for (const a of ww.actors) { if (!a.dead) { mix(a.pos.x); mix(a.pos.y); } }
      }
    }
    setSimTap(null);
    return h;
  } finally {
    setSimTap(null);
    restore();
    if (arm === 'stripped') WS.tree = savedTree;
  }
}

for (const seed of [0xfab1e, 0x51de]) {
  const authored = fingerprint('authored', seed);
  const stripped = fingerprint('stripped', seed);
  check(`F: unpicked ≡ no-tree-at-all, byte-identical (seed 0x${seed.toString(16)})`,
    authored === stripped, `0x${authored.toString(16)} vs 0x${stripped.toString(16)}`);
}
{
  const authored = fingerprint('authored', 0xfab1e);
  const picked = fingerprint('picked', 0xfab1e);
  check('F: the picked arm DIVERGES — the fingerprint can see',
    authored !== picked, `both 0x${authored.toString(16)}`);
}

// --------------------- G. UNLEARN / RELEARN RETENTION ---------------------
w.loadZone(START_ZONE); // back to sanctuary — the discipline waives
inst.treeNodes = ['ws_duelist', 'ws_firm_wrist'];
inst.level = 10;
{
  const ok = w.unlearnSkill('wild_strike', seat);
  // THE RESIDENCE (M1): unlearning mints the bag WRAPPER item — the whole
  // progression truth (level, picks) rides its payload; instance identity
  // retired with the side array, payload fidelity is the new law.
  const baggedItem = seat.meta.items.find(i => i.gem?.kind === 'skill' && i.gem.skillId === 'wild_strike');
  const payload = baggedItem?.gem?.kind === 'skill' ? baggedItem.gem : null;
  check('G: unlearn moves the WHOLE gem to the bag — spends ride along',
    ok && !!payload && payload.level === 10
    && JSON.stringify(payload.treeNodes) === JSON.stringify(['ws_duelist', 'ws_firm_wrist']));
  const learned = !!baggedItem && w.learnSkill(baggedItem.uid, seat);
  const back = seat.meta.knownSkills.get('wild_strike');
  check('G: relearn rebuilds the gem whole — the picks survive the round trip',
    learned && back?.level === 10 && JSON.stringify(back?.treeNodes) === JSON.stringify(['ws_duelist', 'ws_firm_wrist']));
}

// --------------------- H. THE MONSTER PIN CAPABILITY ----------------------
{
  const dervish = MONSTERS.nettle_dervish;
  check('H: the capability subject carries the moded skill in its kit',
    !!dervish && dervish.skills.includes('wild_strike'));
  const saved = dervish.skillTrees;
  dervish.skillTrees = { wild_strike: ['ws_duelist'] };
  try {
    const pinned = w.createMonster('nettle_dervish', 10, 'enemy');
    const kit = pinned.skills.find(s => s?.def.id === 'wild_strike');
    check('H: the kit mints with the pinned spend (the one validation seam)',
      kit?.treeNodes?.length === 1 && kit.treeNodes[0] === 'ws_duelist');
    check('H: the TELEGRAPH view folds the pinned arc — drawn == tested for enemy wedges',
      !!kit && (instanceDelivery(kit) as { arcDeg?: number }).arcDeg === 16);
    check('H: the def itself stays frozen (the fold is per-instance)',
      (WS.delivery as { arcDeg?: number }).arcDeg === 30);
    const bare = w.createMonster('nettle_dervish', 10, 'enemy');
    dervish.skillTrees = undefined;
    const unpinned = w.createMonster('nettle_dervish', 10, 'enemy');
    const bareKit = unpinned.skills.find(s => s?.def.id === 'wild_strike');
    check('H: an unpinned kit stays bare — the capability costs nothing unused',
      bareKit?.treeNodes === undefined);
    void bare;
  } finally {
    dervish.skillTrees = saved;
  }
}

// --------------------- I. THE MILESTONE POPUP DISCIPLINE ------------------
{
  w.loadZone(field!.id);
  for (const a of w.actors) if (a.team === 'enemy') a.dead = true;
  const inst2 = seat.meta.knownSkills.get('wild_strike')!;
  inst2.level = 4;
  inst2.treeNodes = undefined;
  w.grantAbilityEssence(seat, 1, 50);
  // Mid-combat: a live hostile at arm's reach + hot blood.
  const foe = w.createMonster('zombie', 8, 'enemy');
  foe.pos = vec(seat.actor.pos.x + 100, seat.actor.pos.y);
  w.actors.push(foe);
  w.lastCombatAt = w.time;
  const leveled = w.levelUpSkill('wild_strike', seat);
  check('I: the band completion banks the pip (level 5 crossed)',
    leveled && inst2.level === 5 && bandPointsAt(5) === 1);
  w.treePopupRequested = false;
  for (let i = 0; i < 40; i++) w.update(SIM_CFG.dt);
  check('I: mid-combat the popup NEVER offers (the disciplined-calm law)',
    !w.treePopupRequested && w.swapRefusal(seat, 'socket') !== null);
  foe.dead = true;
  w.time += 30; // the calm returns
  for (let i = 0; i < 40; i++) w.update(SIM_CFG.dt);
  check('I: the calm fires the offer once, naming the skill',
    w.treePopupRequested && w.treePopupSkillId === 'wild_strike'
    && w.treePopupSeatId === seat.id);
  w.treePopupRequested = false;
  for (let i = 0; i < 40; i++) w.update(SIM_CFG.dt);
  check('I: the consumed pip never re-offers', !w.treePopupRequested);
}

// ------------------------------- J. THE GRAFT LANE ------------------------
{
  const inst3 = seat.meta.knownSkills.get('wild_strike')!;
  const neutral = treeNodeOf(WS, NEUTRAL)!;
  const savedGraft = neutral.graft;
  const anySupport = Object.keys(SUPPORTS)[0];
  neutral.graft = { support: anySupport, level: 2 };
  try {
    inst3.level = 20;
    inst3.treeNodes = ['ws_duelist', NEUTRAL];
    w.recalcSeat(seat);
    check('J: a spent node\'s graft injects at recalcSeat (socket-free, derived)',
      inst3.grafts?.some(g => g.def.id === anySupport && g.level === 2) === true,
      `grafts: ${inst3.grafts?.map(g => g.def.id).join(',') ?? 'none'}`);
    inst3.treeNodes = ['ws_duelist'];
    w.recalcSeat(seat);
    check('J: the graft unmakes with the spend (derived, never saved)',
      !inst3.grafts?.some(g => g.def.id === anySupport));
    neutral.graft = { support: 'no_such_support_xyz', level: 1 };
    inst3.treeNodes = ['ws_duelist', NEUTRAL];
    w.recalcSeat(seat);
    check('J: an unknown support grants SILENCE (the warn-degrade idiom)',
      !inst3.grafts?.length || !inst3.grafts.some(g => g.def.id === 'no_such_support_xyz'));
  } finally {
    neutral.graft = savedGraft;
    inst3.treeNodes = undefined;
    w.recalcSeat(seat);
  }
}

// ------------------------------- K. THE CO-OP WIRE ------------------------
{
  const inst4 = seat.meta.knownSkills.get('wild_strike')!;
  inst4.level = 20;
  inst4.treeNodes = [...DUELIST, NEUTRAL];
  const wire = serializeSeatMeta(seat);
  check('K: the wire ships tn on the picked row alone (the sparse idiom)',
    JSON.stringify(wire.known.wild_strike?.tn) === JSON.stringify([...DUELIST, NEUTRAL])
    && Object.entries(wire.known).every(([id, row]) => id === 'wild_strike' || row.tn === undefined));
  applySeatMeta(w, seat, wire);
  const applied = seat.meta.knownSkills.get('wild_strike');
  check('K: the client rebuild carries the spends through the one seam',
    JSON.stringify(applied?.treeNodes) === JSON.stringify([...DUELIST, NEUTRAL]));
  const hostileWire = { ...wire, known: { ...wire.known } };
  hostileWire.known.wild_strike = {
    ...wire.known.wild_strike!,
    tn: ['ws_duelist', 'ws_sprinkler', 'no_such_node'],
  };
  const kept = countNotes(() => { applySeatMeta(w, seat, hostileWire); return seat.meta.knownSkills.get('wild_strike'); });
  check('K: hostile tn sanitizes (rival + orphan drop; the panels can never render what the host refuses)',
    JSON.stringify(kept?.treeNodes) === JSON.stringify(['ws_duelist']) && noted === 2);
}

// ------------------------- L. THE CENSUS BRANCH AXIS ----------------------
{
  const census = compatCensus('wild_strike', 'brutality');
  const hosts = new Set(census.rows.map(r => r.skillId));
  check('L: the census enumerates the bare host AND both branch terminals',
    hosts.has('wild_strike') && hosts.has('wild_strike@ws_sprinkler') && hosts.has('wild_strike@ws_duelist'),
    [...hosts].join(', '));
  check('L: exactly two extra hosts per moded skill (the exact-cover determinism)',
    hosts.size === 3);
  check('L: graph census spends the four-point budget in deterministic breadth-first order',
    JSON.stringify(hostTreeNodes('wild_strike@ws_duelist')) === JSON.stringify(['ws_duelist', 'ws_firm_wrist', 'ws_certain_point', 'ws_long_point'])
    && JSON.stringify(hostTreeNodes('wild_strike@ws_sprinkler')) === JSON.stringify(['ws_sprinkler', 'ws_cloudburst', 'ws_long_rain', 'ws_monsoon'])
    && hostTreeNodes('wild_strike') === undefined);
  check('L: parseHostId round-trips the convention',
    JSON.stringify(parseHostId(hostIdOf('wild_strike', 'duelist'))) === JSON.stringify({ skillId: 'wild_strike', branchId: 'duelist' })
    && JSON.stringify(parseHostId('wild_strike')) === JSON.stringify({ skillId: 'wild_strike' }));
  check('L: terminal hosts pass the fit gate like their base (no census hole)',
    census.rows.filter(r => r.skillId.includes('@')).every(r => r.fit !== undefined));

  // THE REGISTRY GUARD (the 2026-08-20 gather-slice bite): a reconcile's
  // idsGone check must read the ledger universe through ledgerSkillIds —
  // raw SKILLS keys would delete every `skill@branch` row as a dead id.
  const ids = ledgerSkillIds();
  check('L: ledgerSkillIds carries the branch hosts beside the registry',
    ids.has('wild_strike') && ids.has('wild_strike@ws_sprinkler') && ids.has('wild_strike@ws_duelist')
    && !ids.has('wild_strike@no_such_branch'));
  const guardLedger = emptyLedger();
  guardLedger.pairs.push(
    { skill: 'wild_strike@ws_sprinkler', support: 'brutality', kind: 'inert', status: 'open', since: '2026-08-20' },
    { skill: 'retired_skill_xyz', support: 'brutality', kind: 'inert', status: 'open', since: '2026-08-20' },
  );
  const rec = reconcileLedger(guardLedger, { probed: [], census }, '2026-08-20',
    { skills: ids, supports: new Set(Object.keys(SUPPORTS)) });
  check('L: a reconcile KEEPS the branch row and retires only the truly-dead id',
    rec.ledger.pairs.some(r => r.skill === 'wild_strike@ws_sprinkler')
    && !rec.ledger.pairs.some(r => r.skill === 'retired_skill_xyz')
    && rec.removed.length === 1);

  // THE ALLOCATED HOST'S GRAFTS (2026-10-01): pinHostTree pins a terminal
  // allocation AND derives the grafts its spent nodes inject. Every authored
  // grafting host, learned onto the seat with the same spends: recalcSeat
  // must derive the same grafts, and the census's verdict on every support
  // must equal the live socket gate's. Pinning the nodes alone read
  // Despair's curse-field branches and Unbound Wheel's duration gems
  // refused while the game admitted them.
  const known = seat.meta.knownSkills;
  const graftSig = (i: { grafts?: { def: { id: string }; level: number }[] }): string =>
    (i.grafts ?? []).map(g => `${g.def.id}@${g.level}`).join(',');
  let graftHosts = 0, graftDrift = '', fitDrift = '';
  for (const def of Object.values(SKILLS)) {
    for (const limb of treeLimbs(def)) {
      const host = hostIdOf(def.id, limb.id);
      const nodes = hostTreeNodes(host);
      if (!nodes?.some(n => treeNodeOf(def, n)?.graft)) continue;
      graftHosts++;
      const pinned = pinHostTree(makeSkillInstance(def, 1, 3), nodes);
      const live = makeSkillInstance(def, 1, 3);
      live.treeNodes = [...nodes];
      const prev = known.get(def.id);
      known.set(def.id, live);
      try {
        w.recalcSeat(seat);
        if (graftSig(pinned) !== graftSig(live)) {
          graftDrift += ` ${host}(${graftSig(pinned) || 'none'} vs ${graftSig(live) || 'none'})`;
        }
        for (const row of compatCensus(def.id).rows) {
          if (row.skillId !== host) continue;
          const admits = supportFitsInstOrCrew(SUPPORTS[row.supportId], live, w.summonCrewSkills(live));
          if ((row.fit !== 'refused') !== admits) fitDrift += ` ${host}+${row.supportId}`;
        }
      } finally {
        if (prev) known.set(def.id, prev); else known.delete(def.id);
      }
    }
  }
  w.recalcSeat(seat);
  check('L: pinHostTree derives the node grafts recalcSeat derives, on every grafting host',
    graftHosts > 0 && graftDrift === '', graftDrift || `${graftHosts} grafting host(s)`);
  check('L: every grafting host\'s census row agrees with the live socket gate',
    graftHosts > 0 && fitDrift === '', fitDrift.slice(0, 400) || `${graftHosts} host(s) × ${Object.keys(SUPPORTS).length} support(s)`);
}

// --------------------------- M. THE GATHER'S STRIDE -----------------------
// (ruled 2026-08-20, the quirk the M1 audit surfaced): a Gathered Casting
// conversion's synthesized ChannelSpec binds MOVEMENT exactly as it binds
// the pulse clock — `cs.gather ?? instanceChannel(...)` at movementLocked
// and moveActor. A gathering caster walks its authored 'slowed' 0.5 (the
// channel bargain the conversion trades the bar's rooting for), never
// free and never rooted. The pin rides this rig's stride machinery
// because the audit that surfaced the dead fields lives here; the law is
// the support fabric's.
{
  function gatherStride(heldSlot: boolean, seed: number): { pxPerSec: number; castingTicks: number; ticks: number } {
    const restore = seedGlobalRandom(seed);
    try {
      const ww = makeSimWorld('magician', seed);
      const b = starterBuild('magician', 20);
      b.bar = ['firebolt'];
      b.skills = b.skills.map(s => s.id === 'firebolt'
        ? { ...s, supports: [{ id: 'gathered_casting', level: 1 }] } : s);
      applyBuild(ww, b, 0x9ea7);
      const st = ww.localSeat;
      const p = ww.player;
      const slot = p.skills.findIndex(s => s?.def.id === 'firebolt');
      const dt = SIM_CFG.dt;
      const held = new Array(8).fill(false); held[slot] = heldSlot;
      const edge = new Array(8).fill(false);
      const seconds = 8;
      let px = 0, castingTicks = 0, ticks = 0;
      for (let tick = 0; tick < Math.round(seconds / dt); tick++) {
        const t = tick * dt;
        const prevX = p.pos.x;
        const dir = Math.floor(t / 2) % 2 === 0 ? 1 : -1; // the arena-wall ping-pong
        const intent: PlayerInput = { dx: dir, dy: 0, aim: vec(p.pos.x + 200, p.pos.y), held, edge };
        const inputs = new Map<string, PlayerInput>();
        inputs.set(st.id, intent);
        ww.applyInputs(inputs, dt);
        for (const a of ww.actors) updateAI(a, ww, dt);
        ww.update(dt);
        px += Math.abs(p.pos.x - prevX);
        ticks++;
        if (p.casting?.mode === 'channel') castingTicks++;
      }
      return { pxPerSec: px / seconds, castingTicks, ticks };
    } finally {
      restore();
    }
  }
  const free = gatherStride(false, 0x9a7e);
  const held = gatherStride(true, 0x9a7e);
  check('M: the gather actually stands through the window (the rig is live)',
    held.castingTicks > held.ticks * 0.6 && free.castingTicks === 0,
    `held ${held.castingTicks}/${held.ticks} channel ticks`);
  const ratio = free.pxPerSec > 1 ? held.pxPerSec / free.pxPerSec : 0;
  check('M: THE GATHER\'S STRIDE — the synthesized spec binds the walk (slowed ≈ 0.5×, never free, never rooted)',
    ratio > 0.3 && ratio < 0.7,
    `held ${held.pxPerSec.toFixed(1)} px/s vs free ${free.pxPerSec.toFixed(1)} px/s = ${ratio.toFixed(2)}×`);
}

// ------------------------- N. THE GRAPH GRAMMAR (2026-09-04) --------------
// engine/skilltree.ts — THE ONE RESOLVER behind every tree read: the sugar
// fold (the settled 2×3+1 shape → rung chains, rung-1 forks, a lock-free
// neutral, limbs = the authored branch objects) keeps the M1 words and
// verdicts byte-identical; the GRAPH FORM (links any-of / excludes
// symmetric / ranks / pins) is pinned on a probe-local fixture — a fork
// with a sub-fork, a cross-link, a ranked utility — through the spend
// predicate, the loader seam, the mods fold, the derived layout, and the
// census's terminal walk.
{
  // N1. THE SUGAR FOLD — every authored wearer.
  let foldBad = '';
  let wearers = 0;
  for (const def of Object.values(SKILLS)) {
    const t = def.tree;
    if (!t?.branches) continue;
    wearers++;
    const g = treeGraph(def)!;
    const forks = t.branches.map(b => b.rungs[0].id);
    const expectRoots = [...forks, ...(t.neutral ? [t.neutral.id] : [])];
    if (JSON.stringify(g.rootChildren) !== JSON.stringify(expectRoots)) foldBad += ` ${def.id}:roots`;
    for (const b of t.branches) {
      b.rungs.forEach((n, k) => {
        const gn = g.nodes.get(n.id);
        if (!gn) { foldBad += ` ${def.id}/${n.id}:missing`; return; }
        if (gn.node !== n) foldBad += ` ${def.id}/${n.id}:identity`;
        const wantLinks = k === 0 ? [] : [b.rungs[k - 1].id];
        if (JSON.stringify(gn.links) !== JSON.stringify(wantLinks)) foldBad += ` ${def.id}/${n.id}:links`;
        const wantEx = k === 0 ? forks.filter(f => f !== n.id) : [];
        if (JSON.stringify([...gn.excludes].sort()) !== JSON.stringify([...wantEx].sort())) foldBad += ` ${def.id}/${n.id}:excludes`;
        if (gn.limbId !== b.id) foldBad += ` ${def.id}/${n.id}:limb`;
        if (gn.depth !== k + 1) foldBad += ` ${def.id}/${n.id}:depth`;
      });
    }
    if (t.neutral) {
      const gn = g.nodes.get(t.neutral.id);
      if (!gn || gn.links.length || gn.excludes.size || gn.limbId !== undefined) foldBad += ` ${def.id}/neutral:free`;
    }
    if (g.limbs.length !== t.branches.length || g.limbs.some((l, i) => l !== t.branches![i])) foldBad += ` ${def.id}:limbs-identity`;
    if (treeLimbs(def) !== g.limbs) foldBad += ` ${def.id}:limbs-memo`;
    if (g.dupes.length || g.order.length !== g.nodes.size) foldBad += ` ${def.id}:reach`;
    if (g.box.w < TREE_LAYOUT_CFG.minBox.w || g.box.h < TREE_LAYOUT_CFG.minBox.h) foldBad += ` ${def.id}:box`;
  }
  check('N: THE SUGAR FOLD — every 2×3+1 wearer folds to rung chains, rung-1 forks, a lock-free neutral, limbs = the authored branches',
    foldBad === '' && wearers >= 1, foldBad || `${wearers} wearer(s)`);
  check('N: the fold is memoized per spec (one graph object per def)', treeGraph(WS) === treeGraph(WS));

  // N2. THE M1 WORDS through the derived lock (bare instances — no world).
  const fresh = (nodes: string[] = [], level = 20) => {
    const i = makeSkillInstance(WS, level, 3);
    if (nodes.length) i.treeNodes = nodes;
    return i;
  };
  check('N: prerequisite words walk back to the ROOT-MOST unspent rung',
    treeNodeRefusal(fresh(), 'ws_long_point') === 'The Duelist comes first'
    && treeNodeRefusal(fresh(['ws_duelist']), 'ws_long_point') === 'The Firm Wrist comes first'
    && treeNodeRefusal(fresh(['ws_duelist']), 'ws_firm_wrist') === null);
  check('N: the lock names the sealed LIMB at every rung under it',
    SPRINKLER.every(id => treeNodeRefusal(fresh(['ws_duelist']), id) === "The Sprinkler's path is sealed")
    && DUELIST.every(id => treeNodeRefusal(fresh(['ws_sprinkler']), id) === "The Duelist's path is sealed"));
  check('N: the neutral stays lock-free beside a committed limb; treeSealedSet = the rival limb, nothing else',
    treeNodeRefusal(fresh(['ws_duelist']), NEUTRAL) === null
    && JSON.stringify([...treeSealedSet(WS, ['ws_duelist'])].sort()) === JSON.stringify(treeLimbs(WS).find(b => b.id === 'ws_sprinkler')!.rungs.map(n => n.id).sort())
    && treeSealedSet(WS, []).size === 0 && treeSealedSet(WS, [NEUTRAL]).size === 0);
  check('N: the refusal order holds — seal before budget, budget words unchanged',
    treeNodeRefusal(fresh([...DUELIST, NEUTRAL]), 'ws_sprinkler') === "The Sprinkler's path is sealed"
    && treeNodeRefusal(fresh([...DUELIST], 15), NEUTRAL) === 'no Ability point free — the next comes at level 20'
    && treeNodeRefusal(fresh([...DUELIST, NEUTRAL]), 'ws_economy') === 'every Ability point is spent');
  const dup = countNotes(() => validTreeNodes(WS, ['ws_duelist', 'ws_duelist'], 20));
  check('N: a repeat on a single-rank node drops as a duplicate through the seam',
    JSON.stringify(dup) === JSON.stringify(['ws_duelist']) && noted === 1);

  // N3. THE GRAPH FORM — the fixture: A/B fork limbs, A1/A2 a sub-fork under
  // A, A3 cross-linked to both, U a lock-free two-rank utility.
  const FIX: SkillDef = {
    ...WS, id: 'probe_graph_fixture', name: 'Probe Fixture',
    tree: {
      level: 5,
      nodes: [
        { id: 'A', name: 'Alpha', excludes: ['B'], over: { arcDeg: 30, spreadDeg: 130 } },
        { id: 'B', name: 'Beta', over: { arcDeg: 16, spreadDeg: 24 } },
        { id: 'U', name: 'Utility', ranks: 2, mods: [{ stat: 'channelMobility', kind: 'flat', value: 0.05 }] },
        { id: 'A1', name: 'Alpha One', links: ['A'], excludes: ['A2'], mods: [{ stat: 'attackSpeed', kind: 'increased', value: 0.1 }] },
        { id: 'A2', name: 'Alpha Two', links: ['A'] },
        { id: 'A3', name: 'Alpha Cap', links: ['A1', 'A2'], kind: 'keystone' },
        { id: 'B1', name: 'Beta One', links: ['B'] },
        { id: 'B2', name: 'Beta Two', links: ['B1'] },
      ],
    },
  };
  const g = treeGraph(FIX)!;
  check('N: graph form — root children in authored order; A/B fork limbs, U lock-free; limbs inherit down',
    JSON.stringify(g.rootChildren) === JSON.stringify(['A', 'B', 'U'])
    && JSON.stringify(g.limbs.map(l => l.id)) === JSON.stringify(['A', 'B'])
    && g.nodes.get('U')!.limbId === undefined && g.nodes.get('A3')!.limbId === 'A' && g.nodes.get('B2')!.limbId === 'B'
    && treeLimbOfNode(FIX, 'A3')?.name === 'Alpha' && treeLimbOfNode(FIX, 'U') === undefined);
  check('N: exclusion is symmetric by construction (B excludes A though only A named it; A2 excludes A1)',
    g.nodes.get('B')!.excludes.has('A') && g.nodes.get('A2')!.excludes.has('A1'));
  check('N: limb views synthesize from the fork root (BFS rungs; fork roots draw major, the cap keystone)',
    g.limbs[0].name === 'Alpha'
    && JSON.stringify(g.limbs[0].rungs.map(n => n.id)) === JSON.stringify(['A', 'A1', 'A2', 'A3'])
    && g.nodes.get('A')!.kind === 'major' && g.nodes.get('A3')!.kind === 'keystone' && g.nodes.get('U')!.kind === 'minor');
  const fx = (nodes: string[] = [], level = 20) => {
    const i = makeSkillInstance(FIX, level, 3);
    if (nodes.length) i.treeNodes = nodes;
    return i;
  };
  check('N: a deep node walks its prerequisite chain back to the root-most gap',
    treeNodeRefusal(fx(), 'A3') === 'Alpha comes first' && treeNodeRefusal(fx(['A']), 'A3') === 'Alpha One comes first');
  check('N: spending a fork seals the rival limb TRANSITIVELY, in the limb\'s name',
    treeNodeRefusal(fx(['A']), 'B') === "Beta's path is sealed"
    && treeNodeRefusal(fx(['A']), 'B2') === "Beta's path is sealed"
    && treeSealedSet(FIX, ['A']).size === 3);
  check('N: a sub-fork seals by its OWN name — the limb stays open above it',
    treeNodeRefusal(fx(['A', 'A1']), 'A2') === "Alpha Two's path is sealed"
    && treeNodeRefusal(fx(['A', 'A1']), 'A3') === null
    && treeSpentBranch(fx(['U'])) === undefined && treeSpentBranch(fx(['U', 'A']))?.id === 'A');
  check('N: a cross-linked node opens through EITHER prerequisite',
    treeNodeRefusal(fx(['A', 'A2']), 'A3') === null && treeNodeRefusal(fx(['A', 'A1']), 'A3') === null);
  check('N: ranks — a ranked node takes its points one by one',
    treeNodeRefusal(fx(['U']), 'U') === null && treeSpentCount(['U', 'U'], 'U') === 2
    && treeNodeRanks(FIX, 'U') === 2 && treeNodeRanks(FIX, 'A') === 1 && treeNodeRanks(FIX, 'nope') === 1);
  const overRank = countNotes(() => validTreeNodes(FIX, ['U', 'U', 'U'], 20));
  const overNoted = noted;
  const rivalDeep = countNotes(() => validTreeNodes(FIX, ['A', 'B', 'B1'], 20));
  const rivalNoted = noted;
  const cross = countNotes(() => validTreeNodes(FIX, ['A', 'A2', 'A3', 'U'], 20));
  const crossNoted = noted;
  const subfork = countNotes(() => validTreeNodes(FIX, ['A', 'A1', 'A2'], 20));
  const subNoted = noted;
  check('N: the loader seam — ranks cap repeats, the lock drops rivals transitively, cross-links pass, sub-forks refuse',
    JSON.stringify(overRank) === JSON.stringify(['U', 'U']) && overNoted === 1
    && JSON.stringify(rivalDeep) === JSON.stringify(['A']) && rivalNoted === 2
    && JSON.stringify(cross) === JSON.stringify(['A', 'A2', 'A3', 'U']) && crossNoted === 0
    && JSON.stringify(subfork) === JSON.stringify(['A', 'A1']) && subNoted === 1);
  const quiet = countNotes(() => validTreeNodes(FIX, ['A', 'B'], 20, { quiet: true }));
  check('N: the quiet option mutes the notes (the census walk\'s lane)', JSON.stringify(quiet) === JSON.stringify(['A']) && noted === 0);
  const rankMods = instanceTreeMods(fx(['U', 'U']));
  check('N: a ranked node\'s mods stack per rank through instanceTreeMods',
    rankMods?.length === 2 && rankMods.every(m => m.stat === 'channelMobility' && m.value === 0.05));

  // N4. THE DERIVED LAYOUT — pure, deterministic, pin-overridable.
  const nA = g.nodes.get('A')!, nB = g.nodes.get('B')!, nU = g.nodes.get('U')!;
  const nA1 = g.nodes.get('A1')!, nA2 = g.nodes.get('A2')!, nA3 = g.nodes.get('A3')!;
  const ring = TREE_LAYOUT_CFG.ring;
  check('N: forks fan the upper arc, the lock-free node hangs straight below, sub-forks split, every node on its depth ring',
    nA.y < 0 && nB.y < 0 && nA.x < nB.x && nU.y > 0 && Math.abs(nU.x) < 1
    && Math.abs(nA1.x - nA2.x) > 50
    && Math.abs(Math.hypot(nA.x, nA.y) - ring) < 1 && Math.abs(Math.hypot(nA1.x, nA1.y) - 2 * ring) < 1
    && Math.abs(Math.hypot(nA3.x, nA3.y) - 3 * ring) < 1);
  const FIX2: SkillDef = { ...FIX, tree: JSON.parse(JSON.stringify(FIX.tree)) };
  const g2 = treeGraph(FIX2)!;
  check('N: the layout is deterministic across folds (a structural clone lands every node on the same dot)',
    g2 !== g && g.order.every(id => g2.nodes.get(id)!.x === g.nodes.get(id)!.x && g2.nodes.get(id)!.y === g.nodes.get(id)!.y));
  const pinnedSpec = JSON.parse(JSON.stringify(FIX.tree));
  pinnedSpec.nodes.find((n: { id: string }) => n.id === 'B').x = 300;
  pinnedSpec.nodes.find((n: { id: string }) => n.id === 'B').y = -50;
  const g3 = treeGraph({ ...FIX, tree: pinnedSpec })!;
  check('N: a pin overrides the derived dot and its children fan from the pinned bearing',
    g3.nodes.get('B')!.x === 300 && g3.nodes.get('B')!.y === -50
    && g3.nodes.get('B1')!.x > 200 && g3.nodes.get('A')!.x === nA.x);
  let overlap = '';
  for (const def of [...Object.values(SKILLS).filter(d => d.tree), FIX]) {
    const gg = treeGraph(def)!;
    const arr = gg.order.map(id => gg.nodes.get(id)!);
    for (let i = 0; i < arr.length; i++) {
      for (let j = i + 1; j < arr.length; j++) {
        const minD = TREE_LAYOUT_CFG.radius[arr[i].kind] + TREE_LAYOUT_CFG.radius[arr[j].kind] + 6;
        if (Math.hypot(arr[i].x - arr[j].x, arr[i].y - arr[j].y) < minD) overlap += ` ${def.id}:${arr[i].id}/${arr[j].id}`;
      }
    }
  }
  check('N: no derived-layout collisions across every authored tree + the fixture', overlap === '', overlap);

  // N5. THE CENSUS WALK on a graph limb (the fixture stands in the registry
  // for the read, then leaves) + a ranked round trip through the loader.
  const reg = SKILLS as Record<string, SkillDef>;
  reg[FIX.id] = FIX;
  try {
    check('N: the census walks a graph limb to its terminal through the seam — the sub-fork\'s rival dropped, the lock-free ground filling the budget',
      JSON.stringify(hostTreeNodes(`${FIX.id}@A`)) === JSON.stringify(['A', 'A1', 'A3', 'U'])
      && JSON.stringify(hostTreeNodes(`${FIX.id}@B`)) === JSON.stringify(['B', 'B1', 'B2', 'U'])
      && hostTreeNodes(`${FIX.id}@U`) === undefined);
    const ids = ledgerSkillIds();
    check('N: the ledger universe carries the graph limbs as `skill@limb` hosts',
      ids.has(`${FIX.id}@A`) && ids.has(`${FIX.id}@B`) && !ids.has(`${FIX.id}@U`));
    const ranked = countNotes(() => rebuildSkill({
      skillId: FIX.id, level: 20, rarity: 'common', sockets: [null], treeNodes: ['U', 'U', 'A', 'A1'],
    }));
    check('N: a ranked spend round-trips the loader whole (repeated ids = ranks)',
      JSON.stringify(ranked?.treeNodes) === JSON.stringify(['U', 'U', 'A', 'A1']) && noted === 0);
  } finally {
    delete reg[FIX.id];
  }
  check('N: the fixture leaves the registry (the census forgets it)', !ledgerSkillIds().has(`${FIX.id}@A`));
}

console.log(failed === 0 ? '\nALL PASS' : `\n${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
