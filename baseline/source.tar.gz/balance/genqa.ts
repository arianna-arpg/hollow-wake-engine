// ---------------------------------------------------------------------------
// GENERATION QA — the layout invariant sweep (`npm run genqa`).
//
// Runs generateLayout headlessly over the WHOLE authored matrix — every
// tileset (base + each variant, with its common rows and structure/landmark
// rolls) plus every registered layout generator under a representative def —
// across several seeds, and asserts the invariants the generation systems
// promise. This is the regression net for the stamp/pour/fuse/formation/
// strata grammar: a data row that breaks a promise fails CI-style (exit 2),
// exactly like the balance baseline gate.
//
// Invariants checked per generated layout:
//   registry   validateStamps over every authored layout source (unknown
//              stamps/clusters/landmarks/formations/fields fail the sweep),
//              plus composition defs (at→site refs, when-gate keys) and every
//              tileset/biome composition ROLL naming a registered bundle
//   sanity     no NaN positions/radii, doodad count within ceilings
//   determinism the same seed generates byte-identical doodads twice
//   forbidOn   no solid intersects ground its rule forbids (inverse audit)
//   portals    no movement-blocking scatter left within the portal clears
//              (exemptions mirror the splice EXACTLY: keep-tagged waiver
//              pieces, doors, plan-structure rects — a bare reservation
//              shields nothing from the carve)
//   gateDwell  no registered dimension gate doodad (a live realm-gate dwell
//              wherever it stands — world.ts arms it per load) within
//              dwell-overlap reach of a portal: an overlapped pair leaves
//              the portal un-dwellable (the gate's quicker dwell fires
//              first — the sealed Firmament fan road); floor from transit
//              rows + PORTAL_RADIUS, all data
//   clearway   traveled ways hold their right-of-way: no un-waived blocker
//              body on a live (non-wild) way disc (exemptions mirror
//              sweepClearways EXACTLY), decked soft ground never coexists
//              with the way (fat bodies ford + wade shallow), yielded
//              ground (lava, rents) never underlies it
//   habitat    ground-affine kinds (live kelp/coral) sit near their ground
//              — aquatic arenas ambient, 'habitat'-waived pieces authored;
//              plus a dead-row LINT (warn) for authored rows whose habitat
//              can never be met (kelp with no water poured before it)
//   caveSeeds  the cave_entrance ↔ caveSeeds index zip holds
//   reachable  on walk-grid layouts, every exit shares the entry's component
//   deadface   no surface-pooled tileset with variants carries a base-layout
//              kind absent from every variant + common layout (warn) — the
//              dead-base-face class that silently killed 42 plain faces
//              (deadBaseFaceKinds, shared with probe_deadface's own sweep)
//   doors      placed doors keep walkable floor on BOTH sides (warn)
//   fuse       poured bodies never sit a sliver apart (warn) — contiguity read
//              off RIM OVERLAP, and a seam another poured ground overlay
//              covers is not a seam (the cross-kind read fuseGroundBodies'
//              per-kind weld cannot make); a seam the engine REFUSES is not
//              a seam either — void-like region cells (the hole read) and
//              placed structures' reserved bands (the swept approach), both
//              mirrored from the pour law's own guards
//
// Case groups: every tileset (base + variants, with its rolls), every
// registered layout generator, and every composition FORCED at chance 1.
//
// Usage: npm run genqa [-- --seeds 3 --filter mire --verbose]
// Terrain exploration: --exploration balance/reports/exploration.json
// Optional --route-slack 4 --narrow-clearance 2 (grid cells).
// ---------------------------------------------------------------------------

// Side-effect registries — the same set main.ts and the sim arena load; a
// missing import here would make the sweep test a DIFFERENT game.
import '../src/data/clusters';
import '../src/data/formations';
import '../src/engine/landmarkBuilders';
import '../src/data/landmarks';
import '../src/data/lairs';
import '../src/engine/layoutRecipes';
import '../src/engine/interiorGen';
import '../src/data/massifs';
import '../src/data/puzzles'; // the 'shrine' ring-tenant kind (court tables name it)
import '../src/data/watchposts'; // the 'watch_post' ring-tenant kind (court tables name it)
import '../src/data/occurrences'; // the 'occurrence' ring-tenant kind + the occurrence defs (court tables name them)
import '../src/data/settled';
import '../src/data/garden';
import '../src/data/catacombs';
import '../src/data/merelake';
import '../src/data/cistern';
import '../src/data/lonecrypt';
import '../src/data/grove';
import '../src/data/warfront';
import '../src/data/scald';
import '../src/data/compositions';
import '../src/data/locales';
import '../src/data/authoredMaps'; // THE AUTHORED-MAP FABRIC's shipped maps (+ the 'authored' layout)
import '../src/world/relief'; // registers surface courses and their journey stages

import { Rng } from '../src/core/rng';
import { vec } from '../src/core/math';
import { applyAnnexes, generateZone, randomizeStarterWeb, spacedExitAt, MIN_PORTAL_SEP, PORTAL_RADIUS } from '../src/engine/worldgen';
import { transitRadius } from '../src/data/transit';
import { dimensionDef, dimensionIds } from '../src/world/dimensions';
import {
  generateLayout, validateStamps, validateCompositions, compositionDefs,
  doodadRuleOf, hasDoodadRule, layoutIds, blocksMovement, normalizeDoodadBound, bodyRadiusOf,
  isSidezoneEntranceKind,
  type Doodad, type GeneratedLayout,
} from '../src/engine/levelgen';
import { shapeBoundR } from '../src/engine/shapes';
import { GridWalkField } from '../src/world/gridWalk';
import { regionKind } from '../src/world/regions';
import { TILESETS } from '../src/data/tilesets';
import { STRUCTURES } from '../src/data/structures';
import { ZONES, type StampSpec, type ZoneDef } from '../src/data/zones';
import { MELDS } from '../src/data/melds';
import { blendFieldIds, composeBlendLayout, hasBlendField } from '../src/engine/blend';
import { hollowDef, hollowShapeOf } from '../src/data/hollows';
import { annexKindDef } from '../src/data/annexes';
import { BIOMES, isAquaticBiome } from '../src/world/biomes';
import { CLIMATE_AXES } from '../src/world/climate';
import { interiorRoleDefs } from '../src/engine/interiorGen';
import { deadBaseFaceKinds } from './deadface_check';
import { authoredMapDefs, authoredZoneDef, validateAuthoredMap } from '../src/engine/authoredMaps';
import { ExplorationReport } from './explorationreport';
import { EXPLORATION_CFG } from './layoutmetrics';
import { localePrograms, localeProgram, validateLocaleProgram } from '../src/world/locales';
import { explorationLocalePools } from '../src/world/zoneVariety';
import { landmarkComplexes, landmarkComplex, validateLandmarkComplex } from '../src/world/landmarkComplexes';
import { UNDER_TIER_LANES } from '../src/engine/tiers';
import { hasDistrictBuilder } from '../src/engine/localeGen';
import { mapFeatureKinds } from '../src/world/atlas';
import { validateCourseStages } from '../src/world/courseStages';
import { hasLayout, hasComposition, hasLandmark } from '../src/engine/levelgen';
import { liquidIds } from '../src/engine/genkit';

const args = process.argv.slice(2);
const flag = (name: string): string | undefined => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] : undefined;
};
const SEEDS = Number(flag('seeds') ?? 3);
const FILTER = flag('filter');
const VERBOSE = args.includes('--verbose');
// Optional terrain observations share the exact authored matrix and seeds.
const explorationPath = flag('exploration');
if (args.includes('--exploration') && (!explorationPath || explorationPath.startsWith('--'))) {
  throw new Error('--exploration requires an output JSON path');
}
const explorationDial = (name: string, fallback: number): number => {
  if (!args.includes(`--${name}`)) return fallback;
  const value = Number(flag(name));
  if (!Number.isSafeInteger(value) || value < 0) throw new Error(`--${name} requires a nonnegative integer`);
  return value;
};
const exploration = explorationPath ? new ExplorationReport({
  routeSlackCells: explorationDial('route-slack', EXPLORATION_CFG.routeSlackCells),
  narrowClearanceCells: explorationDial('narrow-clearance', EXPLORATION_CFG.narrowClearanceCells),
}) : undefined;

// Portal-clear constants mirrored from levelgen (not exported on purpose —
// the harness asserts the OBSERVABLE promise, not the internals).
const EXIT_CLEAR_CARVE = 95;

// Registered dimension gate-doodad kinds → their dimension. The load-time
// scan in world.ts arms every standing doodad of these kinds as a live realm
// gate; the gateDwell invariant below keeps them off the portals.
const GATE_DOODAD_DIMS = new Map<string, string>();
for (const dimId of dimensionIds()) {
  const gd = dimensionDef(dimId).entry?.gateDoodad;
  if (gd) GATE_DOODAD_DIMS.set(gd, dimId);
}

interface CaseResult {
  name: string;
  seeds: number;
  doodads: number;
  ms: number;
  fails: string[];
  warns: string[];
}

const results: CaseResult[] = [];

function mid(band: [number, number]): number { return Math.round((band[0] + band[1]) / 2); }

function checkLayout(name: string, layout: GeneratedLayout, def: ZoneDef,
  arena: { w: number; h: number }, entry: { x: number; y: number },
  exits: { x: number; y: number }[], fails: string[], warns: string[]): void {
  const doodads = layout.doodads;
  // Sanity: finite geometry, plausible volume.
  for (const d of doodads) {
    if (!Number.isFinite(d.pos.x) || !Number.isFinite(d.pos.y) || !Number.isFinite(d.radius)) {
      fails.push(`${name}: non-finite doodad (${d.kind})`);
      break;
    }
  }
  if (doodads.length > 9000) fails.push(`${name}: doodad explosion (${doodads.length})`);
  // forbidOn inverse: no solid intersecting ground its rule forbids.
  const forbidPairs = new Set<string>();
  for (const s of doodads) {
    const forbid = doodadRuleOf(s.kind).forbidOn;
    if (!forbid) continue;
    for (const g of doodads) {
      if (!forbid.includes(g.kind)) continue;
      if (Math.hypot(s.pos.x - g.pos.x, s.pos.y - g.pos.y) < s.radius + g.radius) {
        forbidPairs.add(`${s.kind}×${g.kind}`);
        break;
      }
    }
  }
  if (forbidPairs.size) fails.push(`${name}: solids on forbidden ground (${[...forbidPairs].join(', ')})`);
  // GROUND REQUIRED inverse (DoodadRule.voidOk): on a grid, no doodad stands
  // with its center over a VOID-LIKE cell (open sky, chasm — !walkable &&
  // !blocks) unless its rule opts out. The outcome-side of the placement
  // gate, exactly like the forbidOn inverse above.
  if (layout.walk instanceof GridWalkField) {
    const floating = new Set<string>();
    for (const d of doodads) {
      if (doodadRuleOf(d.kind).voidOk) continue;
      const rk = regionKind(layout.walk.regionAt(d.pos.x, d.pos.y));
      if (rk && !rk.walkable && !rk.blocks) floating.add(d.kind);
    }
    if (floating.size) fails.push(`${name}: doodad(s) floating over void (${[...floating].join(', ')})`);
  }
  // THE WALL-HONESTY inverse (wayRoller's refusal): a WAY disc — any kind
  // whose rule carries `clearway`, the traveled-way class marker — never
  // sits with its center on a movement-BLOCKING cell: pavement over masonry
  // reads walkable and lies (the metropolis' gravel drew straight through
  // tenement walls before the roller learned to refuse). Registry-derived:
  // new way kinds join this net the moment they declare their clearway.
  if (layout.walk instanceof GridWalkField) {
    const paved = new Set<string>();
    for (const d of doodads) {
      if (!doodadRuleOf(d.kind).clearway) continue;
      const rk = regionKind(layout.walk.regionAt(d.pos.x, d.pos.y));
      if (rk?.blocks) paved.add(`${d.kind}@${rk.id}`);
    }
    if (paved.size) fails.push(`${name}: way paved over wall (${[...paved].join(', ')})`);
  }
  // Portal clears: CONVEX zones only — the splice contract. Grid layouts'
  // promise is reachability (asserted below); their blockers may legally
  // neighbor a portal the flow-field routes around. The exemption set here
  // (keep / door / structure rect) IS the splice's, one-for-one — reserved
  // footprints deliberately absent on BOTH sides, so scatter a later
  // reservation covers is carved like any other (probe_portal_contract.ts
  // pins the alignment).
  if (!layout.walk) {
    const inStructure = (d: Doodad): boolean =>
      (layout.structures ?? []).some(st =>
        d.pos.x > st.rect.x - d.radius && d.pos.x < st.rect.x + st.rect.w + d.radius
        && d.pos.y > st.rect.y - d.radius && d.pos.y < st.rect.y + st.rect.h + d.radius);
    const pts = [entry, ...exits];
    const blockersNearPortals = doodads.filter(d =>
      blocksMovement(d) && !d.keep && d.kind !== 'door' && !inStructure(d)
      && pts.some(p => Math.hypot(p.x - d.pos.x, p.y - d.pos.y) < EXIT_CLEAR_CARVE * 0.9 + d.radius));
    if (blockersNearPortals.length) {
      fails.push(`${name}: ${blockersNearPortals.length} blocker(s) inside a portal clear (${[...new Set(blockersNearPortals.map(d => d.kind))].join(',')})`);
    }
  }
  // DIMENSION GATE DOODADS keep off the portals: a registered gateDoodad is
  // a live realm-gate dwell wherever it stands (world.ts arms it per load),
  // and its stand-on disc overlapping a portal's leaves the portal
  // un-dwellable — the gate's quicker dwell fires first and the road seals
  // (the Firmament's fan is a progression road). The floor is DATA: the
  // gate's own transit radius + the portal's + a body's width. Runs on
  // every layout shape — grid zones route blockers, but a dwell overlap is
  // not a routing problem.
  {
    const pts = [entry, ...exits];
    for (const d of doodads) {
      const dimId = GATE_DOODAD_DIMS.get(d.kind);
      if (dimId === undefined) continue;
      const floor = transitRadius(`realm_gate:dim_${dimId}`, 32) + PORTAL_RADIUS + 24;
      if (pts.some(p => Math.hypot(p.x - d.pos.x, p.y - d.pos.y) < floor)) {
        fails.push(`${name}: dimension gate doodad '${d.kind}' within dwell-overlap reach (${floor}px) of a portal`);
        break;
      }
    }
  }
  // THE CLEARWAY CONTRACT (the coherence fabric): traveled ways hold their
  // right-of-way in the OUTCOME, whoever laid what, in whatever order. The
  // exemption set mirrors sweepClearways EXACTLY (the aligned-contract
  // lesson from the portal splice): keep-tagged pieces, doors, plan-
  // structure rects, 'clearway'-waived pieces, spanning bridges — and
  // OVERGROWN (wild) way discs claim nothing. Deck/yield assert the ground
  // truth: decked soft ground never coexists with a live way disc (a FAT
  // ford body may only lap a rim, and wades shallow), yielded ground (lava,
  // rents) never underlies one. Thresholds sit 1px INSIDE the mechanism's
  // so float edges never flap.
  {
    const ways = doodads.filter(d => doodadRuleOf(d.kind).clearway);
    if (ways.length) {
      const FORD_R = 56, FORD_FRAC = 0.4; // mirrored: COHERENCE_CFG.fordBodyR + the ford threshold
      const inStructureRect = (d: Doodad): boolean =>
        (layout.structures ?? []).some(st =>
          d.pos.x > st.rect.x - d.radius && d.pos.x < st.rect.x + st.rect.w + d.radius
          && d.pos.y > st.rect.y - d.radius && d.pos.y < st.rect.y + st.rect.h + d.radius);
      const standing = new Set<string>();
      for (const s of doodads) {
        if (!blocksMovement(s) || doodadRuleOf(s.kind).clearway) continue;
        if (s.keep || s.kind === 'door' || s.waive?.includes('clearway')) continue;
        if (doodadRuleOf(s.kind).spans || inStructureRect(s)) continue;
        const bodyR = bodyRadiusOf(s);
        if (ways.some(c => !c.wild
          && Math.hypot(s.pos.x - c.pos.x, s.pos.y - c.pos.y) < bodyR + c.radius - 1)) {
          standing.add(s.kind);
        }
      }
      if (standing.size) fails.push(`${name}: blocker(s) standing on a traveled way (${[...standing].join(', ')})`);
      const badDeck = new Set<string>(), badYield = new Set<string>();
      for (const c of ways) {
        const cw = doodadRuleOf(c.kind).clearway!;
        for (const g of doodads) {
          if (g === c) continue;
          const dd = Math.hypot(c.pos.x - g.pos.x, c.pos.y - g.pos.y);
          if (cw.yieldsTo?.includes(g.kind) && dd < c.radius + g.radius - 1) {
            badYield.add(`${c.kind}×${g.kind}`);
          }
          if (cw.decks?.includes(g.kind)) {
            if (g.radius > FORD_R) {
              if (dd < g.radius + c.radius * FORD_FRAC - 1) badDeck.add(`${c.kind}×${g.kind} (unforded body)`);
            } else if (dd < c.radius + g.radius - 1) {
              badDeck.add(`${c.kind}×${g.kind}`);
            }
          }
        }
      }
      if (badDeck.size) fails.push(`${name}: soft ground under a traveled way (${[...badDeck].join(', ')})`);
      if (badYield.size) fails.push(`${name}: traveled way over ground it yields to (${[...badYield].join(', ')})`);
    }
  }
  // THE HABITAT CONTRACT (the coherence fabric): ground-affine kinds sit
  // near their ground in the outcome. Aquatic arenas (def.aquatic, or the
  // underwater recipe whose whole floor is sea by construction) satisfy
  // ambiently; 'habitat'-waived pieces are the authored exception. The
  // slack past the rule's reach covers blob-satellite/cluster stray beyond
  // the siting gate — the invariant catches flora in the DRY MIDDLE of a
  // meadow, never a frond a stride past its pool.
  if (!def.aquatic && def.layoutType !== 'underwater') {
    const HAB_SLACK = 90;
    const stranded = new Set<string>();
    for (const d of doodads) {
      const hab = doodadRuleOf(d.kind).habitat;
      if (!hab || d.waive?.includes('habitat')) continue;
      const reach = (hab.reach ?? 140) + HAB_SLACK; // 140 mirrored: COHERENCE_CFG.habitatReach
      const ok = doodads.some(g => hab.near.includes(g.kind)
        && Math.hypot(d.pos.x - g.pos.x, d.pos.y - g.pos.y) - g.radius <= reach);
      if (!ok) stranded.add(d.kind);
    }
    if (stranded.size) fails.push(`${name}: habitat-bearing kind(s) stranded from their ground (${[...stranded].join(', ')})`);
  }
  // caveSeeds zip.
  const mouths = doodads.filter(d => d.kind === 'cave_entrance').length;
  if (mouths !== layout.caveSeeds.length) {
    fails.push(`${name}: caveSeeds zip sheared (${mouths} mouths vs ${layout.caveSeeds.length} seeds)`);
  }
  // HOLLOWS (the hollows fabric): every recorded secret must be SEALED — its
  // carve rect entirely non-walkable (identity is the disguise), its seams
  // present and sharing its id (a pocket one, a passage two), and its reveal
  // kind registered. The seam is the only door.
  if (layout.hollows?.length) {
    const wf = layout.walk instanceof GridWalkField ? layout.walk : null;
    if (!wf) fails.push(`${name}: hollows recorded on a convex layout`);
    const ids = new Set<string>();
    for (const h of layout.hollows) {
      if (ids.has(h.id)) fails.push(`${name}: duplicate hollow id '${h.id}'`);
      ids.add(h.id);
      if (!hollowDef(h.kind)) fails.push(`${name}: hollow '${h.id}' names unregistered kind '${h.kind}'`);
      const seams = doodads.filter(d => d.hollow === h.id);
      const wantSeams = hollowShapeOf(h.kind) === 'passage' ? 2 : 1;
      if (seams.length !== wantSeams) {
        fails.push(`${name}: hollow '${h.id}' (${h.kind}) has ${seams.length} seam(s), wants ${wantSeams}`);
      }
      if (wf) {
        let leak = false;
        for (let y = h.rect.y + wf.cell / 2; y < h.rect.y + h.rect.h && !leak; y += wf.cell) {
          for (let x = h.rect.x + wf.cell / 2; x < h.rect.x + h.rect.w && !leak; x += wf.cell) {
            if (wf.isWalkable(x, y)) leak = true;
          }
        }
        if (leak) fails.push(`${name}: hollow '${h.id}' rect holds walkable ground — the secret leaks`);
      }
    }
    // Every seam doodad must point at a recorded hollow (no orphans).
    for (const d of doodads) {
      if (d.hollow && !ids.has(d.hollow)) fails.push(`${name}: seam doodad points at unknown hollow '${d.hollow}'`);
    }
  }
  // ANNEX faces (the growing zone — Secrets Movement II, data/annexes.ts):
  // every spec pairs a def piece with a registered kind; ring-0 faces stand
  // as doodads while CHILDREN are recorded only (a gen doodad in dormant
  // space would draw over the void band); grid chambers stay SEALED at
  // generation (the hollows doctrine's leak check) with their carve
  // recorded; convex specs carry no carve. A def piece without a spec is a
  // WARN (best-effort seating), never a fail.
  {
    const specs = layout.annexes ?? [];
    const seen = new Set<string>();
    const pieceIds = new Set((def.annexes ?? []).map(pc => pc.id));
    const wf = layout.walk instanceof GridWalkField ? layout.walk : null;
    for (const s of specs) {
      if (seen.has(s.piece)) fails.push(`${name}: duplicate annex spec '${s.piece}'`);
      seen.add(s.piece);
      if (!pieceIds.has(s.piece)) fails.push(`${name}: annex spec '${s.piece}' names no def piece`);
      const kd = annexKindDef(s.kind);
      if (!kd) { fails.push(`${name}: annex '${s.piece}' names unregistered kind '${s.kind}'`); continue; }
      const faces = doodads.filter(d => d.annex === s.piece);
      const ring0 = !s.piece.includes('.');
      if (ring0 && faces.length !== 1) {
        fails.push(`${name}: annex '${s.piece}' has ${faces.length} face doodad(s), wants 1`);
      }
      if (!ring0 && faces.length !== 0) {
        fails.push(`${name}: CHILD annex '${s.piece}' planted a generation face — dormant space would draw it over the void`);
      }
      if (ring0 && faces[0] && faces[0].kind !== kd.face) {
        fails.push(`${name}: annex '${s.piece}' face doodad '${faces[0].kind}' ≠ its kind's face '${kd.face}'`);
      }
      if (wf) {
        if (!s.carve?.length) fails.push(`${name}: grid annex '${s.piece}' recorded no carve`);
        let leak = false;
        for (let y = s.rect.y + wf.cell / 2; y < s.rect.y + s.rect.h && !leak; y += wf.cell) {
          for (let x = s.rect.x + wf.cell / 2; x < s.rect.x + s.rect.w && !leak; x += wf.cell) {
            if (wf.isWalkable(x, y)) leak = true;
          }
        }
        if (leak) fails.push(`${name}: annex '${s.piece}' chamber holds walkable ground — the secret leaks`);
      } else if (s.carve) {
        fails.push(`${name}: convex annex '${s.piece}' carries a carve`);
      }
    }
    for (const pc of def.annexes ?? []) {
      if (!seen.has(pc.id)) warns.push(`${name}: annex piece '${pc.id}' seated no face (sealed forever — best-effort)`);
    }
    for (const d of doodads) {
      if (d.annex && !seen.has(d.annex)) fails.push(`${name}: face doodad points at unknown annex '${d.annex}'`);
    }
  }
  // HIT-SURFACE fabric invariants (engine/shapes.ts):
  //  - every door doodad carries an authored slab rect that stays INSIDE its
  //    cells rect (the slab is the door you see, never wider than the breach);
  //  - any authored/rule surface keeps the broad-phase promise after
  //    normalizeDoodadBound: shapeBoundR(surface) ≤ max(radius, boundR), or
  //    spatial-index queries near a slab corner would miss the doodad.
  for (const d of doodads) {
    normalizeDoodadBound(d);
    if (d.hitbox) {
      const bound = Math.max(d.radius, d.boundR ?? 0);
      if (shapeBoundR(d.hitbox) > bound + 0.01) {
        fails.push(`${name}: ${d.kind} hitbox bound ${shapeBoundR(d.hitbox).toFixed(1)} exceeds broad-phase ${bound.toFixed(1)}`);
        break;
      }
    }
    if (d.kind === 'door') {
      const c = d.door?.cells;
      if (!d.hitbox || d.hitbox.kind !== 'rect') {
        fails.push(`${name}: door ${d.door?.id ?? '?'} lacks its slab rect hitbox`);
        break;
      }
      if (c && (d.hitbox.hw > c.w / 2 + 0.01 || d.hitbox.hh > c.h / 2 + 0.01)) {
        fails.push(`${name}: door ${d.door?.id ?? '?'} slab (${d.hitbox.hw.toFixed(0)}×${d.hitbox.hh.toFixed(0)}) pokes past its cells (${c.w}×${c.h})`);
        break;
      }
    }
  }
  // Grid reachability: the universal invariant, asserted from outside. Both
  // endpoints snap exactly the way ensureReachability's own check snaps (a
  // global nearest-walkable search) — the assertion mirrors the engine's
  // contract, no stronger and no weaker.
  if (layout.walk instanceof GridWalkField && layout.walk.reachable) {
    const en = layout.walk.isWalkable(entry.x, entry.y)
      ? vec(entry.x, entry.y) : layout.walk.snapToWalkable(vec(entry.x, entry.y));
    for (const e of exits) {
      const q = layout.walk.isWalkable(e.x, e.y) ? vec(e.x, e.y) : layout.walk.snapToWalkable(vec(e.x, e.y));
      if (!layout.walk.reachable(en, q)) {
        fails.push(`${name}: exit (${Math.round(e.x)},${Math.round(e.y)}) unreachable from entry`);
      }
    }
    // Door sanity (warn): a placed door should open BETWEEN two walkable
    // sides along its normal — a door with a wall behind it is dead décor.
    // Mirrors the engine's apron contract (levelgen's `apronMarch`): a
    // CONTIGUOUS march out along the normal, either sign, that STOPS at the
    // first blocked sample. Ground beyond a band of masonry is not this
    // door's floor however open it looks — you cannot step onto it. (The
    // march starts at 1.2 cells, safely outside the door's own cell, so the
    // classic "a fixed offset lands on a second wall line" case is answered
    // by the near samples rather than by hopping the wall.)
    for (const st of layout.structures ?? []) {
      for (const pd of st.doors) {
        const grid = layout.walk;
        const open = (sign: number): boolean => {
          for (let k = 1.2; k <= 3.4; k += 0.4) {
            const x = pd.pos.x + pd.normal.x * st.cellSize * k * sign;
            const y = pd.pos.y + pd.normal.y * st.cellSize * k * sign;
            if (!grid.isWalkable(x, y)) break;
            return true;
          }
          return false;
        };
        if (!open(1) || !open(-1)) {
          warns.push(`${name}: door ${pd.door.id} lacks floor on ${!open(1) ? 'its apron' : 'its room'} side`);
        }
      }
    }
  }
  // NO PHANTOM DOORS (warn): a door is TWO things — the doodad the world
  // draws and blocks with, and the PlacedDoor record the structure keeps
  // (door state, Zone Memory, the co-op ZoneMsg, breakable door-actors, the
  // open-doors topology reachability reads). A pass that splices the doodad
  // and keeps the record ships a door the zone believes in and nobody can
  // see — usually standing in whatever masonry killed it. Match by position:
  // the two halves are minted from the same cells rect.
  for (const st of layout.structures ?? []) {
    for (const pd of st.doors) {
      const drawn = doodads.some(d => d.kind === 'door'
        && Math.abs(d.pos.x - pd.pos.x) < 1 && Math.abs(d.pos.y - pd.pos.y) < 1);
      if (!drawn) warns.push(`${name}: door ${pd.door.id} has a record but no doodad (phantom — a splice took the doodad only)`);
    }
  }
  // Fuse promise (warn): poured bodies never sit a sliver apart — the promise
  // fuseGroundBodies makes is that a zone's poured ground reads as CONTINUOUS
  // BODIES, not as circles jammed together with a dry seam between them. Two
  // honesty guards keep the assertion on what the ground actually IS instead of
  // on a per-kind proxy (drawn == tested):
  //
  //  · CONTIGUITY, not weld reach. Bodies union on ANY rim overlap. The
  //    engine's weld unions at `dist < r+r-6` because a pair already deeper
  //    into each other than that has nothing left to weld; that margin is a
  //    WELD heuristic and copying it into a CONNECTIVITY test made the pour's
  //    own gapless-by-design lattice read as a split — paintLiquid thins solid
  //    interiors to a checker, leaving same-axis neighbours 2 cells (60px)
  //    apart at radius 1.05×cell (31.5), i.e. genuinely OVERLAPPING by 3px,
  //    which the 57px threshold refuses to union. A "split" reported at a
  //    NEGATIVE gap is nonsense: overlapping rims are one body, so the union
  //    tests the rims, and every surviving cross-body gap is ≥ 0 by
  //    construction.
  //  · CROSS-KIND BRIDGES. fuseGroundBodies buckets byKind and welds within a
  //    kind only, which is right for the WELD (a cross-kind weld would move
  //    generated geometry, and a bog is not a river). But the promise a player
  //    reads off the ground is ONE CONTINUOUS BODY, and a river or swamp lying
  //    across the seam between two bog bodies keeps that promise — there is no
  //    dry sliver, no guard split and no fuse miss to report. So a gap another
  //    poured ground overlay covers rim-to-rim is not a gap.
  //  · THE HOLE READ. On a grid layout, a seam standing over a VOID-LIKE
  //    region cell (!walkable && !blocks — the engine's own overVoid
  //    definition: a gorge, a cloud void) is a hole in the world, not a dry
  //    sliver: GROUND REQUIRED (cellGuarded) refuses pour cells there by
  //    construction, so the two rims can never join and the player reads an
  //    abyss between banks — the Overpass's drift lips on opposite gorge
  //    rims. Region grain only: poured hole KINDS (a chasm doodad in the
  //    seam) keep their verdict above — a hole never bridges, and a doodad
  //    hole never excuses.
  //  · THE SWEPT APPROACH. A seam crossing a placed structure's RESERVED
  //    band (rect + margin — the exact reservation placeStructurePlan
  //    pushes) is ground the world promised to keep clear: the pour and the
  //    weld both part around it by the reservation contract (inReserved),
  //    and the sliver reads as the building's kept approach — the metropolis
  //    gate façade's dry rim through a riverland pour. Structures only:
  //    formation/cluster/clearing reservations never reach the layout
  //    output, so their guard splits still warn (the ice_teeth arcs — see
  //    the frost_hollow KNOWN-GOOD note in data/compositions.ts).
  //
  // The reported number is the smallest UNBRIDGED cross-body gap, so a bridged
  // pair can never mask a real split elsewhere in the same zone. Both reads
  // above mirror engine REFUSALS — ground the fuse could never legally lay —
  // so a genuine weld regression on open unguarded ground stays loud.
  const FUSE_SLIVER = 25;  // gap (px) under which two bodies read as jammed, not fused
  const FUSE_SAMPLES = 4;  // rim→rim steps a bridge must cover (both ends + 3 inside)
  // The bridge set, gathered once: every poured GROUND overlay in the zone.
  // 'ground' is the overlap class that merges freely and gates nothing (mud,
  // water, lava) — which is exactly what "no dry sliver here" means. Inert
  // poured kinds are excluded by the same read: a chasm or a magma_core wall
  // in the seam is a HOLE between the bodies, never a bridge across them.
  // ONE judgment call sits in that predicate: a HAZARD overlay bridges too
  // (lava carries no forbidOn, so lava-between-bogs is geometrically legal
  // and covers the seam — no guard split, no fuse miss, nothing dry to see).
  // The authored matrix pours no such pair today; narrowing the read to
  // non-hazard ground is a `&& !rule.hazardGround` away if one ever reads
  // wrong on screen.
  const pouredGround = doodads.filter(d => {
    const rule = doodadRuleOf(d.kind);
    return !!rule.pour && rule.overlap === 'ground';
  });
  const pouredKinds = [...new Set(doodads.filter(d => doodadRuleOf(d.kind).pour
    && (doodadRuleOf(d.kind).pour!.fuseGap ?? 1) > 0).map(d => d.kind))];
  for (const kind of pouredKinds) {
    const discs = doodads.filter(d => d.kind === kind);
    if (discs.length < 2 || discs.length > 1200) continue;
    const parent = discs.map((_, i) => i);
    const find = (i: number): number => parent[i] === i ? i : (parent[i] = find(parent[i]));
    for (let i = 0; i < discs.length; i++) {
      for (let j = i + 1; j < discs.length; j++) {
        if (Math.hypot(discs[i].pos.x - discs[j].pos.x, discs[i].pos.y - discs[j].pos.y)
          < discs[i].radius + discs[j].radius) {
          const ri = find(i), rj = find(j);
          if (ri !== rj) parent[ri] = rj;
        }
      }
    }
    // A same-kind disc in the seam would already have unioned the pair, so the
    // bridge set is every OTHER kind's poured ground.
    const bridges = pouredGround.filter(d => d.kind !== kind);
    /** Does other-kind poured ground cover the whole rim→rim segment? Sampled
     *  rather than solved: the gap is sub-cell (FUSE_SLIVER < GEN_CELL) and
     *  bridge discs are ≥ 1.05 cells across, so a few samples answer at the
     *  lattice's own grain. Coverage is a UNION over the bridge set — a chain
     *  of touching discs bridges as honestly as one fat one. */
    const bridgedAcross = (a: Doodad, b: Doodad, len: number, gap: number): boolean => {
      if (!bridges.length) return false;
      const ux = (b.pos.x - a.pos.x) / len, uy = (b.pos.y - a.pos.y) / len;
      for (let s = 0; s <= FUSE_SAMPLES; s++) {
        const t = a.radius + gap * (s / FUSE_SAMPLES);
        const px = a.pos.x + ux * t, py = a.pos.y + uy * t;
        if (!bridges.some(o => Math.hypot(px - o.pos.x, py - o.pos.y) < o.radius)) return false;
      }
      return true;
    };
    /** THE HOLE READ + THE SWEPT APPROACH (see the seam laws above): does an
     *  engine refusal own this seam? ANY sample suffices — one refused lattice
     *  cell still leaves the weld's neighbours rim-overlapping (27px step vs
     *  63px reach), so a pair that stayed split was severed by a refusal band
     *  ≥ 2 cells wide, which these samples cannot miss at sub-sliver grain. */
    const reservedBands = (layout.structures ?? []).map(st => {
      const margin = STRUCTURES[st.defId]?.margin ?? st.cellSize * 1.5;
      return {
        x0: st.rect.x - margin, y0: st.rect.y - margin,
        x1: st.rect.x + st.rect.w + margin, y1: st.rect.y + st.rect.h + margin,
      };
    });
    const seamRefused = (a: Doodad, b: Doodad, len: number, gap: number): boolean => {
      const ux = (b.pos.x - a.pos.x) / len, uy = (b.pos.y - a.pos.y) / len;
      for (let s = 0; s <= FUSE_SAMPLES; s++) {
        const t = a.radius + gap * (s / FUSE_SAMPLES);
        const px = a.pos.x + ux * t, py = a.pos.y + uy * t;
        if (layout.walk instanceof GridWalkField) {
          const rk = regionKind(layout.walk.regionAt(px, py));
          if (rk && !rk.walkable && !rk.blocks) return true; // a hole, not a seam
        }
        if (reservedBands.some(r => px >= r.x0 && px <= r.x1 && py >= r.y0 && py <= r.y1)) return true;
      }
      return false;
    };
    let minGap = Infinity;
    let seamWitness: [Doodad, Doodad] | undefined;
    for (let i = 0; i < discs.length; i++) {
      for (let j = i + 1; j < discs.length; j++) {
        if (find(i) === find(j)) continue;
        const a = discs[i], b = discs[j];
        const len = Math.hypot(a.pos.x - b.pos.x, a.pos.y - b.pos.y);
        const gap = len - a.radius - b.radius;
        // Only a pair that would LOWER the reported floor needs the bridge
        // test — pairs at or above the sliver threshold can never warn.
        if (gap >= FUSE_SLIVER || gap >= minGap) continue;
        if (bridgedAcross(a, b, len, gap)) continue;
        if (seamRefused(a, b, len, gap)) continue;
        minGap = gap;
        seamWitness = [a, b];
      }
    }
    if (minGap < FUSE_SLIVER) warns.push(`${name}: ${kind} bodies ${minGap.toFixed(0)}px apart (guard split or fuse miss)`);
    if (VERBOSE && seamWitness) {
      const [a, b] = seamWitness;
      const len = Math.hypot(b.pos.x - a.pos.x, b.pos.y - a.pos.y);
      const t = (a.radius + minGap / 2) / len;
      const at = { x: a.pos.x + (b.pos.x - a.pos.x) * t, y: a.pos.y + (b.pos.y - a.pos.y) * t };
      // An observation only: nearby guards help explain the witness but do
      // not excuse it or weaken the contiguity warning.
      console.log('seam witness ' + JSON.stringify({ name, kind, gap: minGap, at,
        bodies: seamWitness.map(d => ({ at: d.pos, radius: d.radius })),
        portalDistance: Math.min(...[entry, ...exits].map(p => Math.hypot(at.x - p.x, at.y - p.y))),
        nearby: doodads.filter(d => d.kind !== kind && Math.hypot(at.x - d.pos.x, at.y - d.pos.y) < d.radius + 90)
          .filter(d => { const r = doodadRuleOf(d.kind); return r.blocksMove || r.clearway || r.forbidOn?.includes(kind); })
          .map(d => ({ kind: d.kind, at: d.pos, radius: d.radius })),
      }));
    }
  }
}

function runCase(name: string, def: ZoneDef): void {
  if (FILTER && !name.includes(FILTER)) return;
  const fails: string[] = [];
  const warns: string[] = [];
  const arena = { w: def.size.w, h: def.size.h };
  const entry = vec(120, arena.h / 2);
  const exits = [vec(arena.w - 120, arena.h / 2), vec(arena.w / 2, 120)];
  let count = 0;
  const placedKinds = new Set<string>();
  // THE PROMISED DOOR (the door guarantee — engine/levelgen.ts
  // doorGuaranteeSeat): a layout row whose kind is a registered SIDEZONE
  // ENTRANCE and whose count FLOOR is ≥1 promises a load-bearing way (the
  // rooted web's ladder rides these doors) — the guarantee lane must
  // deliver the floor on EVERY seed, so a shortfall is a FAIL, never a
  // warn. Min-0 rows promise nothing statically (their rolled-but-starved
  // case is the guarantee's runtime business).
  const doorMins = new Map<string, number>();
  for (const row of def.layout) {
    if ((row.count?.[0] ?? 0) >= 1 && isSidezoneEntranceKind(row.kind)) {
      doorMins.set(row.kind, (doorMins.get(row.kind) ?? 0) + row.count[0]);
    }
  }
  const t0 = performance.now();
  for (let s = 0; s < SEEDS; s++) {
    const seed = 1000003 * (s + 1) + 17;
    const d = { ...def, seed };
    try {
      const layout = generateLayout(d, arena, new Rng(seed), entry, exits);
      const layout2 = generateLayout(d, arena, new Rng(seed), entry, exits);
      if (JSON.stringify(layout.doodads) !== JSON.stringify(layout2.doodads)) {
        fails.push(`${name} seed ${seed}: NON-DETERMINISTIC`);
      }
      count = layout.doodads.length;
      for (const dd of layout.doodads) placedKinds.add(dd.kind);
      for (const [k, min] of doorMins) {
        const got = layout.doodads.filter(dd => dd.kind === k).length;
        if (got < min) fails.push(`${name} seed ${seed}: promised door '${k}' ×${min}, placed ${got}`);
      }
      checkLayout(`${name} seed ${seed}`, layout, d, arena, entry, exits, fails, warns);
      exploration?.record(name, d, entry, exits, layout);
    } catch (e) {
      fails.push(`${name} seed ${seed}: THREW ${(e as Error).message}`);
      exploration?.failed(name, d, e);
    }
  }
  // DEAD-ROW LINT (warn): an authored row naming a habitat-bearing kind that
  // never placed across every seed — kelp authored with no water poured
  // before it starves silently at the siting gate; the coherent fix is the
  // ground-before convention (pour first), a `where: shore` band, or an
  // explicit rules.ignore ['habitat'] waiver on a deliberately dry garden.
  if (!def.aquatic && def.layoutType !== 'underwater') {
    for (const row of def.layout) {
      const hab = doodadRuleOf(row.kind).habitat;
      if (!hab || row.count[1] <= 0 || placedKinds.has(row.kind)) continue;
      if (row.rules?.ignore?.includes('habitat')) continue;
      warns.push(`${name}: row '${row.kind}' never placed (habitat unmet — pour its ground first, band it, or waive)`);
    }
  }
  results.push({ name, seeds: SEEDS, doodads: count, ms: (performance.now() - t0) / SEEDS, fails, warns });
}

// --- 1. Registry validation over every authored layout source --------------
const layoutSources = [
  ...Object.values(ZONES).map(z => ({ source: `zone ${z.id}`, specs: z.layout })),
  ...Object.values(TILESETS).flatMap(t => [
    { source: `tileset ${t.id}`, specs: t.layout },
    { source: `tileset ${t.id} common`, specs: (t.common ?? []) as StampSpec[] },
    ...(t.variants ?? []).map((v, i) => ({ source: `tileset ${t.id} variant ${v.name ?? i}`, specs: v.layout })),
  ]),
  // Composition entries speak the same StampSpec vocabulary (plus `at`).
  ...compositionDefs().flatMap(c => [
    { source: `composition ${c.id} pre`, specs: (c.pre ?? []) as StampSpec[], allowAt: true },
    { source: `composition ${c.id} post`, specs: (c.post ?? []) as StampSpec[], allowAt: true },
  ]),
  // Interior room-role furnishings are stamped inside dungeon rooms.
  ...interiorRoleDefs().map(r => ({ source: `interiorRole ${r.id}`, specs: (r.furnish ?? []) as StampSpec[] })),
  // Biome-meld rows are ordinary stamp rows the edge-band builder emits —
  // an unregistered kind here would silently skip at generation time.
  ...Object.values(MELDS).map(m => ({ source: `meld ${m.id}`, specs: m.rows as StampSpec[] })),
];
const registryErrors = [
  ...landmarkComplexes().flatMap(c => validateLandmarkComplex(c).map(e => `complex ${c.id}: ${e}`)),
  ...localePrograms().flatMap(p => p.variants.filter(v => v.underTier && !UNDER_TIER_LANES[v.underTier]).map(v => `locale ${p.id}/${v.id}: unknown under-tier lane`)),
  ...mapFeatureKinds().filter(f => f.destination?.complex && (!landmarkComplex(f.destination.complex)
    || landmarkComplex(f.destination.complex).stages.find(s => s.id === landmarkComplex(f.destination!.complex!).entrance)?.locale !== f.destination.locale))
    .map(f => `atlas complex ${f.id}: invalid entrance`),
  ...explorationLocalePools().flatMap(p => p.biomes.filter(b => !BIOMES[b]).map(b => `exploration pool ${p.id}: unknown biome ${b}`)),
  ...localePrograms().flatMap(p => validateLocaleProgram(p, { builder: hasDistrictBuilder, doodad: hasDoodadRule, region: id => !!regionKind(id), walkable: id => !!regionKind(id)?.walkable }).map(e => 'locale ' + p.id + ': ' + e)),
  ...mapFeatureKinds().filter(f => f.destination && !localeProgram(f.destination.locale)).map(f => 'atlas destination ' + f.id + ': unknown locale ' + f.destination!.locale),
  ...dimensionIds().flatMap(dim => (dimensionDef(dim).courses ?? []).flatMap(c =>
    validateCourseStages(c.stages, { layout: hasLayout, composition: hasComposition, landmark: hasLandmark,
      liquid: id => liquidIds().includes(id) })
      .map(e => `course ${dim}/${c.id}: ${e}`))),
  ...validateStamps(layoutSources),
  // Composition-local invariants: at→site refs, when-gate keys, site bands.
  ...validateCompositions(id => id in CLIMATE_AXES),
  // Every composition ROLL on a tileset must name a registered bundle.
  ...Object.values(TILESETS).flatMap(t => (t.compositions ?? [])
    .filter(r => !compositionDefs().some(c => c.id === r.composition))
    .map(r => `tileset ${t.id}: unregistered composition '${r.composition}'`)),
  ...Object.entries(BIOMES).flatMap(([id, b]) => (b.compositions ?? [])
    .filter(r => !compositionDefs().some(c => c.id === r.composition))
    .map(r => `biome ${id}: unregistered composition '${r.composition}'`)),
  // A biome naming an edge dressing must name a REGISTERED one.
  ...Object.entries(BIOMES).flatMap(([id, b]) =>
    b.meld && !MELDS[b.meld] ? [`biome ${id}: unregistered meld '${b.meld}'`] : []),
  // THE FACE VOICE (#50 Part B): a tileset's own edge-dressing override must
  // name a registered meld too (tileset ▷ biome at resolved edges).
  ...Object.entries(TILESETS).flatMap(([id, t]) =>
    t.meld && !MELDS[t.meld] ? [`tileset ${id}: unregistered meld '${t.meld}'`] : []),
  // THE BLEND FABRIC: every declared partner/field must resolve (a bad ref
  // no-ops silently at mint — this is where it fails loudly instead).
  ...Object.values(TILESETS).flatMap(t =>
    [{ tag: '', roll: t.blend }, ...(t.variants ?? []).map(v => ({ tag: ` variant '${v.name}'`, roll: v.blend ?? undefined }))]
      .flatMap(({ tag, roll }) => !roll ? [] : [
        ...(!TILESETS[roll.with] ? [`tileset ${t.id}${tag}: unregistered blend partner '${roll.with}'`] : []),
        ...(roll.with === t.id ? [`tileset ${t.id}${tag}: blend partner is itself`] : []),
        ...(!hasBlendField(roll.field.kind) ? [`tileset ${t.id}${tag}: unregistered blend field '${roll.field.kind}'`] : []),
      ])),
];

// --- 1b. THE DEAD-FACE WARN (static, over the authored table) ---------------
// A surface-pooled tileset with variants deals ONLY variants at every surface
// mint, so a base-layout kind absent from every variant + common layout can
// never stand in the world — the class that silently killed 42 plain faces
// before PLAIN_FACES restated them. Warn, not fail: the heal is an authoring
// decision (join PLAIN_FACES, or hoist the kind into common/a face), and the
// adjudication ledger for deliberate exceptions lives in probe_deadface,
// which cross-checks this same predicate (deadBaseFaceKinds — one law, two
// witnesses).
if (!FILTER || 'deadface'.includes(FILTER)) {
  const warns = Object.values(TILESETS).flatMap(t => {
    const dead = deadBaseFaceKinds(t);
    return dead.length
      ? [`tileset ${t.id}: base-only kinds never mint on the surface path — ${dead.join(', ')} (restate the plain face or hoist into common/a variant)`]
      : [];
  });
  results.push({ name: 'deadface:static', seeds: 0, doodads: 0, ms: 0, fails: [], warns });
}

// --- 2. Every tileset, base + variants --------------------------------------
for (const ts of Object.values(TILESETS)) {
  const base: ZoneDef = {
    id: `qa_${ts.id}`, name: `QA ${ts.id}`, level: 8,
    size: { w: mid(ts.sizeW), h: mid(ts.sizeH) },
    theme: ts.theme,
    layout: [...(ts.common ?? []), ...ts.layout],
    // AQUATIC mirrors worldgen's mint stamp (one classifier, both worlds):
    // an open-seabed tileset's flora places ambiently here exactly as live.
    ...(isAquaticBiome(ts.biome) ? { aquatic: true } : {}),
    ...(ts.forceLayout ? { layoutType: ts.forceLayout } : {}),
    ...(ts.layoutParams ? { layoutParams: ts.layoutParams } : {}),
    objective: { kind: 'clear' },
    exits: [], map: { x: 0, y: 0 },
    ...(ts.structures ? { structures: ts.structures } : {}),
    ...(ts.landmarks ? { landmarks: ts.landmarks } : {}),
    ...(ts.compositions ? { compositions: ts.compositions } : {}),
  };
  runCase(`tileset:${ts.id}`, base);
  for (const [i, v] of (ts.variants ?? []).entries()) {
    runCase(`tileset:${ts.id}/${v.name ?? i}`, {
      ...base, id: `qa_${ts.id}_v${i}`,
      layout: [...(ts.common ?? []), ...v.layout],
      // THE FACE'S OWN KNOBS ride its case — the live mint merges variant
      // layoutParams per-key over the tileset's (worldgen's placeZoneAt and
      // mintCave both; the trapworks group below already mirrors it). Until
      // it did, every variant was swept under the BASE face's dials: the sea
      // of ramparts' massif mix was never generated here, which is how its
      // under-fill collapse hid (probe_massif rig F pins the fix).
      ...(ts.layoutParams || v.layoutParams
        ? { layoutParams: { ...ts.layoutParams, ...v.layoutParams } } : {}),
    });
  }
}

// --- 3. Every registered layout generator -----------------------------------
// A representative liquid-y def, swept under EVERY parameterization the
// biome registry authors for the layout: one `layout:id@biome` case per
// DISTINCT layoutParams object among the biomes that roll it (dedupe by
// sorted-key stringify, so biomes sharing identical dials — and biomes with
// none — never multiply cases) plus one `layout:id:bare` case with no params
// at all (the generator's own defaults; also where the param-less biomes
// land). A generator that only breaks under one biome's dials — a riverland
// without its freezeAt, a spiral without its lava, a deep-country overgrowth
// band — now fails NAMED instead of shipping unswept, and the bare lane
// keeps no-param callers (sidezones, hand-authored defs) honest.
const layoutParamsKey = (v: unknown): string => JSON.stringify(v, (_k, val) =>
  val && typeof val === 'object' && !Array.isArray(val)
    ? Object.fromEntries(Object.keys(val as object).sort().map(k => [k, (val as Record<string, unknown>)[k]]))
    : val);
for (const id of layoutIds()) {
  // 'field' shapes itself to a World-side heat-map region (fieldifyZone
  // overrides the footprint; def.field carries the blob) — no headless def
  // is representative. It is exercised through the real world web instead.
  if (id === 'field') continue;
  const layoutSweepCase = (label: string, defId: string, params?: Record<string, unknown>): void => {
    runCase(label, {
      id: defId, name: `QA ${id}`, level: 8,
      size: { w: 2400, h: 1800 },
      theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
      layout: [
        { kind: 'rocks', count: [4, 7] }, { kind: 'trees', count: [5, 8] },
        { kind: 'water', count: [1, 2] }, { kind: 'grass', count: [3, 5] },
      ],
      layoutType: id,
      ...(params ? { layoutParams: params } : {}),
      objective: { kind: 'clear' },
      exits: [], map: { x: 0, y: 0 },
    });
  };
  layoutSweepCase(`layout:${id}:bare`, `qa_layout_${id}`);
  const seenParams = new Set<string>();
  for (const [biomeId, b] of Object.entries(BIOMES)) {
    if (!b.allowedLayouts || !(id in b.allowedLayouts) || !b.layoutParams) continue;
    const key = layoutParamsKey(b.layoutParams);
    if (seenParams.has(key)) continue;
    seenParams.add(key);
    layoutSweepCase(`layout:${id}@${biomeId}`, `qa_layout_${id}_${biomeId}`, b.layoutParams);
  }
}

// Every locale route graph, both river orientations, with choices rolled per QA seed.
for (const p of localePrograms()) for (const v of p.variants) for (const sides of [['w', 'e'], ['n', 's']]) for (const scale of p.sizeScale ?? [1]) {
  runCase('locale:' + p.id + '/' + v.id + '/' + sides.join('') + '/' + scale, {
    id: 'qa_locale_' + p.id, name: p.label, level: 8, size: { w: Math.round(p.size.w * scale), h: Math.round(p.size.h * scale) },
    theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
    layout: [], layoutType: 'districts', layoutParams: { locale: p.id, localeVariant: v.id, riverSides: sides },
    ...(p.underways ? { landmarks: [{ landmark: 'rootway_mouth', chance: 1 }] } : {}),
    objective: { kind: 'clear' }, exits: [], map: { x: 0, y: 0 },
  });
}

// --- 3b. Regional journey stages ---------------------------------------------
// Journey stages consume the SAME local carvers and biome knobs. Sweep every
// authored stage at normal/small scales, across each compatible biome's dials.
// The dedicated probe covers geometric stage selection and the real mint fold.
for (const dim of dimensionIds()) for (const course of dimensionDef(dim).courses ?? []) {
  for (const stage of course.stages ?? []) {
    const recipes = stage.forceLayout || course.forceLayout
      ? [stage.forceLayout ?? course.forceLayout!]
      : Object.keys(BIOMES[course.biome]?.allowedLayouts ?? { plains: 1 });
    for (const recipe of recipes) {
      const contexts = Object.entries(BIOMES).filter(([id, b]) =>
        course.paints === false ? recipe in (b.allowedLayouts ?? {}) : id === course.biome);
      for (const [biome, b] of contexts.length ? contexts : [['plain', undefined] as const]) {
        const ts = Object.values(TILESETS).find(t => t.biome === biome) ?? TILESETS.meadow;
        for (const small of [false, true]) {
          const label = `course:${dim}/${course.id}/${stage.id}@${biome}${small ? ':small' : ''}`;
          runCase(label, {
            id: label, name: label, level: 8, biome,
            size: small ? { w: 1200, h: 900 } : { w: 2400, h: 1800 },
            theme: ts.theme, layout: [...(ts.common ?? []), ...ts.layout],
            layoutType: recipe,
            layoutParams: { ...b?.layoutParams, ...ts.layoutParams, ...course.layoutParams,
              ...stage.layoutParams, riverSides: small ? ['n', 's'] : ['w', 'e'] },
            compositions: [...(stage.compositions ?? []),
              ...(stage.span[1] === 1 ? course.terminus?.compositions ?? [] : [])],
            landmarks: [...(stage.landmarks ?? []),
              ...(stage.span[1] === 1 ? course.terminus?.landmarks ?? [] : [])],
            objective: { kind: 'clear' }, exits: [], map: { x: 0, y: 0 },
          });
        }
      }
    }
  }
}

// --- 3c. Interior layouts at CAVE scale ---------------------------------------
// mintCave rolls dungeon/labyrinth from caveLayouts at cavern arena sizes
// (~1200×900) — far smaller than group 3's representative def. Rooms, portal
// chambers, and door mouths must all still fit and connect down there.
for (const id of ['dungeon', 'labyrinth', 'edifice']) {
  runCase(`layout:${id}@cave`, {
    id: `qa_cave_${id}`, name: `QA cave ${id}`, level: 8,
    size: { w: 1150, h: 880 },
    theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
    layout: [
      { kind: 'rocks', count: [2, 4] }, { kind: 'grass', count: [2, 4] },
    ],
    layoutType: id,
    objective: { kind: 'clear' },
    exits: [], map: { x: 0, y: 0 },
  });
}

// --- 3b². HOLLOWS forced on every face that budgets them ----------------------
// The hollows fabric only fires on GRID layouts, and the tileset cases above
// run their default (usually convex) generator — so force each hollow-
// budgeted tileset through 'rooms' at cave scale with a fat budget, and let
// checkLayout's hollow invariants (sealed rect, seam zip, registered kinds)
// bite on real placements.
for (const ts of Object.values(TILESETS)) {
  if (!ts.hollows) continue;
  runCase(`hollows:${ts.id}`, {
    id: `qa_hollows_${ts.id}`, name: `QA hollows ${ts.id}`, level: 8,
    size: { w: 1300, h: 1000 },
    theme: ts.theme,
    layout: [...(ts.common ?? []), ...ts.layout],
    layoutType: 'rooms',
    hollows: { count: [2, 3], table: ts.hollows.table },
    objective: { kind: 'clear' },
    exits: [], map: { x: 0, y: 0 },
  });
}

// --- 3b²ᵃ. ANNEXES forced on every face that budgets them ---------------------
// The growing zone's mint roll fires at worldgen's chokepoints — the tileset
// cases above never see it — so pre-roll each annex-budgeted tileset's chains
// onto a rooms def (fat count, the tileset's own table + depth, one fixed
// seed: the roll itself is probe-pinned pure) and let checkLayout's annex
// invariants (sealed chambers, face pairing, carve records, the child
// dormant-space law) bite on real per-seed placements.
for (const ts of Object.values(TILESETS)) {
  if (!ts.annexes) continue;
  const def: ZoneDef = {
    id: `qa_annexes_${ts.id}`, name: `QA annexes ${ts.id}`, level: 8,
    size: { w: 1300, h: 1000 },
    theme: ts.theme,
    layout: [...(ts.common ?? []), ...ts.layout],
    layoutType: 'rooms',
    objective: { kind: 'clear' },
    exits: [], map: { x: 0, y: 0 },
    seed: 1000003 + 17,
  };
  applyAnnexes(def, { ...ts, annexes: { ...ts.annexes, count: [2, 2] } });
  runCase(`annexes:${ts.id}`, def);
}

// --- 3b³. THE TRAPWORKS DIAL through the surface rooms recipe -----------------
// layoutParams.trapworks historically fired only inside the interior
// generators; the surface 'rooms' recipe now records its room/corridor truth
// (ctx.trapGeo) and meets the SAME pass at generateLayout's finished-grid
// tail. Every tileset/variant that AUTHORS the dial runs here through 'rooms'
// at its own scale, so plates, lanes, grooves and cradles land under every
// invariant (portal clears, reachability, inverse forbidOn, determinism).
// This is also the rooms-rolled CAVE reality headless: a cave minted under a
// trapworks tileset inherits these dials via mintCave's layoutParams merge.
for (const ts of Object.values(TILESETS)) {
  const rolls = [
    ...(ts.layoutParams?.trapworks ? [{ tag: 'base', params: ts.layoutParams }] : []),
    ...(ts.variants ?? []).flatMap(v => {
      const vp = v.layoutParams as Record<string, unknown> | undefined;
      return vp?.trapworks ? [{ tag: v.name ?? 'variant', params: { ...ts.layoutParams, ...vp } }] : [];
    }),
  ];
  for (const { tag, params } of rolls) {
    runCase(`trapworks:${ts.id}/${tag}@rooms`, {
      id: `qa_traps_${ts.id}_${tag.replace(/\W+/g, '_')}`, name: `QA traps ${ts.id}`, level: 8,
      size: { w: mid(ts.sizeW), h: mid(ts.sizeH) },
      theme: ts.theme,
      layout: [...(ts.common ?? []), ...ts.layout],
      layoutType: 'rooms',
      layoutParams: params,
      objective: { kind: 'clear' },
      exits: [], map: { x: 0, y: 0 },
    });
  }
}

// --- 3c. BOUNDARY GATES on every enclave biome's layouts ----------------------
// Live, the World stamps def.exitBoundaries at load (placeExit's prediction
// seam); headless defs author it directly so the gate composable — façade,
// throat, doodad splice, reservation, floor bake — is exercised against BOTH
// the enclave's own interiors (the inside face) and representative open
// layouts (the outside face), with the reachability invariant holding through
// the mouth. Auto-derives from BiomeInfo.enclave: a future walled biome joins
// this group the day it is tagged, unedited.
for (const [biomeId, b] of Object.entries(BIOMES)) {
  if (!b.enclave) continue;
  const faces = [...new Set([...Object.keys(b.allowedLayouts ?? {}), 'plains', 'riverland'])];
  for (const layoutId of faces) {
    runCase(`boundary:${biomeId}@${layoutId}`, {
      id: `qa_bgate_${biomeId}_${layoutId}`, name: `QA gate ${layoutId}`, level: 8,
      size: { w: 2400, h: 1800 },
      theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
      layout: [
        { kind: 'rocks', count: [4, 7] },
        { kind: 'water', count: [1, 2] }, { kind: 'grass', count: [3, 5] },
      ],
      layoutType: layoutId,
      ...(b.layoutParams ? { layoutParams: b.layoutParams } : {}),
      // Both of runCase's generated exits wear the gate (the hook reads
      // positions from ctx.exits, ids from this array — def.exits stays []).
      exitBoundaries: [b.enclave.gate, b.enclave.gate],
      objective: { kind: 'clear' },
      exits: [], map: { x: 0, y: 0 },
    });
  }
}

// --- 3d. HOLDFAST GATE + KEPT ROAD over representative layout families --------
// Live, a Holdfast's locked bonus exit wears its guardian's gate ('toll_gate')
// through the SAME exitBoundaries seam the enclaves use, plus an exitRoads
// entry that carves the traveled way source-portal → gate mouth. Headless
// defs author both annotations directly so the road composable — the wander,
// the artery reservation, the corridor CUT through walled layouts, the
// gate-aware endpoint — is exercised over open, canopy, carved-grid and
// liquid families with every invariant (portals, reachability, inverse
// forbidOn, determinism) holding through it.
for (const layoutId of ['plains', 'forest', 'winding', 'riverland']) {
  runCase(`holdfast:${layoutId}`, {
    id: `qa_holdfast_${layoutId}`, name: `QA toll ${layoutId}`, level: 6,
    size: { w: 2400, h: 1800 },
    theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
    layout: [
      { kind: 'rocks', count: [4, 7] },
      { kind: 'water', count: [1, 2] }, { kind: 'grass', count: [3, 5] },
    ],
    layoutType: layoutId,
    // Exit 0 is the holdfast: it wears the toll gate AND receives the road.
    exitBoundaries: ['toll_gate', undefined],
    exitRoads: [{ from: 'entry' }, undefined],
    objective: { kind: 'clear' },
    exits: [], map: { x: 0, y: 0 },
  });
}

// --- 3e. BIOME MELDS over open + carved-grid layout families ------------------
// Live, the World stamps def.exitMelds at load (placeExit's prediction seam —
// the third rider on the gates/roads annotation fabric); headless defs author
// it directly so the edge-band composable — the axis WHERE gate, the dedicated
// per-exit rng, every placement rule — is exercised over an open family and
// the jungle's own carved thicket, with all invariants (portals, reachability,
// inverse forbidOn, byte determinism) holding through it. Auto-derives from
// the MELDS registry: a future biome's edge dressing joins this group the day
// it registers, unedited.
for (const m of Object.values(MELDS)) {
  for (const layoutId of ['plains', 'thicket']) {
    runCase(`meld:${m.id}@${layoutId}`, {
      id: `qa_meld_${m.id}_${layoutId}`, name: `QA meld ${layoutId}`, level: 6,
      size: { w: 2400, h: 1800 },
      theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
      layout: [
        { kind: 'rocks', count: [4, 7] },
        { kind: 'water', count: [1, 2] }, { kind: 'grass', count: [3, 5] },
      ],
      layoutType: layoutId,
      // Both generated exits wear the foreign kit (the hook reads positions
      // from ctx.exits, ids from this array — def.exits stays []).
      exitMelds: [m.id, m.id],
      objective: { kind: 'clear' },
      exits: [], map: { x: 0, y: 0 },
    });
  }
}

// --- 3f. THE BLEND FABRIC (engine/blend.ts) ------------------------------------
// Two sweeps, both self-extending:
//  (a) every registered FIELD SHAPE over a derived tileset pair (the first two
//      frontier tilesets by id — no pair is special-cased), across an open and
//      a carved-grid family: the compose (side-tagged rows), the findSpot
//      dither gate, and the 'blend' WHERE field all run under every invariant
//      (portals, reachability, inverse forbidOn, byte determinism);
//  (b) every tileset that DECLARES a blend (tileset-level or variant override)
//      generates with it forced on — the day a blended tileset registers, its
//      real composition joins the sweep unedited.
{
  const frontierIds = Object.values(TILESETS)
    .filter(t => t.frontier !== false && !t.boundless)
    .map(t => t.id).sort();
  const [qaBaseId, qaPartnerId] = frontierIds;
  const qaBase = TILESETS[qaBaseId], qaPartner = TILESETS[qaPartnerId];
  if (qaBase && qaPartner) {
    for (const kind of blendFieldIds()) {
      for (const layoutId of ['plains', 'dungeon']) {
        runCase(`blend:${kind}@${layoutId}`, {
          id: `qa_blend_${kind}_${layoutId}`, name: `QA blend ${kind}`, level: 8,
          size: { w: 2000, h: 1500 },
          theme: qaBase.theme,
          layout: composeBlendLayout([...(qaBase.common ?? []), ...qaBase.layout], qaPartner),
          layoutType: layoutId,
          blend: { with: qaPartner.id, field: { kind } },
          objective: { kind: 'clear' },
          exits: [], map: { x: 0, y: 0 },
        });
      }
    }
  }
  for (const ts of Object.values(TILESETS)) {
    const rolls: { tag: string; roll: NonNullable<typeof ts.blend> }[] = [
      ...(ts.blend ? [{ tag: 'base', roll: ts.blend }] : []),
      ...(ts.variants ?? []).flatMap(v => v.blend ? [{ tag: v.name, roll: v.blend }] : []),
    ];
    for (const { tag, roll } of rolls) {
      const partner = TILESETS[roll.with];
      if (!partner) continue; // the registry sweep already flagged it
      const variant = ts.variants?.find(v => v.name === tag);
      const rows = variant ? variant.layout : ts.layout;
      const layoutType = ts.forceLayout
        ?? (ts.caveLayouts ? Object.entries(ts.caveLayouts).sort((a, b) => b[1] - a[1])[0][0] : undefined);
      runCase(`blend:${ts.id}/${tag}`, {
        id: `qa_blend_${ts.id}_${tag.replace(/\W+/g, '_')}`, name: `QA blend ${ts.id}`, level: 8,
        size: { w: mid(ts.sizeW), h: mid(ts.sizeH) },
        theme: ts.theme,
        layout: composeBlendLayout([...(ts.common ?? []), ...rows], partner),
        ...(layoutType ? { layoutType } : {}),
        // A variant's blend generates under the variant's MERGED knobs, same
        // as the tileset sweep (tag 'base' has no variant — base params only).
        ...(ts.layoutParams || variant?.layoutParams
          ? { layoutParams: { ...ts.layoutParams, ...variant?.layoutParams } } : {}),
        blend: { with: roll.with, field: roll.field, ...(roll.packs !== undefined ? { packs: roll.packs } : {}) },
        objective: { kind: 'clear' },
        exits: [], map: { x: 0, y: 0 },
      });
    }
  }
}

// --- 4. Every composition, FORCED (chance 1) ---------------------------------
// The tileset sweep exercises compositions probabilistically; this group pins
// every bundle at least once per seed over a representative liquid-y def (the
// water rows let shore-banded entries site). when-gates pass neutrally here
// (headless defs bake no geo) — exactly the authored contract.
for (const c of compositionDefs()) {
  runCase(`composition:${c.id}`, {
    id: `qa_comp_${c.id}`, name: `QA ${c.id}`, level: 8,
    size: { w: 2400, h: 1800 },
    theme: { floor: '#161616', grid: '#222', border: '#555', obstacle: '#333', obstacleEdge: '#666', accent: '#999' },
    layout: [
      { kind: 'rocks', count: [4, 7] }, { kind: 'trees', count: [5, 8] },
      { kind: 'water', count: [1, 2] }, { kind: 'grass', count: [3, 5] },
    ],
    compositions: [{ composition: c.id, chance: 1 }],
    objective: { kind: 'clear' },
    exits: [], map: { x: 0, y: 0 },
  });
}

// --- 4b. Every AUTHORED MAP (engine/authoredMaps.ts) ------------------------------
// The hand-made zones through the same net: the pure synthetic def
// (authoredZoneDef — what placeZoneAt builds, minus the graph) under runCase's
// own synthetic portals, so the stems + connectivity carve are judged against
// ARBITRARY seats (the way home faces the anchor — a map never knows its
// side). The lint is the registry half: a shipped map that cannot mint as
// drawn fails here, not at a player's door.
for (const m of authoredMapDefs()) {
  const lint = validateAuthoredMap(m);
  if (lint.length) results.push({ name: `authored:${m.id}:lint`, seeds: 0, doodads: 0, ms: 0, fails: lint.map(l => `authored map '${m.id}': ${l}`), warns: [] });
  runCase(`authored:${m.id}`, authoredZoneDef(m, { id: `qa_authored_${m.id}`, level: 8 }));
}

// --- 5. EXIT SPACING — the worldgen graph layer's promise ---------------------
// Drives the REAL graph builder (randomizeStarterWeb → generateZone charts,
// with their back-edges, frontier deals, weaves and reciprocals) plus the
// guarded append paths (spacedExitAt — holdfast bonus exits, the Field
// frontier spread), and asserts the promise the live dwell relies on: every
// pair of a def's exits resolves to portal PIXELS ≥ MIN_PORTAL_SEP apart,
// corner collisions included. Two stacked portals leave one un-dwellable —
// the "can't choose which zone I enter" hard-lock this net exists to catch.
// placeExit's edge math is mirrored below (the harness asserts the OBSERVABLE
// promise); MIN_PORTAL_SEP itself is imported — it's the engine's public
// contract now, shared with world.ts's live resolve.
const P_INSET = 90; // mirror of worldgen PORTAL_EDGE_INSET (placeExit's edge math)
function portalPixel(side: 'n' | 's' | 'e' | 'w', at: number, size: { w: number; h: number }): { x: number; y: number } {
  const cx = Math.min(Math.max(size.w * at, P_INSET), size.w - P_INSET);
  const cy = Math.min(Math.max(size.h * at, P_INSET), size.h - P_INSET);
  return side === 'n' ? { x: cx, y: P_INSET } : side === 's' ? { x: cx, y: size.h - P_INSET }
    : side === 'w' ? { x: P_INSET, y: cy } : { x: size.w - P_INSET, y: cy };
}
function checkExitSpacing(label: string, def: Pick<ZoneDef, 'exits' | 'size'>, fails: string[]): void {
  for (let i = 0; i < def.exits.length; i++) {
    for (let j = i + 1; j < def.exits.length; j++) {
      const a = def.exits[i], b = def.exits[j];
      const pa = portalPixel(a.side, a.at ?? 0.5, def.size), pb = portalPixel(b.side, b.at ?? 0.5, def.size);
      const d = Math.hypot(pa.x - pb.x, pa.y - pb.y);
      if (d < MIN_PORTAL_SEP - 0.5) {
        fails.push(`${label}: exits ${i} (${a.side}@${(a.at ?? 0.5).toFixed(2)}→${a.to}) and `
          + `${j} (${b.side}@${(b.at ?? 0.5).toFixed(2)}→${b.to}) only ${d.toFixed(0)}px apart `
          + `(< ${MIN_PORTAL_SEP}) on a ${def.size.w}×${def.size.h} zone`);
      }
    }
  }
}
if (!FILTER || 'exit-spacing'.includes(FILTER)) {
  const fails: string[] = [];
  const t0 = performance.now();
  const webs = SEEDS * 2;
  let charted = 0;
  for (let w = 0; w < webs; w++) {
    // Fresh deep clones — ZONES defs are module singletons; a probe web must
    // never share their exits arrays (the cloneZones by-reference trap).
    const zoneMap: Record<string, ZoneDef> = {};
    for (const [id, z] of Object.entries(ZONES)) {
      zoneMap[id] = { ...z, exits: z.exits.map(e => ({ ...e })), size: { ...z.size }, map: { ...z.map } };
    }
    randomizeStarterWeb(zoneMap, (0x5eed + w * 7919) >>> 0);
    const rng = new Rng((0xac3 + w) >>> 0);
    let genIdx = 1000 + w * 100;
    // Chart '?' frontiers the way travel does, ~12 mints per web (the weave
    // machinery runs inside generateZone — reciprocals and all).
    for (let step = 0; step < 12; step++) {
      const openDefs = Object.values(zoneMap).filter(z => z.exits.some(e => e.to === '?' && !e.lock));
      if (!openDefs.length) break;
      const src = openDefs[rng.int(0, openDefs.length - 1)];
      const e = src.exits.find(x => x.to === '?' && !x.lock)!;
      const gen = generateZone(src, e, zoneMap, genIdx++);
      zoneMap[gen.id] = gen;
      e.to = gen.id;
      charted++;
    }
    // The graph layer's own deals + weaves…
    for (const z of Object.values(zoneMap)) checkExitSpacing(`web ${w} zone ${z.id}`, z, fails);
    // …then the GUARDED append paths, stressed. Holdfast-style: the overlay's
    // real raw at-candidates, pushed through the spacing guard, twice per zone.
    for (const z of Object.values(zoneMap)) {
      for (let k = 0; k < 2; k++) {
        const side = rng.pick(['n', 's', 'e', 'w'] as const);
        const at = rng.pick([0.2, 0.32, 0.68, 0.8]);
        z.exits.push({ to: '?', side, at: spacedExitAt(z, side, at) });
      }
      checkExitSpacing(`web ${w} zone ${z.id} +holdfast-appends`, z, fails);
    }
    // Field-style spread: keep the real roads, re-deal 2-per-side frontiers
    // through the guard (mirrors world.fieldifyZone's rebuild).
    for (const z of Object.values(zoneMap)) {
      const reals = z.exits.filter(x => x.to !== '?').map(e => ({ ...e }));
      if (!reals.length) continue;
      const rebuilt = { exits: reals, size: z.size };
      for (const side of ['n', 's', 'e', 'w'] as const) {
        for (const at of [0.3, 0.7]) rebuilt.exits.push({ to: '?', side, at: spacedExitAt(rebuilt, side, at) });
      }
      checkExitSpacing(`web ${w} zone ${z.id} field-spread`, rebuilt, fails);
    }
  }
  results.push({ name: 'exit-spacing:webs', seeds: webs, doodads: charted,
    ms: (performance.now() - t0) / Math.max(1, webs), fails, warns: [] });
}

// --- Report ------------------------------------------------------------------
let failTotal = registryErrors.length;
for (const msg of registryErrors) console.log(`REGISTRY FAIL: ${msg}`);
let warnTotal = 0;
for (const r of results) {
  failTotal += r.fails.length;
  warnTotal += r.warns.length;
  for (const f of r.fails) console.log(`FAIL: ${f}`);
  for (const w of r.warns) console.log(`warn: ${w}`);
  if (VERBOSE && !r.fails.length) {
    console.log(`ok   ${r.name} — ${r.doodads} doodads, ${r.ms.toFixed(1)}ms/seed`);
  }
}
const slow = results.filter(r => r.ms > 400);
for (const r of slow) console.log(`warn: ${r.name} slow (${r.ms.toFixed(0)}ms/seed)`);
console.log(`\ngenqa: ${results.length} cases × ${SEEDS} seeds — ${failTotal} fail(s), ${warnTotal + slow.length} warn(s)`);
if (exploration && explorationPath) {
  exploration.write(explorationPath, { failures: failTotal, warnings: warnTotal + slow.length });
  console.log(`Exploration report: ${explorationPath}`);
}
process.exit(failTotal ? 2 : 0);
