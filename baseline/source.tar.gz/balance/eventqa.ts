// ---------------------------------------------------------------------------
// EVENT QA — the event-fabric invariant sweep (`npm run eventqa`).
//
// Runs the CONTENT-PACKAGE / overlay / zone-event fabric headlessly and
// asserts the contracts the framework promises — the regression net for the
// event system, exactly as genqa is for generation (exit 2 on breach).
//
// Invariant groups:
//   registry    every package def validates against the live registries
//               (validatePackages — the same sweep the sim warns with, made a
//               FAILING gate), ids unique, per-package seeds distinct
//   pledge      persistence: 'durable' ⇔ snapshot()+restore() implemented,
//               'transient' ⇔ neither (the pledge can never drift from code)
//   gates       resolveGates math: weighted shares sum to 1, pressure
//               preserves the count, alwaysOn/pressureless hold no seat and
//               change nothing for others, relationships fold only while both
//               run, the frequency crank folds into the three muls exactly
//   manifest    build → JSON → reconcile is stable; unknown ids drop; out-of-
//               range sliders clamp; a garbage manifest degrades to defaults
//   lifecycle   a full WorldSim over the real starter web ticks for minutes
//               without a throw; snapshotOverlays is PURE JSON; restore into
//               a fresh sim reproduces the exact snapshot (roundtrip); two
//               sims on one seed stay byte-identical (determinism); an
//               everything-culled prune never throws
//   fracture    the divert handoff: in transit ⇒ active nowhere; the glide
//               lands EXACTLY on the destination zone (longer timer); a
//               mid-transit save resolves to the destination; grace/idle
//               config coherent (the "never spawned" regression net)
//   ledger      the unlock contract: every ledger key any unlock/tier READS
//               is BUMPED somewhere in src/ (source-scan) — no impossible
//               unlocks; every EncounterLedger key is read by some unlock
//   policy      BIOMES deny/allowEvents name real event ids; deny/allow
//               factions name real (post-graft) factions
//   zone-events the on-entry registry: unique ids, sane rewards, the classic
//               priority cascade (siege > caravan > patrol) preserved
//   waning      THE WANING LAW (finite clocks): every encounter scale's clock
//               and kill-fed well are finite; kill-fed defs carry the wane
//               tell; wells without spigots (and spigots without wells) are
//               dead knobs; surge/tide ceilings (maxLifeSec, the deadwake
//               pour budget) are declared and positive; the incursion's
//               termination is wired-and-winnable (the Observer deed
//               resolves, cleanse outruns regrowth, collapse is total)
//
// Usage: npm run eventqa [-- --verbose]
// ---------------------------------------------------------------------------

// Side-effect registries — the same set main.ts loads; a missing import here
// would make the sweep test a DIFFERENT game (genqa's discipline).
import '../src/data/clusters';
import '../src/data/formations';
import '../src/engine/landmarkBuilders';
import '../src/data/landmarks';
import '../src/data/lairs';
import '../src/engine/layoutRecipes';
import '../src/engine/interiorGen';
// The recipe-registering data kits (genqa's set): without these the layout
// registry misses 'needles'/'fields'/'district' and the BIOMES
// allowedLayouts validation cried wolf every run — masking real drift.
import '../src/data/massifs';
import '../src/data/settled';
import '../src/data/garden';
import '../src/data/grove';
import '../src/data/theater'; // THE THEATER FABRIC's defaults (before warfront — kind priority is registration order)
import '../src/data/warfront';
import '../src/data/scald';
import '../src/data/pilgrimage'; // THE TERRACE PILGRIMAGE theater kind + rows (the scald coda)
import '../src/data/compositions';
// The living-terrain registries main.ts loads (fog banks, creep kinds): a def
// validate() that checks FOG_BANKS/CREEPS must see the same game the player
// boots (deepwinter's whiteout was the first to read one here).
import '../src/data/fog';
import '../src/data/creeps';

import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { registerAllPackageFactions } from '../src/packages/factionGen';
import { PACKAGES, PACKAGE_BY_ID, packageSeed, allEncounterSpecs } from '../src/packages/registry';
import { validatePackages } from '../src/packages/validation';
import { buildManifest, reconcileManifest, type ExpeditionManifest } from '../src/packages/manifest';
import { resolveGates, gateOf, INACTIVE_GATE } from '../src/packages/weighting';
import { scaledCap } from '../src/packages/frequency';
import { theaterKinds, theaterRows, theaterKindDef, THEATER_CFG } from '../src/engine/theater';
import { validateRadianceCond } from '../src/world/radiance';
import { WorldSim, packageLookups } from '../src/world/sim';
import { BIOMES } from '../src/world/biomes';
import { FACTIONS, MONSTERS } from '../src/data/monsters';
import { TILESETS } from '../src/data/tilesets'; // THE FACE AXIS census (theater rows naming faces)
import { IncursionField, INCURSION_ARCHETYPES } from '../src/packages/overlays/incursion';
import { Rng } from '../src/core/rng';
import { START_ZONE, ZONES, type ZoneDef } from '../src/data/zones';
import { randomizeStarterWeb } from '../src/engine/worldgen';
import { makeAccount } from '../src/meta/account';
import type { OverlayView, WorldOverlay } from '../src/world/overlay';

const args = process.argv.slice(2);
const VERBOSE = args.includes('--verbose');

let failures = 0;
let checks = 0;
const fail = (group: string, msg: string): void => {
  failures++;
  console.error(`  ✗ [${group}] ${msg}`);
};
const ok = (group: string, msg: string): void => {
  checks++;
  if (VERBOSE) console.log(`  ✓ [${group}] ${msg}`);
};
const assert = (cond: boolean, group: string, msg: string): void => {
  if (cond) ok(group, msg); else fail(group, msg);
};

// Grafted factions must exist before ANY validation/lookup (main.ts order).
registerAllPackageFactions();

// === 1. REGISTRY ==============================================================
console.log('eventqa: registry integrity');
{
  const problems = validatePackages(packageLookups());
  for (const p of problems) fail('registry', p);
  assert(problems.length === 0, 'registry', `validatePackages clean over ${PACKAGES.length} packages`);

  const ids = PACKAGES.map(p => p.id);
  assert(new Set(ids).size === ids.length, 'registry', 'package ids unique');

  const seeds = ids.map(id => packageSeed(0x1234abcd, id));
  assert(new Set(seeds).size === seeds.length, 'registry', 'per-package seeds pairwise distinct');
}

// === 2. THE PERSISTENCE PLEDGE ===============================================
console.log('eventqa: the persistence pledge');
function assertPledge(o: WorldOverlay, from: string): void {
  const hasSnap = typeof o.snapshot === 'function';
  const hasRestore = typeof o.restore === 'function';
  if (o.persistence === 'durable') {
    assert(hasSnap && hasRestore, 'pledge', `${from}/${o.id}: durable ⇒ snapshot+restore`);
  } else {
    assert(!hasSnap && !hasRestore, 'pledge', `${from}/${o.id}: transient ⇒ neither hook`);
  }
}
{
  // Package overlays: constructed exactly as the sim would.
  for (const p of PACKAGES) {
    if (!p.world?.overlay) continue;
    const inst = p.world.overlay({ seed: 0xbeef, gate: () => INACTIVE_GATE, biomeSeed: 0xbeef });
    assertPledge(inst, 'pkg');
    assert(inst.id.length > 0 && !inst.id.startsWith(':'), 'pledge', `${p.id}: overlay id well-formed`);
  }
}

// === 3. GATE MATH =============================================================
console.log('eventqa: gate math');
const account = makeAccount();
/** A manifest with EVERY package enabled + live from level 1 (weights kept). */
function forcedManifest(seed: number): ExpeditionManifest {
  const m = buildManifest(account, seed);
  return {
    ...m,
    packages: PACKAGES.map(p => ({
      id: p.id, enabled: true, weight: p.defaultWeight, startLevel: 0,
    })),
  };
}
{
  const m = forcedManifest(0x51ee7);
  for (const level of [1, 10, 50, 100]) {
    const gates = resolveGates(m, level);
    const weighted = PACKAGES.filter(p => !p.alwaysOn && !p.pressureless);
    const shares = weighted.map(p => gateOf(gates, p.id).share);
    const shareSum = shares.reduce((s, v) => s + v, 0);
    assert(Math.abs(shareSum - 1) < 1e-9, 'gates', `lv${level}: weighted shares sum to 1 (${shareSum.toFixed(6)})`);
    const pressures = weighted.map(p => gateOf(gates, p.id).pressure);
    const pSum = pressures.reduce((s, v) => s + v, 0);
    assert(Math.abs(pSum - weighted.length) < 1e-6, 'gates', `lv${level}: Σpressure preserves the active count`);
    for (const p of PACKAGES) {
      const g = gateOf(gates, p.id);
      if (p.alwaysOn || p.pressureless) {
        assert(g.active && g.share === 0 && g.pressure === 1, 'gates', `${p.id}: unweighted seat (share 0, pressure 1)`);
      }
    }
  }

  // Pressureless byte-identity: the Pit's presence must not move ANY other gate.
  const without: ExpeditionManifest = { ...m, packages: m.packages.map(e => e.id === 'pit' ? { ...e, enabled: false } : e) };
  const gA = resolveGates(m, 50), gB = resolveGates(without, 50);
  let identical = true;
  for (const p of PACKAGES) {
    if (p.id === 'pit') continue;
    if (JSON.stringify(gA.get(p.id)) !== JSON.stringify(gB.get(p.id))) identical = false;
  }
  assert(identical, 'gates', 'pressureless package holds NO seat (others byte-identical with it on/off)');

  // Relationship fold: breach amplifies demon_invasion while BOTH are active.
  const withBreach = resolveGates(m, 50);
  const noBreach = resolveGates({ ...m, packages: m.packages.map(e => e.id === 'breach' ? { ...e, enabled: false } : e) }, 50);
  const demonShareWith = gateOf(withBreach, 'demon_invasion').share;
  // Recompute what demon's share WOULD be un-amplified but same active set:
  // amplification must yield a strictly higher share than its own weight/total.
  const activeW = PACKAGES.filter(p => !p.alwaysOn && !p.pressureless)
    .reduce((s, p) => s + p.defaultWeight, 0);
  const naive = (PACKAGE_BY_ID['demon_invasion'].defaultWeight) / activeW;
  assert(demonShareWith > naive, 'gates', `amplifies folds in (demon share ${demonShareWith.toFixed(4)} > naive ${naive.toFixed(4)})`);
  assert(gateOf(noBreach, 'demon_invasion').active, 'gates', 'demon stays active without breach (fold needs BOTH)');

  // The frequency crank folds into exactly the three muls.
  const cranked: ExpeditionManifest = { ...m, frequency: { rate: 2, concurrency: 3, severity: 0.5 } };
  const gc = resolveGates(cranked, 50);
  for (const p of PACKAGES.filter(pp => !pp.alwaysOn && !pp.pressureless).slice(0, 4)) {
    const g = gateOf(gc, p.id);
    assert(Math.abs(g.ignitionMul - g.pressure * 2) < 1e-9, 'gates', `${p.id}: ignitionMul = pressure × rate`);
    assert(Math.abs(g.severityMul - g.pressure * 0.5) < 1e-9, 'gates', `${p.id}: severityMul = pressure × severity`);
    assert(g.concurrencyMul === 3, 'gates', `${p.id}: concurrencyMul = crank`);
  }
  assert(scaledCap(1, 0) === 1 && scaledCap(2, 0.1) === 1 && scaledCap(2, 3) === 6, 'gates', 'scaledCap floors at 1 and scales');
}

// === 4. MANIFEST ==============================================================
console.log('eventqa: manifest build/reconcile');
{
  const m = buildManifest(account, 0xfeed);
  const round = reconcileManifest(JSON.parse(JSON.stringify(m)), account, 0);
  assert(JSON.stringify(round) === JSON.stringify(m), 'manifest', 'build → JSON → reconcile is stable');

  const withGhost = JSON.parse(JSON.stringify(m)) as ExpeditionManifest;
  withGhost.packages.push({ id: 'ghost_package', enabled: true, weight: 50, startLevel: 0 });
  const dropped = reconcileManifest(withGhost, account, 0);
  assert(!dropped.packages.some(e => e.id === 'ghost_package'), 'manifest', 'unknown package ids drop on reconcile');

  const wild = JSON.parse(JSON.stringify(m)) as ExpeditionManifest;
  for (const e of wild.packages) { e.weight = 9999; e.startLevel = -50; }
  const clamped = reconcileManifest(wild, account, 0);
  for (const e of clamped.packages) {
    const p = PACKAGE_BY_ID[e.id];
    if (!p) continue;
    if (e.weight > 100 || e.startLevel < 0) { fail('manifest', `${e.id} slider escaped its band (w${e.weight}/s${e.startLevel})`); }
  }
  ok('manifest', 'out-of-range sliders clamp into their (tier-widened) bands');
  const garbage = reconcileManifest('not a manifest', account, 42);
  assert(garbage.packages.length > 0 && garbage.seed === 42, 'manifest', 'garbage input degrades to a fresh default manifest');
}

// === 5. LIFECYCLE (headless WorldSim over the real starter web) ==============
console.log('eventqa: overlay lifecycle (tick / snapshot / restore / determinism)');
function starterView(sim: WorldSim, zoneMap: Record<string, ZoneDef>, time: number): OverlayView {
  const allNodes = Object.values(zoneMap);
  const nodes = allNodes.filter(z => (z.dimension ?? 'surface') === 'surface');
  const byId: Record<string, ZoneDef> = {};
  for (const z of nodes) byId[z.id] = z;
  return {
    nodes, byId, allNodes,
    terrain: () => 'land' as const,
    currentZoneId: START_ZONE,
    time,
    census: {},
    charLevel: 50,
    gates: sim.gatesFor(50),
    visited: new Set(nodes.map(z => z.id)),
    surveyed: new Set<string>(),
  };
}
function runSim(seed: number, steps: number): { sim: WorldSim; zoneMap: Record<string, ZoneDef>; time: number } {
  const manifest = forcedManifest(seed);
  const sim = new WorldSim(manifest);
  const zoneMap: Record<string, ZoneDef> = JSON.parse(JSON.stringify(ZONES));
  randomizeStarterWeb(zoneMap, manifest.seed);
  let time = 0;
  for (const z of Object.values(zoneMap)) {
    if (z.floating) continue;
    sim.onNodeCharted(z, starterView(sim, zoneMap, time));
  }
  const DT = 0.5;
  for (let i = 0; i < steps; i++) {
    time += DT;
    sim.update(DT, starterView(sim, zoneMap, time));
  }
  return { sim, zoneMap, time };
}
{
  const STEPS = 720; // 6 simulated minutes at the 0.5s step — deep into event arcs
  let a: ReturnType<typeof runSim> | null = null;
  try { a = runSim(0xa11ce, STEPS); ok('lifecycle', `sim A ticked ${STEPS} steps without a throw`); }
  catch (e) { fail('lifecycle', `sim A threw: ${(e as Error).stack?.split('\n')[0]}`); }
  let b: ReturnType<typeof runSim> | null = null;
  try { b = runSim(0xa11ce, STEPS); } catch { /* covered above */ }

  if (a && b) {
    const snapA = a.sim.snapshotOverlays();
    const snapB = b.sim.snapshotOverlays();
    // PURE JSON: the stringify→parse→stringify fixpoint holds (no Maps/Sets/
    // class instances/functions survive JSON, so drift shows as inequality).
    const jsonA = JSON.stringify(snapA);
    assert(jsonA === JSON.stringify(JSON.parse(jsonA)), 'lifecycle', 'snapshot bag is pure JSON');
    assert(jsonA === JSON.stringify(snapB), 'lifecycle', 'same seed + same ticks ⇒ byte-identical snapshots (determinism)');
    for (const key of Object.keys(snapA)) {
      assert(!key.startsWith(':') || key === ':reputation' || key === ':drives', 'lifecycle', `snapshot key '${key}' well-formed`);
    }

    // RESTORE ROUNDTRIP: a fresh sim adopting the bag re-emits it exactly.
    const fresh = runSim(0xa11ce, 0);
    const restored = fresh.sim.restoreOverlays(JSON.parse(jsonA) as Record<string, unknown>);
    const again = JSON.stringify(fresh.sim.snapshotOverlays());
    assert(again === jsonA, 'lifecycle', `restore → snapshot reproduces the bag exactly (${restored.size} fields restored)`);

    // The restored world keeps living, and an everything-culled prune is safe.
    try {
      let t = fresh.time;
      for (let i = 0; i < 100; i++) { t += 0.5; fresh.sim.update(0.5, starterView(fresh.sim, fresh.zoneMap, t)); }
      ok('lifecycle', 'restored sim ticks on without a throw');
    } catch (e) { fail('lifecycle', `restored sim threw: ${(e as Error).stack?.split('\n')[0]}`); }
    try {
      fresh.sim.pruneOverlayZones(() => false);
      JSON.stringify(fresh.sim.snapshotOverlays());
      ok('lifecycle', 'total prune (every zone culled) never throws and stays pure JSON');
    } catch (e) { fail('lifecycle', `total prune threw: ${(e as Error).stack?.split('\n')[0]}`); }

    // Dev-ignite parity: every cached event field the Events tab drives exists.
    const s = a.sim;
    const devSeams: [string, boolean][] = [
      ['demonField.devIgnite', typeof s.demonField?.devIgnite === 'function'],
      ['crusadeField.devIgnite', typeof s.crusadeField?.devIgnite === 'function'],
      ['fractureField.devIgnite', typeof s.fractureField?.devIgnite === 'function'],
      ['huntField.devIgnite', typeof s.huntField?.devIgnite === 'function'],
      ['conclaveField.devOpenRitual', typeof s.conclaveField?.devOpenRitual === 'function'],
      ['deadwakeField.devIgnite', typeof s.deadwakeField?.devIgnite === 'function'],
      ['migrationField.devIgnite', typeof s.migrationField?.devIgnite === 'function'],
      ['brigandField.devIgnite', typeof s.brigandField?.devIgnite === 'function'],
      ['contagionField.devIgnite', typeof s.contagionField?.devIgnite === 'function'],
      ['holdfastField.devForce', typeof s.holdfastField?.devForce === 'function'],
      ['myceliaField.devIgnite', typeof s.myceliaField?.devIgnite === 'function'],
      ['hauntField.devIgnite', typeof s.hauntField?.devIgnite === 'function'],
      ['breachField.devIgnite', typeof s.breachField?.devIgnite === 'function'],
      ['amalgamationField.devOpen', typeof s.amalgamationField?.devOpen === 'function'],
      ['vendettaField.devIgnite', typeof s.vendettaField?.devIgnite === 'function'],
      ['worldBossField.devIgnite', typeof s.worldBossField?.devIgnite === 'function'],
      ['worldBossField.devManifest', typeof s.worldBossField?.devManifest === 'function'],
      ['worldBossField.devLair', typeof s.worldBossField?.devLair === 'function'],
      ['extractionField.devIgnite', typeof s.extractionField?.devIgnite === 'function'],
      ['boroughField.devIgnite', typeof s.boroughField?.devIgnite === 'function'],
      ['unsealingField.devIgnite', typeof s.unsealingField?.devIgnite === 'function'],
      ['wraithsailField.devSummon', typeof s.wraithsailField?.devSummon === 'function'],
      ['wraithsailField.devDock', typeof s.wraithsailField?.devDock === 'function'],
      ['gloamingField.devIgnite', typeof s.gloamingField?.devIgnite === 'function'],
      ['gloamingField.devRecede', typeof s.gloamingField?.devRecede === 'function'],
      ['quickeningField.devIgnite', typeof s.quickeningField?.devIgnite === 'function'],
      ['quickeningField.devFade', typeof s.quickeningField?.devFade === 'function'],
    ];
    for (const [name, present] of devSeams) assert(present, 'lifecycle', `dev seam ${name} present`);
  }
}

// === 5b. FRACTURE DIVERT LIFECYCLE ===========================================
// The cross-zone handoff the chase depends on: a diverted fracture is nowhere
// while its marker glides (nothing may materialize), LANDS exactly on its
// destination zone when the glide ends (fractureIn surfaces it, longer-timer),
// and a mid-transit save resolves to the DESTINATION (the glide is theatre).
// Regression net for "chased it into the next zone and it never spawned".
console.log('eventqa: fracture divert lifecycle');
{
  const { sim, zoneMap, time } = runSim(0xf2ac, 0);
  const ff = sim.fractureField;
  if (!ff) {
    fail('fracture', 'sim.fractureField accessor missing');
  } else {
    // The starter seed web is tiny (town + one field zone); a real divert lands
    // on ground the engine CHARTS on demand (pickRovingDest generates a '?'
    // frontier). Mirror that: mint a destination node into the QA web.
    const seedHost = Object.values(zoneMap).find(z => z.objective.kind !== 'safe' && z.caveDepth == null && !z.floating);
    if (seedHost) {
      const dest = JSON.parse(JSON.stringify(seedHost)) as ZoneDef;
      dest.id = 'qa_divert_dest';
      dest.name = 'QA Divert Destination';
      zoneMap[dest.id] = dest;
    }
    const view = starterView(sim, zoneMap, time);
    const surge = ff.surge();
    // Config coherence for the new arrival-grace lever set.
    assert(surge.divertGrace > 0, 'fracture', `divertGrace is live (${surge.divertGrace}s)`);
    assert(surge.divertTimer >= surge.baseTimer, 'fracture', 'divertTimer at least as forgiving as baseTimer');
    assert(surge.travelSeconds > 0, 'fracture', 'travelSeconds positive (the glide exists)');
    assert(surge.idleLife > surge.travelSeconds + surge.divertGrace, 'fracture',
      'idleLife outlasts glide + grace (a chased fracture cannot idle out mid-handoff)');

    // Ignite somewhere targetable, then divert to another valid host.
    let zoneA = '';
    for (const n of view.nodes) { if (ff.devIgnite(view, n.id)) { zoneA = n.id; break; } }
    assert(zoneA !== '', 'fracture', 'devIgnite found a targetable starter zone');
    const zoneB = view.nodes.find(z => z.id !== zoneA && z.caveDepth == null && !z.floating
      && !z.eventOwned && z.objective.kind !== 'safe')?.id ?? '';
    assert(zoneB !== '', 'fracture', 'a second valid host exists to divert to');
    if (zoneA && zoneB) {
      const origin = ff.fractureIn(zoneA);
      assert(!!origin && !origin.longerTimer, 'fracture', 'ignited fracture surfaces at its origin (base timer)');
      const hops0 = ff.peek()?.hopsRemaining ?? 0;
      assert(hops0 > 0, 'fracture', 'dev-ignited fracture has hops to spend');

      ff.divert(zoneB, { x: 0, y: 0 }, { x: 120, y: 80 });
      // IN TRANSIT: active nowhere (the engine must not materialize it) but
      // visibly travelling, and the hop already spent.
      assert(ff.fractureIn(zoneA) === null && ff.fractureIn(zoneB) === null, 'fracture', 'in transit ⇒ active in NO zone');
      assert(ff.peek()?.travelPos != null, 'fracture', 'in transit ⇒ the marker glides (travelPos live)');
      assert((ff.peek()?.hopsRemaining ?? -1) === hops0 - 1, 'fracture', 'divert spends exactly one hop');
      assert(ff.activityAt(zoneB) === 0, 'fracture', 'no event-activity bloom until it lands');

      // MID-TRANSIT SAVE lands at the destination (snapshot pledge).
      const snap = ff.snapshot() as { fracture?: { zoneId?: string; diverted?: boolean } };
      assert(snap.fracture?.zoneId === zoneB && snap.fracture?.diverted === true, 'fracture',
        'mid-transit snapshot resolves to the destination, diverted');
      const pkg = PACKAGE_BY_ID['fractures'];
      const fresh = pkg?.world?.overlay?.({ seed: 0xf2ac, gate: () => INACTIVE_GATE, biomeSeed: 0xf2ac }) as typeof ff | undefined;
      if (fresh?.restore) {
        fresh.restore(JSON.parse(JSON.stringify(snap)));
        const landed = fresh.fractureIn(zoneB);
        assert(!!landed && landed.longerTimer, 'fracture', 'restored mid-transit save surfaces AT the destination (longer timer)');
      } else {
        fail('fracture', 'fractures overlay restore hook missing');
      }

      // ARRIVAL: step the live overlay past the glide — it must surface in the
      // destination (and only there), as the longer-timer diverted instance.
      const steps = Math.ceil((surge.travelSeconds + 0.6) / 0.5);
      for (let i = 0; i < steps; i++) ff.update(0.5, view);
      const arrived = ff.fractureIn(zoneB);
      assert(!!arrived && arrived.longerTimer, 'fracture', 'glide complete ⇒ fracture surfaces in the destination (longer timer)');
      assert(ff.fractureIn(zoneA) === null, 'fracture', 'origin zone released after the divert');
      assert(ff.peek()?.travelPos == null, 'fracture', 'arrival clears the glide');
      assert(ff.activityAt(zoneB) === 1, 'fracture', 'landed fracture feeds the activity bloom');
    }
  }
}

// === 5c. EXTRACTION SPENT-LEDGER + EXTRACT HONESTY ===========================
// The seam's economy guard: a drained zone must not re-roll its essence
// faucet on a door-hinge (spent survives snapshot/restore), yet the world
// keeps breathing (replenishment). Plus the countdown-honesty invariant: an
// extract clock is NEVER kill-fed — the yield ceiling is the rolled timer.
console.log('eventqa: extraction spent-ledger + honesty');
{
  const pkg = PACKAGES.find(p => p.id === 'extraction');
  if (!pkg?.world?.overlay) {
    fail('extraction', 'extraction package/overlay missing from the registry');
  } else {
    const LIVE_GATE = { active: true, share: 1, pressure: 1, ignitionMul: 1, severityMul: 1, concurrencyMul: 1 };
    type XF = { nodeAvailable(z: string): boolean; markSpent(z: string, t: number): void;
      devIgnite(v: unknown, z: string): boolean; update(dt: number, v: unknown): void;
      snapshot?(): unknown; restore?(s: unknown): void; pruneZones?(has: (z: string) => boolean): void };
    const mk = (): XF => pkg.world!.overlay!({ seed: 0xe57a, gate: () => LIVE_GATE, biomeSeed: 0xe57a }) as unknown as XF;
    const viewAt = (time: number): unknown => ({ time, byId: { quarry: { id: 'quarry' } }, nodes: [{ id: 'quarry' }] });

    const f = mk();
    assert(f.nodeAvailable('quarry'), 'extraction', 'fresh ground is seam-eligible');
    f.markSpent('quarry', 100);
    assert(!f.nodeAvailable('quarry'), 'extraction', 'a drained zone is burned');
    // The pledge carries the burn: snapshot → fresh instance → restore.
    const g = mk();
    g.restore!(f.snapshot!());
    assert(!g.nodeAvailable('quarry'), 'extraction', 'spent ground survives snapshot→restore');
    // Replenishment: far past respawnSec the ground quietly refills.
    g.update(0.5, viewAt(100 + 24 * 3600));
    assert(g.nodeAvailable('quarry'), 'extraction', 'a spent seam replenishes after its clock');
    // Prune drops unknown ground without throwing.
    f.pruneZones!(() => false);
    assert(f.nodeAvailable('quarry'), 'extraction', 'pruned ground is forgotten (eligible again)');
    // devIgnite clears the burn and answers by gate + structural floor.
    const h = mk();
    h.markSpent('quarry', 5);
    assert(h.devIgnite(viewAt(6), 'quarry'), 'extraction', 'devIgnite clears the spent mark (gate live)');
    assert(h.nodeAvailable('quarry'), 'extraction', 'devIgnite leaves the ground eligible');

    // The honesty invariant, over every extract encounter any package ships.
    for (const e of allEncounterSpecs()) {
      if (!e.extract) continue;
      assert(e.timePerKill === 0 && e.radiusPerKill === 0, 'extraction',
        `extract encounter '${e.id}' clock is not kill-fed`);
      assert(e.scales.every(s => (s.maxBonusTime ?? 0) === 0), 'extraction',
        `extract encounter '${e.id}' has no bonus-time snowball`);
    }
  }
}

// === 6. THE LEDGER CONTRACT ===================================================
console.log('eventqa: ledger contract (reads ⊆ bumps)');
{
  // BUMPED keys: every bumpLedger/bumpAccountLedger string literal in src/,
  // plus every EncounterLedger value (world bumps e.def.ledger.* verbatim).
  const bumped = new Set<string>();
  const readKeys = new Set<string>();
  const walk = (dir: string): void => {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, f.name);
      if (f.isDirectory()) { walk(p); continue; }
      if (!f.name.endsWith('.ts')) continue;
      const text = fs.readFileSync(p, 'utf8');
      // Modular hosts (e.g. TitanRuntime) alias World as w; the literal
      // counter contract must not depend on the caller's variable name.
      for (const m of text.matchAll(/bump(?:Account)?Ledger\(\s*(?:[\w.]+\.ledger,\s*)?'([a-z0-9_]+)'/g)) bumped.add(m[1]);
      for (const m of text.matchAll(/ledgerOnEnter:\s*'([a-z0-9_]+)'/g)) bumped.add(m[1]);
      for (const m of text.matchAll(/ledgerKill:\s*'([a-z0-9_]+)'/g)) bumped.add(m[1]);
      for (const m of text.matchAll(/ctx\.ledger\.([a-z0-9_]+)/g)) readKeys.add(m[1]);
    }
  };
  walk(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'src'));
  for (const e of allEncounterSpecs()) {
    bumped.add(e.ledger.onEncounter);
    bumped.add(e.ledger.onClose);
    if (e.extract) bumped.add(e.extract.ledgerLost); // settleExtraction bumps it verbatim
  }
  // Milestone/meta keys the engine writes dynamically (reached_level_<n>,
  // vocation ids, quest rewards) — the dynamic namespaces the scan can't see.
  const DYNAMIC = [/^reached_level_/, /^vocation_/, /^quest_/];
  for (const key of readKeys) {
    if (bumped.has(key) || DYNAMIC.some(rx => rx.test(key))) { ok('ledger', `read key '${key}' is bumped`); continue; }
    fail('ledger', `unlock/tier reads '${key}' but NOTHING bumps it — an impossible unlock`);
  }
  assert(readKeys.size > 10, 'ledger', `scan found ${readKeys.size} read keys / ${bumped.size} bumped keys (scan sane)`);
}

// === 7. ZONE POLICY ==========================================================
console.log('eventqa: zone policy ids');
{
  const knownEvents = new Set<string>([
    ...PACKAGES.map(p => p.id),
    ...allEncounterSpecs().map(e => e.packageId),
    ...theaterKinds().map(d => d.id),
    'incursion', // always-on infra field (not a package id)
  ]);
  for (const [bid, b] of Object.entries(BIOMES)) {
    for (const id of [...(b.denyEvents ?? []), ...(b.allowEvents ?? [])]) {
      assert(knownEvents.has(id), 'policy', `biome '${bid}' names event '${id}'`);
    }
    for (const id of [...(b.denyFactions ?? []), ...(b.allowFactions ?? [])]) {
      assert(!!FACTIONS[id], 'policy', `biome '${bid}' names faction '${id}'`);
    }
  }
}

// === 8. THE THEATER REGISTRY (engine/theater.ts — the zone-event lane's
// re-founding) ================================================================
// The STATIC data contract: kinds and rows well-formed, every row naming a
// registered kind and known ground, hour gates lint-clean, THE RESIDENT
// LAW's schema holds (no reward surface exists to check — arcless by type),
// and THE PARITY PIN: the legacy three's re-founded numbers are TODAY'S
// numbers, verbatim (drift here is a retune, and a retune needs a ruling).
// Live behavior (draw determinism, the cadence, the pour caps, the
// concurrency fold) is balance/probe_theater.ts's ground.
console.log('eventqa: the theater registry');
{
  const kinds = theaterKinds();
  const rows = theaterRows();
  assert(kinds.length >= 3, 'theater', `registry holds ${kinds.length} kinds`);
  assert(new Set(kinds.map(d => d.id)).size === kinds.length, 'theater', 'kind ids unique');
  assert(new Set(rows.map(r => r.id)).size === rows.length, 'theater', 'row ids unique');
  for (const d of kinds) {
    assert(typeof d.spawn === 'function' && typeof d.tick === 'function', 'theater', `${d.id}: spawn+tick handlers present`);
    assert(d.posture === 'replacement' || d.posture === 'additive', 'theater', `${d.id}: posture declared`);
    if (d.posture === 'additive') {
      const cap = d.pourCap ?? THEATER_CFG.pour.additiveCap;
      assert(Number.isFinite(cap) && cap > 0, 'theater', `${d.id}: additive kind stands under a finite pour cap`);
    }
  }
  for (const r of rows) {
    assert(!!theaterKindDef(r.kind), 'theater', `row '${r.id}' names registered kind '${r.kind}'`);
    assert(r.chance > 0 && r.chance <= 1, 'theater', `row '${r.id}' chance in (0,1]`);
    assert(r.weight === undefined || r.weight > 0, 'theater', `row '${r.id}' weight positive`);
    assert(r.pourCap === undefined || r.pourCap > 0, 'theater', `row '${r.id}' pour cap positive`);
    for (const b of r.biomes ?? []) {
      assert(!!BIOMES[b], 'theater', `row '${r.id}' names biome '${b}'`);
    }
    for (const f of r.factions ?? []) {
      assert(!!FACTIONS[f], 'theater', `row '${r.id}' names faction '${f}'`);
    }
    // THE FACE AXIS (TheaterRow.tilesets): a row that claims faces names REAL
    // tilesets, each standing in the biomes it also claims (a terrace row on
    // farmland ground would never play — drift, not texture).
    for (const tsId of r.tilesets ?? []) {
      const ts = TILESETS[tsId];
      assert(!!ts, 'theater', `row '${r.id}' names tileset '${tsId}'`);
      if (ts && r.biomes) {
        assert(!!ts.biome && r.biomes.includes(ts.biome), 'theater',
          `row '${r.id}' face '${tsId}' stands in one of its biomes [${r.biomes.join(', ')}]`);
      }
    }
    for (const w of validateRadianceCond(`theater row '${r.id}'`, r.when)) {
      fail('theater', w);
    }
  }
  // The ambient caravan stays RETIRED — escorts are the 'procession' zone
  // OBJECTIVE (data/processions.ts), never a theater kind.
  assert(!kinds.some(d => d.id === 'caravan'), 'theater', 'the ambient caravan kind is retired');
  // THE PARITY PIN — the legacy three re-founded with TODAY'S numbers. The
  // old chanceNight/chanceDay literals live as night/day phase rows; the
  // cast counts live as kind params. Retuning any of these is a design
  // ruling, not a drive-by.
  const pin = (rowId: string, kind: string, chance: number, night: boolean): void => {
    const r = rows.find(x => x.id === rowId);
    assert(!!r && r.kind === kind && r.chance === chance, 'theater',
      `parity: ${rowId} = ${kind} @ ${chance}`);
    const ph = r?.when?.phases ?? [];
    assert(night ? ph.length === 1 && ph[0] === 'night'
      : ph.length === 3 && !ph.includes('night'), 'theater',
      `parity: ${rowId} keeps the old ${night ? 'isNight' : 'day-side'} phase read`);
  };
  pin('siege_night', 'siege', 0.7, true);
  pin('siege_day', 'siege', 0.55, false);
  pin('patrol_night', 'patrol', 0.6, true);
  pin('patrol_day', 'patrol', 0.4, false);
  pin('war_column_night', 'war_column', 0.55, true);
  pin('war_column_day', 'war_column', 0.45, false);
  const sp = theaterKindDef('siege')?.params as Record<string, number> | undefined;
  assert(!!sp && sp.attackers === 5 && sp.defenders === 4 && sp.attackerRing === 220
    && sp.attackerJitter === 30 && sp.defenderJitter === 60, 'theater',
    'parity: the siege cast is today\'s 5-on-4 at the old ring/jitters');
  const pp = theaterKindDef('patrol')?.params as Record<string, number> | undefined;
  assert(!!pp && pp.followers === 3 && pp.maxWaypoints === 5 && pp.leadJitter === 30
    && pp.followJitter === 60, 'theater', 'parity: the patrol walks today\'s 1+3 beat');
  const cp = theaterKindDef('war_column')?.params as Record<string, number> | undefined;
  assert(!!cp && cp.followers === 5 && cp.maxWaypoints === 6 && cp.leadJitter === 26
    && cp.followJitter === 55, 'theater', 'parity: the war column marches today\'s 1+5 file');
  // The warfront's ownership proof: the column's rows claim its biome.
  assert(rows.filter(r => r.kind === 'war_column').every(r => r.biomes?.length === 1 && r.biomes[0] === 'warfront'),
    'theater', 'war_column rows claim the warfront biome and no other country');
}

// === 9. THE WANING LAW (finite clocks) =======================================
// No event may be farmable ad infinitum: every in-zone event clock is FINITE,
// and kills may buy time only from a finite, per-scale well (bonusUsed is
// cumulative and never refills), so the reachable ceiling falls at wall-clock
// rate however hard a field is farmed. This census makes the law unauthorable
// by omission; the live dynamics are pinned on the real engine by
// balance/probe_eventclock.ts. The INCURSION — always-on infra, no package
// def, so the package audits never see it — joins at the tail: its declared
// termination policy is censused knob-by-knob and DRIVEN through the
// overlay's own public seams (the deadwake surge() idiom).
console.log('eventqa: the waning law (finite clocks)');
{
  for (const e of allEncounterSpecs()) {
    assert(Number.isFinite(e.timePerKill) && e.timePerKill >= 0, 'waning',
      `'${e.id}' timePerKill is finite and non-negative`);
    for (const s of e.scales) {
      assert(Number.isFinite(s.baseTime) && s.baseTime > 0, 'waning',
        `'${e.id}' scale '${s.id}' baseTime is finite and positive`);
      assert(Number.isFinite(s.maxBonusTime) && s.maxBonusTime >= 0, 'waning',
        `'${e.id}' scale '${s.id}' maxBonusTime is finite and non-negative`);
    }
    if (e.timePerKill > 0) {
      // The spigot needs a well…
      assert(e.scales.some(s => s.maxBonusTime > 0), 'waning',
        `'${e.id}' is kill-fed but every scale's well is empty — timePerKill is a dead knob`);
      // …and a well that runs dry must SAY so (the honesty tell).
      assert(!!e.waneText, 'waning',
        `'${e.id}' is kill-fed but declares no waneText — a silently-dry well is a hidden timer`);
    } else {
      // …and a well needs a spigot: a bonus budget no kill can fill is dead
      // data AND would draw a lying headroom band on the HUD bar.
      assert(e.scales.every(s => s.maxBonusTime === 0), 'waning',
        `'${e.id}' is not kill-fed but carries a bonus well — maxBonusTime is a dead knob`);
    }
    // A surge-carrying encounter must burn out on its own clock (the demon
    // invasion's maxLifeSec precedent — enforced in its overlay).
    if (e.surge) {
      assert(Number.isFinite(e.surge.maxLifeSec) && e.surge.maxLifeSec > 0, 'waning',
        `'${e.id}' surge declares a hard maxLifeSec burnout`);
    }
  }

  // THE DEADWAKE EBB: the tide's pour well is declared, positive, and told.
  // (Reached through the overlay's public surge() seam — the config is the
  // def's, the read is the engine's own.)
  const dwPkg = PACKAGE_BY_ID['deadwake'];
  assert(!!dwPkg?.world?.overlay, 'waning', 'the deadwake package stands');
  if (dwPkg?.world?.overlay) {
    const gate = { active: true, share: 1, pressure: 1, ignitionMul: 1, severityMul: 1, concurrencyMul: 1 };
    const dw = dwPkg.world.overlay({ seed: 0xdead, gate: () => gate, biomeSeed: 0xdead }) as unknown as {
      surge(): { pourBudgetSec: number; falterFrac: number; ebbText: string } };
    const s = dw.surge();
    assert(Number.isFinite(s.pourBudgetSec) && s.pourBudgetSec > 0, 'waning',
      'deadwake pourBudgetSec is a hard, positive pour ceiling');
    assert(s.falterFrac > 0 && s.falterFrac < 1, 'waning',
      'deadwake falterFrac leaves a real pre-ebb tell window');
    assert(typeof s.ebbText === 'string' && s.ebbText.length > 0, 'waning',
      'deadwake declares its ebb announce (tone is data)');
  }

  // THE INCURSION TERMINATION: the always-on infra blight (no package def —
  // the lifetime audit's last uncensused stream). Its lawful shape is the
  // STANDING CONDITION: cured by the Observer DEED (world.ts
  // materializeObserver gates on the policy; killHandlers' eldritch_observer
  // → resolveEpicenter), with a SELF-THROTTLING pour — every blight cull
  // retracts the reach by termination.cleanseRetract (killHandlers'
  // eldritch_cleanse → cleanse), so one cull per event beat strictly outruns
  // regrowth and the pour is always player-shuttable. The config half
  // censuses every archetype's knobs (dead knobs refused BOTH ways, the
  // waning idiom); the dynamics half drives the REAL overlay through the
  // exact public seams the engine calls, so the declared policy can never
  // silently un-wire again.
  for (const [aid, a] of Object.entries(INCURSION_ARCHETYPES)) {
    const t = a.termination;
    assert(Number.isFinite(a.spread.maxReach) && a.spread.maxReach > 0, 'waning',
      `incursion '${aid}': maxReach is a finite spatial ceiling`);
    assert(a.cap.maxConcurrent >= 1, 'waning', `incursion '${aid}': maxConcurrent sane`);
    assert(a.announce.length > 0, 'waning', `incursion '${aid}': the landing is told (announce)`);
    if (t.policy === 'hybridCleanseObserver') {
      assert(!!t.observer && !!MONSTERS[t.observer], 'waning',
        `incursion '${aid}': the Observer deed resolves — '${t.observer ?? '(none)'}' must be a real `
        + `monster or materializeObserver refuses forever (an immortal blight)`);
      assert(Number.isFinite(t.cleanseRetract ?? NaN) && (t.cleanseRetract ?? 0) > 0, 'waning',
        `incursion '${aid}': cleanseRetract is a live, positive retract`);
      assert((t.cleanseRetract ?? 0) > a.spread.growthPerSec * a.eventInterval, 'waning',
        `incursion '${aid}': the tug-of-war is winnable — one cull per beat outruns regrowth `
        + `(${t.cleanseRetract} > ${a.spread.growthPerSec}/s × ${a.eventInterval}s)`);
    } else {
      assert(t.observer == null && t.cleanseRetract == null, 'waning',
        `incursion '${aid}': ambientCapped carries no observer/cleanseRetract dead knobs`);
      assert(a.cap.maxInfluencedZones > 0, 'waning',
        `incursion '${aid}': ambientCapped honors its own name (maxInfluencedZones > 0)`);
    }
    if (t.observerReward) {
      assert(t.observerReward.base > 0 && t.observerReward.festerBonusMax >= 0
        && t.observerReward.festerSeconds > 0, 'waning', `incursion '${aid}': observerReward row sane`);
    }
  }

  // The dynamics, on the real overlay (fixed seed — a deterministic landing):
  // ignite → bind → cleanse retracts exactly → the deeds collapse it whole.
  {
    const arch = INCURSION_ARCHETYPES['eldritch'];
    const retract = arch.termination.cleanseRetract ?? 0;
    const inc = new IncursionField(new Rng(0x1ec0));
    const lit = inc.ignite('eldritch', { x: 0, y: 0 }, 12);
    assert(!!lit, 'waning', 'eldritch incursion ignites (under maxConcurrent)');
    const eps = inc.peek()[0]?.epicenters ?? [];
    assert(eps.length >= arch.nodeCount[0] && eps.length <= arch.nodeCount[1], 'waning',
      `landing fields ${eps.length} epicenter(s) within nodeCount`);
    assert(inc.mintRequests.length === eps.length, 'waning', 'one mint request per epicenter');
    // Bind each epicenter to a QA zone AT its coord — what the engine's mint
    // drain does through placeZoneAt + bindEpicenter.
    const byId: Record<string, ZoneDef> = {};
    eps.forEach((ep, i) => {
      const zid = `qa_inc_e${i}`;
      byId[zid] = { id: zid, map: { x: ep.coord.x, y: ep.coord.y }, exits: [] } as unknown as ZoneDef;
      inc.bindEpicenter(ep.id, zid);
    });
    const view = { byId, visited: new Set(Object.keys(byId)) } as unknown as OverlayView;
    inc.update(0.001, view); // hand the overlay its node view (the engine's tick)
    assert(inc.influence('qa_inc_e0') > 0.5, 'waning', 'a bound epicenter zone reads deep influence');
    assert(inc.resolveEpicenter('qa_not_a_zone') === 1, 'waning', 'resolving a non-epicenter zone is a 1× no-op');

    // CLEANSE: the per-cull retract shrinks every influencing pod by exactly
    // cleanseRetract (the eldritch_cleanse kill handler's own call).
    type Snap = { ownedZones: string[]; incursions: { epicenters: { pods: { len: number }[] }[] }[] };
    const podsOf = (s: Snap): number[] => s.incursions[0].epicenters[0].pods.map(p => p.len);
    const before = podsOf(inc.snapshot() as Snap);
    inc.cleanse('qa_inc_e0', retract);
    const after = podsOf(inc.snapshot() as Snap);
    assert(after.length > 0 && after.every((len, i) => Math.abs(len - Math.max(0, before[i] - retract)) < 1e-9),
      'waning', `cleanse retracts every influencing pod by cleanseRetract (${retract})`);

    // THE DEED: resolve every epicenter — the LAST collapses the incursion
    // whole, and a festered blight pays the declared richer multiplier.
    for (let i = 0; i < eps.length - 1; i++) {
      const mul = inc.resolveEpicenter(`qa_inc_e${i}`);
      assert(mul >= 1.5 - 1e-9, 'waning', `epicenter ${i} resolves for ≥ base spoils (${mul.toFixed(2)}×)`);
      assert(inc.activeCount() === 1, 'waning', `incursion stands while epicenters remain (${i + 1}/${eps.length} down)`);
    }
    inc.update(240, view); // let the last epicenter FESTER past festerSeconds
    const lastMul = inc.resolveEpicenter(`qa_inc_e${eps.length - 1}`);
    assert(Math.abs(lastMul - 3.5) < 1e-6, 'waning',
      `a fully-festered Observer pays base + festerBonusMax (${lastMul.toFixed(2)}× = 3.5×)`);
    assert(inc.activeCount() === 0, 'waning', 'the last Observer deed collapses the incursion');
    assert(inc.influence('qa_inc_e0') === 0 && inc.eventContext('qa_inc_e0') === null, 'waning',
      'a collapsed incursion holds no influence and fires no events');
    const residue = inc.snapshot() as Snap;
    assert(residue.incursions.length === 0 && residue.ownedZones.length === 0, 'waning',
      'the collapse leaves no residue in the save (dead incursions never snapshot)');
    assert(!!inc.ignite('eldritch', { x: 0, y: 0 }, 12), 'waning',
      'the deed re-opens the sky (a collapsed incursion frees its maxConcurrent seat)');
  }
}

// === 10. THE HUNT (surge-contract invariants; the lifecycle rides probe_hunt) =
console.log('eventqa: hunt surge contract');
{
  const huntPkg = PACKAGE_BY_ID['hunt'];
  assert(!!huntPkg?.world?.overlay, 'hunt', 'the hunt package stands');
  if (huntPkg?.world?.overlay) {
    const gate = { active: false, share: 0, pressure: 0, ignitionMul: 0, severityMul: 0, concurrencyMul: 1 };
    const hf = huntPkg.world.overlay({ seed: 0x4117, gate: () => gate, biomeSeed: 0x4117 }) as unknown as {
      surge(): {
        triggerChance: number; trackStages: [number, number]; dwellSeconds: number;
        beasts: { faction: string; defId: string; weight: number }[];
        seat: { range?: { min?: number; max?: number } };
      };
    };
    const s = hf.surge();
    assert(s.triggerChance > 0 && s.triggerChance < 1, 'hunt', 'triggerChance is a live, sane per-step chance');
    assert(s.trackStages[0] >= 1 && s.trackStages[1] >= s.trackStages[0], 'hunt',
      `trackStages ordered with ≥1 find ([${s.trackStages}])`);
    assert(s.dwellSeconds > 0, 'hunt', 'the trail asks a real dwell');
    assert((s.seat.range?.min ?? 0) >= 0 && (s.seat.range?.max ?? Infinity) > (s.seat.range?.min ?? 0),
      'hunt', 'the seat envelope is ordered (off the boots, findable)');
    assert(s.beasts.length >= 1, 'hunt', `the quarry pool stands (${s.beasts.length} beasts)`);
    for (const b of s.beasts) {
      const def = MONSTERS[b.defId];
      assert(!!FACTIONS[b.faction] && !!def && b.weight > 0, 'hunt',
        `quarry '${b.defId}' resolves (faction '${b.faction}', weight ${b.weight})`);
      if (!def) continue;
      // THE CHASE CONTRACT: a hunt beast RUNS — at least one flee phase, each
      // survivable by burst (damage-reduction < 100%), and the body is a boss
      // (the one-great-beast promise: payouts, Crowned promotion, the pin).
      const flees = (def.brain?.phases ?? []).filter(p => p.flee);
      assert(flees.length >= 1, 'hunt', `quarry '${b.defId}' carries ≥1 flee phase (the chase IS the hunt)`);
      for (const p of flees) {
        const dt = (p.mods ?? []).find(m => m.stat === 'damageTaken');
        assert(dt ? -dt.value < 1 : true, 'hunt',
          `quarry '${b.defId}' flee @${p.atLifeFrac} stays burst-killable (reduction < 1)`);
      }
      assert(!!def.boss, 'hunt', `quarry '${b.defId}' is boss-tier (one GREAT beast, never a pack body)`);
    }
    // THE BEAST'S GROUND (the transience doctrine): both dress kinds stand
    // event-pinned (never sky-born) and the hunt's front source is registered
    // — the spoor/nest bones can only ever be BORROWED ground.
    const { WEATHER_DEFS } = await import('../src/world/weather');
    const { eventFrontSourceIds } = await import('../src/engine/eventWeather');
    assert(!!WEATHER_DEFS.hunt_spoor?.eventOnly && !WEATHER_DEFS.hunt_spoor?.skyWeight
      && !!WEATHER_DEFS.hunt_nest?.eventOnly && !WEATHER_DEFS.hunt_nest?.skyWeight,
      'hunt', 'spoor + nest are event-pinned weather rows (never sky-born)');
    assert(eventFrontSourceIds().includes('hunt'), 'hunt', 'the hunt event-front source is registered');
  }
}

// === verdict =================================================================
console.log(failures
  ? `\neventqa FAILED — ${failures} breach(es) across ${checks + failures} checks`
  : `\neventqa OK — ${checks} checks clean`);
process.exit(failures ? 2 : 0);
